//5.producer consumer using semaphores.
#include<stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdlib.h>
#include<unistd.h>
#define N 5
int prod=0,cons=0;
struct buffer{
	int b[N];
	sem_t empty,full;
	int in;
  int out;
}buf;
void *P(){
	int i=1;
	for(int j=0;j<N;j++){
    prod++;
    int save=prod;
    printf("\nProducer %d is entering C.S",save);
    sem_wait(&(buf.empty));
		buf.b[buf.in]=i;
		buf.in=(buf.in+1)%N;
		printf("\nProduced item:%d",i++);
		sleep(1);
    printf("\nProducer %d  is Leaving C.S",save);
		sem_post(&(buf.full));
	}
}
void *C(){
	int item;
	for(int j=0;j<N;j++){
    cons++;
    int save=cons;
    printf("\nConsumer %d is entering C.S",save);
		sem_wait(&(buf.full));
		item=buf.b[buf.out];
		buf.out=(buf.out+1)%N;
		printf("\nConsumed :%d",item);
    printf("\nConsumer %d  is Leaving C.S",save);
		sem_post(&(buf.empty));

	}
}
void main(){
	pthread_t t1,t2;
	sem_init(&(buf.empty),0,N);
	sem_init(&(buf.full),0,0);
	buf.in=0;
	buf.out=0;
	pthread_create(&t1,NULL,P,NULL);
	pthread_create(&t2,NULL,C,NULL);
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
}
/*Output:
Producer 1 is entering C.S
Produced item:1
Consumer 1 is entering C.S
Producer 1  is Leaving C.S
Producer 2 is entering C.S
Produced item:2
Consumed :1
Consumer 1  is Leaving C.S
Consumer 2 is entering C.S
Producer 2  is Leaving C.S
Producer 3 is entering C.S
Produced item:3
Consumed :2
Consumer 2  is Leaving C.S
Consumer 3 is entering C.S
Producer 3  is Leaving C.S
Producer 4 is entering C.S
Produced item:4
Consumed :3
Consumer 3  is Leaving C.S
Consumer 4 is entering C.S
Producer 4  is Leaving C.S
Producer 5 is entering C.S
Produced item:5
Consumed :4
Consumer 4  is Leaving C.S
Consumer 5 is entering C.S
Producer 5  is Leaving C.S
Consumed :5
Consumer 5  is Leaving C.S
*/
