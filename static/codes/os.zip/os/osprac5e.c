/*6.Program to Demonstrate Matrix Multipliaction using Threads*/
#include<stdio.h>
#include<stdlib.h>
#include <pthread.h>
#include <time.h>
#include <wait.h>
#include <errno.h>
#include <sys/types.h>
int A[3][2]={{1,4},{2,5},{3,6}};
int B[2][3]={{8,7,6},{5,4,3}};
int C[3][3];
typedef struct {
  int r;
  int c;
}v;
void *runner(void *arg){
  v*temp=arg;
	int k;
  for(k=0;k<2;k++){
    C[temp->r][temp->c]+=A[temp->r][k]*B[k][temp->c];
  }
  pthread_exit(NULL);
}
int main(int argc, char const *argv[]) {
  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_t tid;
int i,j;
printf("\nThe matrixs are:\n");
printf("A=\n");
for(i=0;i<3;i++){
	for(j=0;j<2;j++)
		printf("%d ",A[i][j]);
	printf("\n");	
}
printf("\nB=\n");
for(i=0;i<2;i++){
	for(j=0;j<3;j++)
		printf("%d ",B[i][j]);
	printf("\n");	
}
  for(i=0;i<3;i++){
    for(j=0;j<3;j++){
      v *data=(v*)malloc(sizeof(v));
      data->r=i;
      data->c=j;
      pthread_create(&tid,&attr,runner,data);
     pthread_join(tid,NULL);
    }
    }
    printf("Resultant matrix-\n");
    for(i=0;i<3;i++){
      for (j = 0; j < 3; j++) {
          printf("%d  ",C[i][j]);
      }
      printf("\n");
    }
  return 0;
}
/* Output:
The matrixs are:
A=
1 4 
2 5 
3 6 

B=
8 7 6 
5 4 3 
Resultant matrix-
28  23  18  
41  34  27  
54  45  36  
*/
