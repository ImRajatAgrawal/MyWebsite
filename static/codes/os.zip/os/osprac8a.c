//BEST FIT ALGORITHM
#include<stdio.h>
#include<stdlib.h>
int main(){
	int n,b,i,j,itf=0,extf=0,flag,visited[10],s=0,t,allocated[10];
	printf("\nEnter the no of blocks:");
	scanf("%d",&b);
	int blocks[b],id[b];
	printf("\nEnter no of processes:");
	scanf("%d",&n);
	int p[n];
	printf("\nEnter memory partitions:\n");
for(i=0;i<b;i++){
	scanf("%d",&blocks[i]);
	allocated[i]=0;
}
for(i=0;i<b;i++){
	for(j=i;j<b;j++){
		if(blocks[i]>blocks[j]){
			t=blocks[i];
			blocks[i]=blocks[j];
			blocks[j]=t;

		}
	}
}
printf("\nEnter size of processes:\n");
for(i=0;i<n;i++){
	printf("P%d:",i+1);
	scanf("%d",&p[i]);
	visited[i]=0;
}
for(j=0;j<n;j++){
	flag=0;
	for(i=0;i<b;i++){
		if(p[j]<=blocks[i] && visited[j]==0 && allocated[i]==0){
			blocks[i]-=p[j];
			itf+=blocks[i];
			printf("\nProcess P%d has been allocated with block %d",j+1,i+1);
			flag=1;
			visited[j]=1;
			allocated[i]=1;
			break;
		}
}
	if(flag==0){
		printf("\nProcess P%d is not allocated to any block",j+1);
		extf+=p[j];
		visited[j]=1;
	}
}
for(i=0;i<n;i++){
	for(j=0;j<b;j++)
	if(allocated[j]==0){
		s+=blocks[j];
		break;
	}
}
if(extf<=s||s==0){
	printf("\nInternal fragmentation:%d",itf);
	printf("\nExternal fragmentation:%d\n",extf);
}
else{
	extf=0;
	printf("\nInternal fragmentation:%d",itf);
	printf("\nExternal fragmentation:%d\n",extf);
}
return 0;
}
/*
OUTPUT:
Enter the no of blocks:6

Enter no of processes:4

Enter memory partitions:
200
400
600
500
300
250

Enter size of processes:
P1:357
P2:210
P3:468
P4:491

Process P1 has been allocated with block 4
Process P2 has been allocated with block 2
Process P3 has been allocated with block 5
Process P4 has been allocated with block 6
Internal fragmentation:224
External fragmentation:0
*/
