//READER WRITER PROBLEM USING SEMAPHORES.
#include<stdio.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>
sem_t wrt;
sem_t mutex;
int readCount=0,w,j=0,rd=0,wr=0;
void *Reader(void *arg);
void *Writer(void *arg);
int main(){
	int i=0,k=0,now,nor;
	sem_init(&wrt,0,1);
	sem_init(&mutex,0,1);
	w=0;
	pthread_t rtid[100],wtid[100],tid[100];
	printf("\nEnter number of Readers:");
	scanf("%d",&nor);
	printf("\nEnter number of Writers:");
	scanf("%d",&now);
	for(i=0;i<now;i++)
	pthread_create(&wtid[i],NULL,Writer,NULL);
	for(i=0;i<nor;i++)
	pthread_create(&rtid[i],NULL,Reader,NULL);
	for(i=0;i<now;i++)
		pthread_join(wtid[i],NULL);
	for(i=0;i<nor;i++)
	pthread_join(rtid[i],NULL);
	pthread_exit(NULL);
	return 0;
}
void * Writer(void *arg){
	wr++;
	int s=wr;
	printf("\nWriter %d is trying to enter into Critical Section\n",s);
	sem_wait(&wrt);
	w=j;
	j++;
	printf("\nWriter %d is writting:%d\n",s,w);
	sleep(1);
	printf("\nWriter %d is leaving\n",s);
	sem_post(&wrt);
}
void *Reader(void *arg){
	rd++;
	int s=rd;
	printf("\nReader %d is trying to enter into the Critical Section\n",s);
	sleep(1);
	sem_wait(&mutex);
	readCount++;
	if(readCount==1)
		sem_wait(&wrt);
	sem_post(&mutex);
	printf("\nReader %d is reading:%d\n",s,w);
	sleep(1);
	sem_wait(&mutex);
	printf("\nReader %d is leaving\n",s);
	readCount--;
	if(readCount==0)
		sem_post(&wrt);	
	sem_post(&mutex);
}
/*
OUTPUT:
Enter number of Readers:4

Enter number of Writers:5

Writer 1 is trying to enter into Critical Section
Writer 1 is writting:0
Writer 2 is trying to enter into Critical Section
Writer 3 is trying to enter into Critical Section
Writer 4 is trying to enter into Critical Section
Writer 5 is trying to enter into Critical Section
Reader 1 is trying to enter into the Critical Section
Reader 2 is trying to enter into the Critical Section
Reader 3 is trying to enter into the Critical Section
Reader 4 is trying to enter into the Critical Section
Writer 1 is leaving
Writer 2 is writting:1
Writer 2 is leaving
Writer 3 is writting:2
Writer 3 is leaving
Writer 4 is writting:3
Writer 4 is leaving
Writer 5 is writting:4
Writer 5 is leaving
Reader 1 is reading:4
Reader 2 is reading:4
Reader 3 is reading:4
Reader 4 is reading:4
Reader 1 is leaving
Reader 3 is leaving
Reader 2 is leaving
Reader 4 is leaving
*/

