//Demonstrate exec system call
//file-osprac3g.c
#include <stdio.h>
#include <unistd.h>
void main()
{
printf("before exec my pid is %d\n",getpid()); 
printf("before exec my ppid is %d\n",getppid());
printf("exec starts\n");
execl("osprac3h","osprac3h",(char*)0);
printf("This will not print\n");
}
//file-osprac3h.c
#include <stdio.h>
#include<unistd.h>
void main()
{
printf("After exec my pid is %d\n",getpid()); 
printf("After exec my ppid is %d\n",getppid());
printf("exec ends\n");
}
/*
OUTPUT:
rajat@rajat-HP-Pavilion-15-NoteBook-PC:~$ gcc -o osprac3g osprac3g.c
rajat@rajat-HP-Pavilion-15-NoteBook-PC:~$ gcc -o osprac3h osprac3h.c
rajat@rajat-HP-Pavilion-15-NoteBook-PC:~$ ./osprac3g
before exec my pid is 2457
before exec my ppid is 2171
exec starts
After exec my pid is 2457
After exec my ppid is 2171
exec ends
*/
