#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<dirent.h>
#include<sys/stat.h>
int main(){
int f,choice;
char buff[100],fname[25],cwd[1024];
DIR *p;
struct dirent *d;
do{
printf("\n_____Directory sysytem calls______");
printf("\n0.exit()   1.create a directory");
printf("\n2.remove   3.list directories and files in CWD");
printf("\n4.change directory");
printf("\nEnter operation to perform:");
scanf("%d",&choice);
switch(choice){
	case 0:
			printf("\nyou have opted to exit...\n");
			exit(0);
	case 1:
				printf("\nEnter name of directory to create:");
				scanf("%s",fname);
				if((f=mkdir(fname,0777))==-1){
					perror("creation error");
				}
				else
					printf("\nDirectory with name [ %s ] created",fname);
				break;
	case 2:
			printf("\nEnter directory name to delete:");
			scanf("%s",fname);
			if((f=rmdir(fname))==-1){
				printf("\ncannot remove the directory");
			}
			else
				printf("\nDirectory removed");
			break;
	case 3:
			if((getcwd(cwd,sizeof(cwd)))!=NULL)
				printf("current working directory:%s\n",cwd);
			else
				perror("getcwd() error");
			p=opendir(cwd);
			if(p==NULL)
				perror("cannot find directory");
			else{	
				while(d=readdir(p)){
					printf("%5s %ld  ",d->d_name,d->d_ino);
					if(d->d_type==DT_REG)
						printf("regular file  ");
					else if(d->d_type==DT_DIR)
						printf("Directory  ");
					else if(d->d_type==DT_SOCK)
						printf("DOMAIN socket  ");
					else if(d->d_type==DT_BLK)
						printf("Block device  ");
					else if(d->d_type==DT_CHR)
						printf("Character device  ");
					else
						printf("unknown  ");		
				}
			}
			closedir(p);					
			break;
	case 4:
			printf("\nEnter directory name to change to:");
			scanf("%s",fname);
			if(chdir(fname)==-1){
				perror("could not change to directory");
			}
			else{
				getcwd(cwd,sizeof(cwd));
				printf("CWD: %s\n",cwd);
			}
			break;	
}			
}while(choice>0);
return 0;
}
/*
OUTPUT:
gcc osp2.c
rajat@rajat-HP-Pavilion-15-NoteBook-PC:~$ ./a.out

_____Directory sysytem calls______
0.exit()   1.create a directory
2.remove   3.list directories and files in CWD
4.change directory
Enter operation to perform:1

Enter name of directory to create:os

Directory with name [ os ] created
_____Directory sysytem calls______
0.exit()   1.create a directory
2.remove   3.list directories and files in CWD
4.change directory
Enter operation to perform:2

Enter directory name to delete:os

Directory removed
_____Directory sysytem calls______
0.exit()   1.create a directory
2.remove   3.list directories and files in CWD
4.change directory
Enter operation to perform:4

Enter directory name to change to:Documents
CWD: /home/rajat/Documents

_____Directory sysytem calls______
0.exit()   1.create a directory
2.remove   3.list directories and files in CWD
4.change directory
Enter operation to perform:3

current working directory:/home/rajat/Documents

rajatscript4.sh.pdf 138239  regular file  rajatsort3.c.pdf 137382  regular file  rajatscript7.sh.pdf 138251  regular file  server(1).c 135339  regular file  Shared Memory-2.pdf 137803  regular file  rajatscript2.sh.pdf 138098  regular file  serverprob.c.pdf 138070  regular file  rajatscript5.sh.pdf 138131  regular file  rajatscript9.sh.pdf 138257  regular file  process1.c 137802  regular file  dspd1.pdf 133822  regular file  myclient.c.pdf 137807  regular file  rajatscript8.sh.pdf 138259  regular file  rajatsort1.c.pdf 136801  regular file  awkcode.awk.pdf 133533  regular file  dspdprac8.c.pdf 137592  regular file  perl6.pl.pdf 135501  regular file  perlprac4.pl.pdf 135125  regular file  20_DSPD_P2_66.c.pdf 139948  regular file  myserver.c.pdf 137808  regular file  process2.c.pdf 138079  regular file  osp2b.c.pdf 166148  regular file      . 131107  Directory  p2.c.pdf 138067  regular file  p1.c.pdf 138064  regular file  dspd1.c 131299  regular file  rajatscript1.sh.pdf 138234  regular file  Socket programming.pdf 137804  regular file  dspdprac10.c.pdf 137704  regular file  rajatscript6.sh.pdf 138128  regular file  rajatscript3.sh.pdf 138108  regular file     .. 131074  Directory  dspdprac7.c.pdf 133521  regular file  clientprob.c.pdf 138068  regular file  23_DSPD_P2_66.c.pdf 140958  regular file  client(1).c 136283  regular file  os1.c.pdf 165574  regular file  document.pdf 132819  regular file  os2.c.pdf 165739  regular file  dspdprac5.c.pdf 133334  regular file  os3.c.pdf 165741  regular file  dspdprac4.c.pdf 133000  regular file  perlrajat.pl.pdf 133530  regular file  process1.c.pdf 138074  regular file  dspdprac6.c.pdf 133527  regular file  dspdprac11.c.pdf 140987  regular file  
_____Directory sysytem calls______
0.exit()   1.create a directory
2.remove   3.list directories and files in CWD
4.change directory
Enter operation to perform:0

you have opted to exit...
*/
