//4.A simple c program to demonstrate use of basic pthread functions  
#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<pthread.h>
void *threadfun(void *arg){
	sleep(1);
	printf("\nhello world\n");
}
int main(){
	pthread_t tid;
	printf("Before Thread\n");
	pthread_create(&tid,NULL,threadfun,NULL);
	printf("Thread created\n");
	printf("Thread id:%d",(int)tid);
	pthread_join(tid,NULL);
	printf("After Thread\n");
	exit(0);
return 0;
}
/*
OUTPUT:
Before Thread
Thread created
Thread id:1766450944
hello world
After Thread
*/
