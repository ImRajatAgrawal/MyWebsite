//PROGRAM 4:Simple program to create Orphan process
/#include<stdio.h>
#include<unistd.h>
int main(){
 pid_t p;
// create child process
 p=fork();
 if(p==0){
    //fork() returns Zero to child
    sleep(10);
 }
 printf("The child process pid is %d parent pid %d\n", getpid(), getppid());
	//parent/child waits for 20 secs and exits
 sleep(20);
 printf("\nProcess %d is done its Parent pid %d...\n", getpid(), getppid());
 return 0;
}
/*
OUTPUT:
The child process pid is 3089 parent pid 1995
The child process pid is 3090 parent pid 3089

Process 3089 is done its Parent pid 1995...
rajat@rajat-HP-Pavilion-15-NoteBook-PC:~$ 
Process 3090 is done its Parent pid 1016...
*/
//PROGRAM 5: PROGRAM FOR ORPHAN PROCESS IN C PROGRAMMING
#include<stdio.h>
#include<unistd.h>
int main(){
    int id;
    printf("Before fork()\n");
    id=fork();
    if(id==0){
        printf("Child has started: %d\n ",getpid());
        printf("Parent of this child : %d\n",getppid());
        printf("child prints 1 item\n");
        sleep(10);
        printf("child prints 2 items\n");
    }
    else{
        printf("Parent has started: %d\n",getpid());
        printf("Parent of the parent proc : %d\n",getppid());
    }
    printf("After fork()\n");
    return 0;
}
/*
OUTPUT:
Before fork()
Parent has started: 3276
Parent of the parent proc : 1995
After fork()
Child has started: 3277
 Parent of this child : 3276
child prints 1 item
rajat@rajat-HP-Pavilion-15-NoteBook-PC:~$ child prints 2 items
After fork()
*/
