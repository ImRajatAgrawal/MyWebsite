/*3.To show the discount mechanism using shared memory*/
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include<wait.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<unistd.h>
#include <time.h>
#include<semaphore.h>
#include<pthread.h>

#define SHMSZ 30
int main(int argc, char const *argv[]) {
  pid_t pid;
  int shm_id;
  int count_item=10;
  double discount=0,total_cost=0,total_savings=0;
  shm_id=shmget(IPC_PRIVATE,SHMSZ,IPC_CREAT|0666);
  if(shm_id<0){
		printf("Shm Not created\n");
		exit(0);
	}
	printf("Shared Memory Created with ID %u\n",shm_id);
  double arr[10];
  double *s_addr=(double *)shmat(shm_id,NULL,0);
  s_addr[0]=discount; 
  s_addr[1]=total_cost; 
  s_addr[2]=total_savings; 
  s_addr[3]=0;
  int flag=0;
  pid=fork();
  if(pid==0){
  sleep(15);
    printf("Child process:\n");
     while(s_addr[3]==0);
       s_addr[0]=(s_addr[1]*0.1);
       printf("Discount amount is : %f Rs\n",s_addr[0]);
  }
  else if (pid>0)
  {
    printf("Parent process: \n");
    printf("Enter purchase list:\n");
    for(int i=0;i<10;i++){
      printf("Enter Price of item [%d]: ",i+1);
      scanf("%lf",&arr[i]);
      s_addr[1]+=arr[i];
    }
    printf("\nTotal cost without Discount: %lf Rs",s_addr[1]);
    if(s_addr[1]>2000){
      s_addr[3]=1;
      wait(NULL);
      printf("\nDiscount obtained : %f Rs\n",s_addr[0]);
      s_addr[1]=s_addr[1]-s_addr[0];
      s_addr[2]=s_addr[0];
    }
    printf("\n=================================\n");
    printf("Item\tCost( INR )\n");
    printf("----------------------------------\n");
    for(int i=0;i<10;i++){
      printf("%d\t%f\n",i+1,arr[i]);
    }
    printf("\n==================================\n");
    printf("Total Bill: %f Rs and customer savings: %f Rs\n",s_addr[1],s_addr[2]);
  }

  return 0;
}
/*
Shared Memory Created with ID 21561358
Parent process: 
Enter purchase list:
Enter Price of item [1]: 200
Enter Price of item [2]: 300
Enter Price of item [3]: 400
Enter Price of item [4]: 500
Enter Price of item [5]: 600
Enter Price of item [6]: 700
Enter Price of item [7]: 800
Enter Price of item [8]: 900
Enter Price of item [9]: 1000
Enter Price of item [10]: 111

Child process:
Discount amount is : 551.100000 Rs
Total cost without Discount: 5511.000000 Rs
Discount obtained : 551.100000 Rs

=================================
Item	Cost( INR )
----------------------------------
1		200.000000
2		300.000000
3		400.000000
4		500.000000
5		600.000000
6		700.000000
7		800.000000
8		900.000000
9		1000.000000
10		111.000000

==================================
Total Bill: 4959.900000 Rs and customer savings: 551.100000 Rs
*/
