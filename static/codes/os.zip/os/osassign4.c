#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include<time.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<math.h>
typedef struct{
	long mtype;
	int arr[100];
	int len;
}queue;
int main(){
	int i,msgid;
	queue q;
	key_t key;
	key=1234;
	msgid=msgget(key,IPC_CREAT|0666);
	printf("\nMessage ID:%d",msgid);
	printf("\nReciever process:");
		if(msgrcv(msgid, &q, sizeof(q), 1, 0)<0){
			perror("msrcv");
			exit(1);	
		}
		printf("\nSquares of the nos are:\n");
		for(i=0;i<q.len;i++){
			printf("\t%d * %d = %.2lf\n",q.arr[i],q.arr[i],pow(q.arr[i],2));
		}
		 msgctl(msgid, IPC_RMID, NULL);
		 return EXIT_SUCCESS;
}		 
/*
OUTPUT:
Message ID:32768
Reciever process:
Squares of the nos are:
	671 * 671 = 450241.00
	766 * 766 = 586756.00
	925 * 925 = 855625.00
	945 * 945 = 893025.00
	1465 * 1465 = 2146225.00
	1598 * 1598 = 2553604.00
	1809 * 1809 = 3272481.00
	1891 * 1891 = 3575881.00
	1920 * 1920 = 3686400.00
	2351 * 2351 = 5527201.00
*/
