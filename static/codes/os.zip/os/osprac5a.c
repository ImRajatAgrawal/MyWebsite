//7.Linear search using multi threading(use n number of threads).
#include<pthread.h>
#include<stdio.h>
// Max size of array
#define max 16
// Max number of threads to create
#define thread_max 4
int a[max] = { 1, 5,5, 7, 10, 12, 14, 15,18, 20, 5, 25, 27, 30, 110, 220 };
int arr[10];
int k=0;
// Flag to indicate if key is found in a[] or not.
int f = 0;
int key;
int current_thread = 0;
// Linear search function which will run for all the threads
void *ThreadSearch(void *args){
    int num = current_thread++; int i;
    for(i = num*(max / 4);i<((num + 1)*(max /4));i++){
        if(a[i]==key){
            f = 1;
            arr[k]=i;
            k++;
         }
    }
}
// Driver Code
int main(){
	printf("Enter key to search:");
	scanf("%d",&key);
    pthread_t thread[thread_max];
	int i;
    for(i = 0;i<thread_max; i++){
        pthread_create(&thread[i], NULL,
                      ThreadSearch,(void *)0);
    }
    for(i = 0;i<thread_max; i++)
        pthread_join(thread[i], NULL);
    if(f == 1){
        printf("Key element found\n");
      	for(i=0;i<k;i++)
      		printf("index:%d\n",arr[i]);
      }
    else
        printf("Key not present\n");
    return 0;
}
/*
OUTPUT:
Enter key to search:5
Key element found
index:1
index:2
index:10
*/
