#include<stdio.h>
#include<stdlib.h>
#include<dirent.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/stat.h>
int main(){
struct dirent **d;
DIR *p;
char fname[100];
int n,i=0;
printf("\nEnter name of directory to open:");
scanf("%s",fname);
	p=opendir(fname);
	chdir(fname);
	getcwd(fname,sizeof(fname));
	n=scandir(fname,&d,0,alphasort);
	if(p==NULL)
		perror("cannot find directory");
	else{	
		printf("\n\t\t  Filename\tinode no.   filetype  \t Record length");
		while(i<n){
			printf("\n%25s\t %ld\t     ",d[i]->d_name,d[i]->d_ino);
			if(d[i]->d_type==DT_REG)
				printf("regular file  ");
			else if(d[i]->d_type==DT_DIR)
				printf("Directory  ");
			else if(d[i]->d_type==DT_SOCK)
				printf("DOMAIN socket  ");
			else if(d[i]->d_type==DT_BLK)
				printf("Block device  ");
			else if(d[i]->d_type==DT_CHR)
				printf("Character device  ");
			else
				printf("unknown  ");
			printf("\t%d",d[i]->d_reclen);			
		i++;
		}
	}
	printf("\n");
closedir(p);					
return 0;
}			
/*
OUTPUT:
gcc osp2b.c
rajat@rajat-HP-Pavilion-15-NoteBook-PC:~$ ./a.out

Enter name of directory to open:Documents

		  Filename	        inode no.    filetype  	 Record length
                        .	 131107	     Directory  	24
                       ..	 131074	     Directory  	24
      20_DSPD_P2_66.c.pdf	 139948	     regular file  	40
      23_DSPD_P2_66.c.pdf	 140958	     regular file  	40
      Shared Memory-2.pdf	 137803	     regular file  	40
   Socket programming.pdf	 137804	     regular file  	48
          awkcode.awk.pdf	 133533	     regular file  	40
              client(1).c	 136283	     regular file  	32
         clientprob.c.pdf	 138068	     regular file  	40
             document.pdf	 132819	     regular file  	32
                  dspd1.c	 131299	     regular file  	32
                dspd1.pdf	 133822	     regular file  	32
         dspdprac10.c.pdf	 137704	     regular file  	40
         dspdprac11.c.pdf	 140987	     regular file  	40
          dspdprac4.c.pdf	 133000	     regular file  	40
          dspdprac5.c.pdf	 133334	     regular file  	40
          dspdprac6.c.pdf	 133527	     regular file  	40
          dspdprac7.c.pdf	 133521	     regular file  	40
          dspdprac8.c.pdf	 137592	     regular file  	40
           myclient.c.pdf	 137807	     regular file  	40
           myserver.c.pdf	 137808	     regular file  	40
                os1.c.pdf	 165574	     regular file  	32
                os2.c.pdf	 165739	     regular file  	32
                os3.c.pdf	 165741	     regular file  	32
                 p1.c.pdf	 138064	     regular file  	32
                 p2.c.pdf	 138067	     regular file  	32
             perl6.pl.pdf	 135501	     regular file  	32
         perlprac4.pl.pdf	 135125	     regular file  	40
         perlrajat.pl.pdf	 133530	     regular file  	40
               process1.c	 137802	     regular file  	32
           process1.c.pdf	 138074	     regular file  	40
           process2.c.pdf	 138079	     regular file  	40
      rajatscript1.sh.pdf	 138234	     regular file  	40
      rajatscript2.sh.pdf	 138098	     regular file  	40
      rajatscript3.sh.pdf	 138108	     regular file  	40
      rajatscript4.sh.pdf	 138239	     regular file  	40
      rajatscript5.sh.pdf	 138131	     regular file  	40
      rajatscript6.sh.pdf	 138128	     regular file  	40
      rajatscript7.sh.pdf	 138251	     regular file  	40
      rajatscript8.sh.pdf	 138259	     regular file  	40
      rajatscript9.sh.pdf	 138257	     regular file  	40
         rajatsort1.c.pdf	 136801	     regular file  	40
         rajatsort3.c.pdf	 137382	     regular file  	40
              server(1).c	 135339	     regular file  	32
         serverprob.c.pdf	 138070	     regular file  	40
*/
