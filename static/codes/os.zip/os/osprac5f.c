/*8.Program to find the MAX and MIN element of the array using threads*/
#include<stdio.h>
#include<stdlib.h>
#include <pthread.h>
#include <time.h>
#include <wait.h>
#include <errno.h>
#include <sys/types.h>

#define SIZE 100000
#define NO_OF_THREADS 10
typedef struct{
  int max;
  int min;
}v;
int arr[SIZE];
void *runner(void *arg){
  v *temp=arg;
  temp=(v*)malloc(sizeof(v));
  temp->max=arr[SIZE/NO_OF_THREADS];
  temp->min=arr[SIZE/NO_OF_THREADS];
  for(int i=(SIZE/NO_OF_THREADS)+1;i<SIZE;i++){
    if(temp->max<=arr[i])
      temp->max=arr[i];
    if(temp->min > arr[i])
      temp->min=arr[i];
  }
pthread_exit((void*)temp);
}
int main(int argc, char const *argv[]) {
  pthread_t tid;
  pthread_attr_t attr;
  pthread_attr_init(&attr);
  time_t begin_t,end_t;
  begin_t=clock();
  srand(time(NULL));
  for(int i=0;i<SIZE;i++){
    arr[i]=rand();
  }
  v *temp_main,*temp_thread;
  temp_main=(v*)malloc(sizeof(v));
  temp_thread=(v*)malloc(sizeof(v));
 
  for(int i=1;i<NO_OF_THREADS;i++){
	pthread_create(&tid,&attr,&runner,NULL);
}	
for(int i=1;i<NO_OF_THREADS;i++){
	pthread_join(tid,(void**)&temp_thread);
  }
  temp_main->max=arr[0];
  temp_main->min=arr[0];
  for(int i=1;i<SIZE/NO_OF_THREADS;i++){
    if(arr[i]>=temp_main->max)
      temp_main->max=arr[i];
    if(arr[i]>temp_main->min)
      temp_main->min=arr[i];
  }
  if(temp_main->max <= temp_thread->max)
      temp_main->max=temp_thread->max;
  if (temp_main->min >= temp_thread->min) {
    temp_main->min=temp_thread->min;
  }
	end_t=clock();
  printf("Final MAX and MIN are: %d and %d \n",temp_main->max,temp_main->min);
printf("Time required for execution: %f\n",(double)(end_t-begin_t)/CLOCKS_PER_SEC);
  return 0;
}
/* Output:
Final MAX and MIN are: 2147475678 and 8334 
Time required for execution: 0.001788
*/
