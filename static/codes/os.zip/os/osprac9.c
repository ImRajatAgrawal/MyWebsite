//FIFO REPLACEMENT ALGORITHM
#include<stdio.h>
#define min -999
int main(){
	int f,i,n,k,j,flag,x,y;
	printf("\nFIFO REPLACEMENT ALGORITHM\n");
	printf("\nEnter the reference string length:");
	scanf("%d",&n);
	int arr[n];
	printf("\nEnter reference string:\n");
	for(i=0;i<n;i++)
		scanf("%d",&arr[i]);
	printf("\nEnter no of frames:");
	scanf("%d",&f);
	int frame[n*f],fault=0;
	for(i=0;i<n*f;i++)
		frame[i]=min;
	x=0;
	y=0;
	printf("frames are:\n");
	for(i=0;i<f;i++)
	printf("| %d ",i);
	printf("|\n------------------\n");
	for(j=0;j<n;j++){
		flag=0;
		for(k=0;k<f;k++){
			if(frame[0]==min)
				break;
			else if(arr[j]==frame[k]){
				flag=1;
				break;
			}	
		}
		if(flag==0){
			frame[x]=arr[j];
			y++;
			if(y<=f){
				for(i=0;i<y;i++)
					printf("| %d ",frame[i]);
				printf("|\n");	
			}
			else{
					for(i=0;i<f;i++)
						printf("| %d ",frame[i]);
					printf("|\n");			
			}		
			fault++;
			++x;
			if(x>=f)
				x=0;	
		}
		else{
				for(i=0;i<f;i++)
					printf("| %d ",frame[i]);
					printf("|:HIT");
				printf("\n");
		}
	
	}
	printf("\nNo of page faults:%d",fault);
	printf("\nNo of hits:%d",n-fault);
	double d= (double)(n-fault)/n;
	printf("\nHit ratio:%lf\n",d);
	return 0;
}
/*
OUTPUT:
FIFO REPLACEMENT ALGORITHM

Enter the reference string length:12

Enter reference string:
1 2 3 4 1 2 5 1 2 3 4 5

Enter no of frames:4
frames are:
| 0 | 1 | 2 | 3 |
------------------
| 1 |
| 1 | 2 |
| 1 | 2 | 3 |
| 1 | 2 | 3 | 4 |
| 1 | 2 | 3 | 4 |:HIT
| 1 | 2 | 3 | 4 |:HIT
| 5 | 2 | 3 | 4 |
| 5 | 1 | 3 | 4 |
| 5 | 1 | 2 | 4 |
| 5 | 1 | 2 | 3 |
| 4 | 1 | 2 | 3 |
| 4 | 5 | 2 | 3 |

No of page faults:10
No of hits:2
Hit ratio:0.166667
*/
