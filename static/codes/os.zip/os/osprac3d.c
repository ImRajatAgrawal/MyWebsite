//PROGRAM 6: C program to demonstrate Zombie Process.
#include<stdio.h>
#include<unistd.h>
int main(){
    int id;
    id=fork();
    if(id>0){
        printf("Parent will sleep\n");
        sleep(10);
    }
    if(id==0)
        printf("I am child\n");
return 0;
}
/*
OUTPUT:
Parent will sleep
I am child
*/
//PROGRAM 7: C PROGRAM TO DEMONSTRATE exec() SYSTEM CALL.
#include<stdio.h>
#include<unistd.h>
int main(){
	 execlp("cat","cat","rajat",(char *)0);
return 0;
}
/*
OUTPUT:
hello world thankyou
*/
//PROGRAM 8: Demonstrate execvp system call.
#include<stdio.h>
#include<fcntl.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/wait.h>
#define BUF_SIZE 100
void ChildProcess();
void ParentProcess();
void Child1Process();
int main(void){
	pid_t pid;
	pid=fork();
	if(pid==0)
		ChildProcess();
	else
		ParentProcess();
	return 0;
}

void ChildProcess(){
	int i;
	char *args[]={"cat","rajat",0};
	execvp("cat",args);
}
void ParentProcess(){
	int i,t;
	char b[BUF_SIZE];
	char buffer[5];
	int f1,f2,ret;
	pid_t pid1;	
	pid1=fork();
	if(pid1==0)
		Child1Process();
	else{	
		f1=open("rajat",O_RDONLY|O_CREAT,0777);
		if(f1==-1)
			write(1,"Error while opening file!!!!!!",36); 
		f2=open("f2",O_WRONLY|O_CREAT,0777);
		if(f2==-1)
			write(1,"Error while opening file!!!!!!",36); 
		else{
			do{
				ret=read(f1,buffer,sizeof(buffer));
				if(ret)
				ret=write(f2,buffer,sizeof(buffer));
		      }while(ret);
		}
		close(f1);
		close(f2);
	}
	i=wait(NULL);
	if(i!=-1)
		printf("PID=%d\n",i);
	i=wait(NULL);
	if(i!=-1)
		printf("PID=%d\n",i);
}

void Child1Process(){
	int i;
	long int sum=0;
	for(i=1;i<=1000;i++)
		sum+=i;
	printf("CHILD CALCULATED TOTAL=%ld\n",sum);
}
/*
OUTPUT:
CHILD CALCULATED TOTAL=500500
PID=3578
hello world thankyou
PID=3577
*/
