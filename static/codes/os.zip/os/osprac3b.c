//PROGRAM 3:To check for prime no and sort an array of elements
//			using fork() system call.
#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
int  main(){
	int pid,n,a[10],i,t,j,flag=0;
	pid=fork();
	printf("PID=%d\n",pid);
	if(pid==0){
		printf("Enter a number to check whether prime or not:");
		scanf("%d",&n);
		if(n==1)
				printf("number is prime");
		else{
			for(j=2;j<=(n/2);j++){
				if(n%j==0){
					flag=1;
					printf("not a prime number");
					break;
				}				
			
			}
				if(flag==0)
				printf("\nprime number");	
		}
	}
	 else{
		sleep(5);
		printf("\nEnter 10 numbers to sort:");
			for(j=0;j<10;j++)
			scanf("%d",&a[j]);
		for(i=0;i<9;i++){
			for(j=0;j<9-i;j++){
				if(a[j+1]<a[j]){
				t=a[j];
				a[j]=a[j+1];
			
				a[j+1]=t;
				}	
			}		
		}
	printf("SORTED ARRAY:\n");
	for(i=0;i<10;i++)
	printf("%d ",a[i]);
	}	
	printf("\n");
}		
/*
OUTPUT:
PID=2946
PID=0
Enter a number to check whether prime or not:17
prime number

Enter 10 numbers to sort: 99 88 77 55 66 44 33 22 11 12
SORTED ARRAY:
11 12 22 33 44 55 66 77 88 99 
*/
