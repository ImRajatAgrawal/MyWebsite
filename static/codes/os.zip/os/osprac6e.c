//6.POSIX semaphores system calls with shared memory.
#include<stdio.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<sys/sem.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<wait.h>
#include<semaphore.h>
sem_t mutex;
int main(int argc, char const *argv[]){
  int svalue=sem_init(&mutex,0,1);
  pid_t pid;
	int *count;
  int shmid=shmget(IPC_PRIVATE,4,IPC_CREAT|0666);
  if(shmid==-1){
    fprintf(stderr, "shm creation error\n");
    exit(1);
  }
  printf("shared memory created\n");
    count=(int*)shmat(shmid,NULL,0);
    *count=0;
    pid=fork();
    if(pid==0){
      printf("Child Process: pid %d and ppid %d\n\n",getpid(),getppid());
      for(int i=0;i<10;i++){
        	if(i%3==0)
          	sleep(1);
        	sem_wait(&mutex);
          printf("Child count: %d\n",++(*count));
        	sem_post(&mutex);
      }
    }
    else if(pid>0){
      printf("Parent process:pid %d\n\n",getpid());
      for(int i=0;i<5;i++){
        sleep(1);
        sem_wait(&mutex);
          printf("Parent count: %d\n",++(*count));
        sem_post(&mutex);
      }
      wait(NULL);
    }
  return 0;
}
/*shared memory created
Parent process:pid 5684
Child Process: pid 5685 and ppid 5684
Parent count: 1
Child count: 2
Child count: 3
Child count: 4
Parent count: 5
Child count: 6
Child count: 7
Child count: 8
Parent count: 9
Child count: 10
Child count: 11
Child count: 12
Parent count: 13
Child count: 14
Parent count: 15
*/
