#include<stdio.h>
#include<sys/types.h>
#include<fcntl.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<string.h>
#include<unistd.h>
int main(){
	char buffer[100],fname[25],data,temp[1024],*newline;
	int choice,f1,n,i;
	char t;
	struct stat sb;
	FILE *fp;
	do{
		printf("\n_________SYSTEM CALLS_______");
		printf("\n0.exit");
		printf("\n1.create a file       2.read ");
		printf("\n3.write               4.read in reverse order");
		printf("\n5.search 	      6.delete");
		printf("\n7.status using stat   8.status using fstat");
		printf("\nEnter operation to perform:");
		scanf("%d",&choice);
		switch(choice){
			case 0:
				printf("\nYou have opted to exit...\n");
				exit(0);
			case 1:
				printf("\nEnter name of file to create:");
				scanf("%s",fname);
				if((f1=creat(fname,0777))==-1){
					printf("\nfile cannot be created...");
					exit(1);
				}	
				else
					printf("\nFile created");
				printf("\nEnter data to write:");
				scanf("%c",&t);
				scanf("%[^\n]%*c",buffer);
				write(f1,buffer,strlen(buffer));
				close(f1);
				break;
			case 2:
					printf("\nEnter name of file to open:");
					scanf("%s",fname);
					f1=open(fname,O_RDONLY,0777);
					printf("\nFile opened");
					printf("\nThe contents of the file are: ");
					n=lseek(f1,0,2);
					lseek(f1,0,0);
					for(i=1;i<=n;i++){
						read(f1,&data,1);
						printf("%c",data);
					}
					close(f1);
					break;
			case 3:
					printf("\nEnter name of file to open:");
					scanf("%s",fname);
					f1=open(fname,O_WRONLY|O_APPEND,0777);
					printf("\nFile opened");
					printf("\nEnter data to write:");
					scanf("%c",&t);
					scanf("%[^\n]%*c",buffer);
					write(f1,buffer,strlen(buffer));
					close(f1);
					break;	
			case 4:
					printf("\nEnter name of file to open:");
					scanf("%s",fname);
					f1=open(fname,O_RDONLY,0);
					if(f1==-1){
						printf("\nFile cannot be opened");
					}
					else{
					printf("\nFile opened");
					printf("\nThe contents of the file in reverse order are: ");
					n=lseek(f1,0,2);
					lseek(f1,-1,2);
					while(n-->0){
						read(f1,&data,1);
						printf("%c",data);
						lseek(f1,-2,1);
					}
					}
					close(f1);
					break;
			case 5:
					printf("\nEnter name of file to open:");
					scanf("%s",fname);
					fp=fopen(fname,"r");
					printf("\nFile opened");
					printf("\nEnter pattern to search:");
					scanf("%s",buffer);
					while(fgets(temp,1000,fp)!=NULL){
						if(newline=strstr(temp,"\n"))
							*newline='\0';
						if(strstr(temp,buffer)!=NULL)
							printf("%s\n",temp);	
					}
					fclose(fp);
					break;
		case 6:
				printf("\nEnter filename to delete:");
				scanf("%s",fname);
				if(unlink(fname)==-1)
					printf("\nFile cannot be deleted");
				else{
					printf("\nFile deleted");	
				f1=open(fname,O_RDONLY,0);
					if(f1==-1){
						printf("\nFile cannot be opened as it does not exist...\n");
					}
				}
				close(f1);
				break;
		case 7:
				printf("\nEnter file name whose status you want to print:");
				scanf("%s",fname);
				if(stat(fname,&sb)==-1){
					perror("stat");
					exit(1);
				}
				printf("\nFILE: %s",fname);
				printf("\nSTATUS: ");
				if((sb.st_mode & S_IFMT)==S_IFDIR)
					printf("DIRECTORY\n");
				else if((sb.st_mode & S_IFMT)==S_IFBLK)
					printf("BLOCK SPECIAL FILE\n");
				else if((sb.st_mode & S_IFMT)==S_IFCHR)
					printf("CHARACTER SPECIAL FILE\n");
				else if((sb.st_mode & S_IFMT)==S_IFREG)
					printf("REGULAR FILE\n");
				else if((sb.st_mode & S_IFMT)==S_IFIFO)
					printf("FIFO\n");
				 printf("Resides on device:%d,%ld\n", (sb.st_dev > 8) & 0377,sb.st_dev & 0377);
				printf("I-node: %ld; Links: %ld; Size: %ld  bytes\n", sb.st_ino,sb.st_nlink, sb.st_size);
				if ((sb.st_mode & S_ISUID) == S_ISUID)
				   printf("Set-user-ID\n");
				if ((sb.st_mode & S_ISGID) == S_ISGID)
				   printf("Set-group-ID\n");
				if ((sb.st_mode & S_ISVTX) == S_ISVTX)
				   printf("Sticky-bit set -- save swapped text after use\n");  
				printf("PERMISSIONS: %o\n",sb.st_mode & 0777);			
				break;
		case 8:
				printf("\nEnter file name whose status you want to print:");
				scanf("%s",fname);
				f1=open(fname,O_RDONLY,0777);
				if(fstat(f1,&sb)==-1){
					perror("fstat");
					close(f1);
					exit(1);
				}
				n=lseek(f1,0,2);
				switch(sb.st_mode & S_IFMT){
					case S_IFBLK: printf("Block file");
					case S_IFCHR: printf("character special file");
					case S_IFDIR: printf("directory");
					case S_IFIFO: printf("FIFO");
					case S_IFREG: printf("regular file");
				}
				printf("\nSIZE: %d bytes",n);
				printf("\nLast modified time:%ld seconds",sb.st_mtime);
				printf("\nLast access time:%ld seconds",sb.st_atime);
				printf("\nfile serial number:%ld",sb.st_ino);
				close(f1);
				break;
		}	
	}while(choice>0);
return 0;
}
/*
OUTPUT:
_________SYSTEM CALLS_______
0.exit
1.create a file       2.read 
3.write               4.read in reverse order
5.search 	      6.delete
7.status using stat   8.status using fstat
Enter operation to perform:1

Enter name of file to create:rajat

File created
Enter data to write:hello world

_________SYSTEM CALLS_______
0.exit
1.create a file       2.read 
3.write               4.read in reverse order
5.search 	      6.delete
7.status using stat   8.status using fstat
Enter operation to perform:2

Enter name of file to open:rajat

File opened
The contents of the file are: hello world
_________SYSTEM CALLS_______
0.exit
1.create a file       2.read 
3.write               4.read in reverse order
5.search 	      6.delete
7.status using stat   8.status using fstat
Enter operation to perform:3

Enter name of file to open:rajat

File opened
Enter data to write:  welcome

_________SYSTEM CALLS_______
0.exit
1.create a file       2.read 
3.write               4.read in reverse order
5.search 	      6.delete
7.status using stat   8.status using fstat
Enter operation to perform:4

Enter name of file to open:rajat

File opened
The contents of the file in reverse order are: emoclew dlrow olleh
_________SYSTEM CALLS_______
0.exit
1.create a file       2.read 
3.write               4.read in reverse order
5.search 	      6.delete
7.status using stat   8.status using fstat
Enter operation to perform:5

Enter name of file to open:rajat

File opened
Enter pattern to search:hello
hello world welcome

_________SYSTEM CALLS_______
0.exit
1.create a file       2.read 
3.write               4.read in reverse order
5.search 	      6.delete
7.status using stat   8.status using fstat
Enter operation to perform:7

Enter file name whose status you want to print:rajat

FILE: rajat
STATUS: REGULAR FILE
Resides on device:1,10
I-node: 151843; Links: 1; Size: 19  bytes
PERMISSIONS: 755

_________SYSTEM CALLS_______
0.exit
1.create a file       2.read 
3.write               4.read in reverse order
5.search 	      6.delete
7.status using stat   8.status using fstat
Enter operation to perform:8

Enter file name whose status you want to print:rajat
regular file
SIZE: 19 bytes
Last modified time:1516287591 seconds
Last access time:1516287597 seconds
file serial number:151843
_________SYSTEM CALLS_______
0.exit
1.create a file       2.read 
3.write               4.read in reverse order
5.search 	      6.delete
7.status using stat   8.status using fstat
Enter operation to perform:6

Enter filename to delete:rajat

File deleted
File cannot be opened as it does not exist...

_________SYSTEM CALLS_______
0.exit
1.create a file       2.read 
3.write               4.read in reverse order
5.search 	      6.delete
7.status using stat   8.status using fstat
Enter operation to perform:0

You have opted to exit...
*/
