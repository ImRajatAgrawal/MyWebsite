/*2.TO calulate the MAX and MIN of array using shared memory*/
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <stdlib.h>
#include<wait.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<unistd.h>
#include <time.h>

#define SHMSZ 50
#define SIZE 100000
int main(int argc, char const *argv[]) {

	int shm_id;
	int arr[SIZE];
  srand(time(NULL));
	for(int i=0;i<SIZE;i++){
		arr[i]=rand()%10000;
	}
	pid_t pid;
  time_t begin,end;
	int i;
  begin=clock();
	shm_id=shmget(IPC_PRIVATE,2,IPC_CREAT|0666);
	if(shm_id<0){
		printf("Shm Not created\n");
		exit(0);
	}
	printf("Shared Memory Created with ID %u\n",shm_id);

	int *minmax=(int*)shmat(shm_id,NULL,0);
  minmax[0]=arr[0]; 
  minmax[1]=arr[0];
  pid=fork();
  if(pid==0){
    printf("Child process:PID %d and PPID %d \n",getpid(),getppid());
    for(int i=1;i<SIZE/2;i++){
        if(arr[i]>minmax[0])
          minmax[0]=arr[i];
        if(arr[i]<minmax[1])
          minmax[1]=arr[i];
    }

  }
  else if(pid>0){
    printf("Parent process:PID %d\n",getpid());
    for(int i=(SIZE/2)+1;i<SIZE;i++){
      if(arr[i]>minmax[0])
        minmax[0]=arr[i];
      if(arr[i]<minmax[1])
        minmax[1]=arr[i];
    }
    int err=wait(NULL);
    printf("Max value = %d and Min value = %d\n",minmax[0],minmax[1]);
    end=clock();
    double time_elapsed=(double)(end-begin)/CLOCKS_PER_SEC;
    printf("\nTime for execution is %f seconds\n",time_elapsed);
    shmdt(minmax);
  }
  return 0;
}
/* Output:
Shared Memory Created with ID 13107223
Parent process:PID 3522
Child process:PID 3523 and PPID 3522 
Max value = 9999 and Min value = 0

Time for execution is 0.000502 seconds
*/
