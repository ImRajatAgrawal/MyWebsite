//2.Producer consumer with synchronization using mutex and condition variable.
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include<unistd.h>
#define BufferSize 10

void *Producer();
void *Consumer();

int BufferIndex=-1;
char BUFFER[10];

pthread_cond_t Buffer_Empty=PTHREAD_COND_INITIALIZER;
pthread_cond_t Buffer_Full=PTHREAD_COND_INITIALIZER;
pthread_mutex_t mVar=PTHREAD_MUTEX_INITIALIZER;

int main(){    
    pthread_t ptid,ctid;
    pthread_create(&ptid,NULL,Producer,NULL);
    pthread_create(&ctid,NULL,Consumer,NULL);
  
    pthread_join(ptid,NULL);
    pthread_join(ctid,NULL);
    return 0;
}
void *Producer(void *arg){    
	int i;
    for(i=0; i<15; i++){
    //sleep(1);
        pthread_mutex_lock(&mVar);
        if(BufferIndex==BufferSize-1){
        	printf("Producer waits as buffer is full\n");                       
            pthread_cond_wait(&Buffer_Empty,&mVar);
           } 
        BUFFER[++BufferIndex]='#';
        printf("Produce : %d %s\n",BufferIndex,BUFFER);
        pthread_mutex_unlock(&mVar);
        pthread_cond_signal(&Buffer_Full); 
	    
    }
}
void *Consumer(){
	int i;
    for(i=0; i<15 ; i++){
    	//sleep(1); 
        pthread_mutex_lock(&mVar);
        if(BufferIndex==-1){
        	printf("Consumer waits\n");           
            pthread_cond_wait(&Buffer_Full,&mVar);
           } 
            BUFFER[BufferIndex]=' ';
		printf("Consume : %d %s\n",BufferIndex--,BUFFER);        
        pthread_mutex_unlock(&mVar);       
        pthread_cond_signal(&Buffer_Empty);              
    }
}
/*
OUTPUT:
Produce : 0 #
Produce : 1 ##
Produce : 2 ###
Produce : 3 ####
Produce : 4 #####
Produce : 5 ######
Consume : 5 ##### 
Consume : 4 ####  
Consume : 3 ###   
Consume : 2 ##    
Consume : 1 #     
Consume : 0       
Consumer waits
Produce : 0 #     
Produce : 1 ##    
Produce : 2 ###   
Produce : 3 ####  
Produce : 4 ##### 
Produce : 5 ######
Produce : 6 #######
Produce : 7 ########
Produce : 8 #########
Consume : 8 ######## 
Consume : 7 #######  
Consume : 6 ######   
Consume : 5 #####    
Consume : 4 ####     
Consume : 3 ###      
Consume : 2 ##       
Consume : 1 #        
Consume : 0          
*/
