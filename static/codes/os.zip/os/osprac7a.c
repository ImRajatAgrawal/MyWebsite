//DEADLOCK AVOIDANCE AND RESOURCE REQUEST ALGORITHM
#include<stdio.h>
#include<stdlib.h>
int equal(int visited[],int check[],int n){
	for(int i=0;i<n;i++){
		if(visited[i]==check[i])
			continue;
		else
			return 0;	
	}
	return 1;		
}
int main(){
	int n,m,i,j,flag=0,c,k,t,r,flag1,ct,id,y,f,flag2=0;
	printf("\nEnter the no of processes:");
	scanf("%d",&n);
	printf("Enter no of resource types:");
	scanf("%d",&m);
	int allocation[n][m],available[m],request[m],need[n][m];
	int finish[n],count,visited[n+1],check[n+1],work[m],max[n][m];
	printf("Enter allocation matrix:\n");
	for(i=0;i<n;i++){
	printf("P%d: ",i);
		for(j=0;j<m;j++){
			scanf("%d",&allocation[i][j]);
		}
			finish[i]=0;
			visited[i]=0;
	}
	printf("Enter max matrix:\n");
	for(i=0;i<n;i++){
	printf("P%d: ",i);
		for(j=0;j<m;j++){
			scanf("%d",&max[i][j]);
			need[i][j]=max[i][j]-allocation[i][j];
		}
	}
	printf("Enter available matrix:");
	for(i=0;i<m;i++){
			scanf("%d",&available[i]);
			work[i]=available[i];
	}
	label:
	printf("\nNeed matrix is:\n");
	for(i=0;i<n;i++){
		for(j=0;j<m;j++)
			printf("%d ",need[i][j]);
		printf("\n");	
	}

	ct=0;
	flag1=1;
	for(i=0;i<n;i++){
		if(flag1==1){
			flag1=0;
		for(j=0;j<n;j++){
		count=0;
			for(k=0;k<m;k++){
				if(finish[j]==0){
					if(need[j][k]<=work[k])
						++count;
					else
						break;	
				}
			}
			if(count==m && finish[j]==0){
				finish[j]=1;
				visited[ct]=j;
				++ct;
				flag1=1;
				for(t=0;t<m;t++){
						work[t]+=allocation[j][t];
				}
			}
			
		}
	}
	else
		break;	
	}
	flag=0;
	for(i=0;i<n;i++){
		if(finish[i]==0){
			flag=1;
			printf("\nThe system is not in safe state\n");
			break;
		}
	}
	if(flag==0){
		if(flag2==1){
			if(!equal(visited,check,n)){
				printf("\nNo deadlock but system is not in safe state\n");
				exit(0);
			}	
		}
		printf("\nThe system is in safe state\n");
		printf("The safe sequence is:\n");
		printf("< ");
		for(i=0;i<n;i++)
			printf("P%d ",visited[i]);
		printf(">\n");
		x:
		printf("\nWhether a process wants to request additional instances of resources[1-yes| 0-no]:");
		scanf("%d",&y);
		if(y==1){
			flag2=0;
		printf("Enter the process which wants to request for an additional resource:P");
		scanf("%d",&id);	
		printf("Enter request of process P%d :",id);
		f=0;
		c=0;
		for(i=0;i<m;i++){
			scanf("%d",&request[i]);
			if(request[i]<=need[id][i]){
				c++;
				if(request[i]<=available[i]){
					continue;
				}
				else
					f=1;
			}
		}
		if(c!=m){		
			printf("\nError: Max claim exceeded...");
			goto x;
		}	
		else if(f==1){
			printf("\nProcess p%d must wait since the resources are not available",id);
			goto x;
		}	
		else{
				for(i=0;i<m;i++){
					available[i]-=request[i];
					allocation[id][i]+=request[i];
					need[id][i]-=request[i];
					work[i]=available[i];
				}
				for(i=0;i<n;i++){
					finish[i]=0;
						check[i]=visited[i];
					}
				printf("\nThe request for resources is granted");
				flag2=1;
				goto label;
		 }		
	 }	
 }
	return 0;
}
/*
OUTPUT:
Enter the no of processes:5
Enter no of resource types:3
Enter allocation matrix:
P0: 0 1 0
P1: 2 0 0
P2: 3 0 2
P3: 2 1 1
P4: 0 0 2
Enter max matrix:
P0: 7 5 3
P1: 3 2 2
P2: 9 0 2
P3: 2 2 2
P4: 4 3 3
Enter available matrix:3 3 2

Need matrix is:
7 4 3 
1 2 2 
6 0 0 
0 1 1 
4 3 1 

The system is in safe state
The safe sequence is:
< P1 P3 P4 P0 P2 >

Whether a process wants to request additional instances of resources[1-yes| 0-no]:1
Enter the process which wants to request for an additional resource:P1
Enter request of process P1 :1 0 2

The request for resources is granted
Need matrix is:
7 4 3 
0 2 0 
6 0 0 
0 1 1 
4 3 1 

The system is in safe state
The safe sequence is:
< P1 P3 P4 P0 P2 >

Whether a process wants to request additional instances of resources[1-yes| 0-no]:1
Enter the process which wants to request for an additional resource:P0
Enter request of process P0 :3 0 2

Process p0 must wait since the resources are not available
Whether a process wants to request additional instances of resources[1-yes| 0-no]:1
Enter the process which wants to request for an additional resource:P4
Enter request of process P4 :0 2 0

The request for resources is granted
Need matrix is:
7 4 3 
0 2 0 
6 0 0 
0 1 1 
4 1 1 

The system is not in safe state
*/
