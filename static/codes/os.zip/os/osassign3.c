//2.INTERPROCESS COMMUNICATION USING MESSAGE QUEUES. 
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include<time.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<math.h>
typedef struct{
	long mtype;
	int arr[100];
	int len;
}queue;
void shell_sort(int arr[],int length);
int main(){
	int i,j,msgid,pid;
	queue q;
	key_t key;
	key=1234;
	msgid=msgget(key,IPC_CREAT|0666);
	if(msgid==-1){
		fprintf(stderr,"queue creation error\n");
		exit(1);
	}
	printf("\nMessage queue created");
	printf("\nMessage id:%d",msgid);
	q.mtype=1;
	printf("\nEnter size of array:");
	scanf("%d",&(q.len));
		printf("\nSender Process");
		srand(time(NULL));
		for(i=0;i<q.len;i++){
			q.arr[i]=rand()%2500;
		}
		shell_sort(q.arr,q.len);
		if(msgsnd(msgid, &q, sizeof(q), 0)==-1){
			perror("msgsnd");
			exit(1);
		};
		printf("\nArray send to reciever process\n");
	return 0;
}
void shell_sort(int arr[],int length){
    int i,gap,j,key;
	for(gap=(length/2)-1;gap>0;gap/=2){
	    for(i=gap;i<=length-1;i++){
	        key=arr[i];
	        for(j=i;j>=gap && arr[j-gap]>key;j-=gap)
	            arr[j]=arr[j-gap];
	        arr[j]=key;
	    }
	}
}      
/*
OUTPUT:
Message queue created
Message id:32768
Enter size of array:10

Sender Process
Array send to reciever process
*/
