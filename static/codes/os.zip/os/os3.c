/*c program to copy the contents of an existing file
 into another file with input of file names from the command line*/
#include<stdio.h>
#include<sys/types.h>
#include<fcntl.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<string.h>
#include<sys/uio.h>
#include<unistd.h>
int main(int argc,char *argv[]){
	int f,t,nr,nw,n;
	char buff[512];
	if((f=open(argv[1],O_RDONLY,0777))<0){
		perror("error opening source file");
		exit(1);
	}
	if((t=creat(argv[2],0666))<0){
		perror("error creating file");
		exit(1);
	}
	while((nr=read(f,buff,sizeof(buff)))!=0){
		if(nr<0){
			perror("error reading source file");
			exit(3);
		}
		nw=0;
		do{
			if((n=write(t,&buff[nw],nr-nw))<0){
				perror("error writing file");
				exit(4);	
			}
			nw+=n;
		}while(nw<nr);
	}	
		close(f);
		close(t);
		
	return 0;
}
/*
OUTPUT:
cat rajat
hello world thankyou
rajat@rajat-HP-Pavilion-15-NoteBook-PC:~$ gcc os3.c
rajat@rajat-HP-Pavilion-15-NoteBook-PC:~$ ./a.out rajat os
rajat@rajat-HP-Pavilion-15-NoteBook-PC:~$ cat os
hello world thankyou

*/
