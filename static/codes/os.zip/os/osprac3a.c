//PROGRAM 1:example of fork
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
int main(){
   printf("Hello \n");
   fork();
   printf("bye\n");
   return 0;
}
/*
OUTPUT:
Hello 
bye
bye
*/

//PROGRAM 2: demonstrate use of fork() system call 
#include <stdio.h>
#include <unistd.h>
int main(){
    int id;
    printf("Hello, World!\n");
    id=fork();
    if(id>0){
        //parent process
        printf("This is parent section [Process id: %d].\n",getpid());
    }
    else if(id==0){
        //child process
        printf("fork created [Process id: %d].\n",getpid());
        printf("fork parent process id: %d.\n",getppid());
    }
    else{
        //fork creation failed
        printf("fork creation failed!!!\n");
    }
    return 0;
}
/*
OUTPUT:
Hello, World!
This is parent section [Process id: 2813].
fork created [Process id: 2814].
fork parent process id: 2813.
*/
