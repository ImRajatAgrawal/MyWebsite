//To demonstrate disk scheduling algorithms using c programs.
#include<stdio.h>
#include<stdlib.h>
#include <limits.h>
#define LEFT 1
#define RIGHT 2

void copyarr(int arr[],int cpy[],int length){  
   int i;
    for(i=0;i<length;i++)
       cpy[i]=arr[i];   
}
void shell_sort(int a[],int len){
    int gap,i,key,j;
    for(gap=len/2;gap>0;gap/=2){
	  for(i=gap;i<len;i++){
	      key=a[i];
	      for(j=i;j>=gap && a[j-gap]>key;j-=gap)
	          a[j]=a[j-gap];
	      a[j]=key;
	  }
    }
}

void fcfs(int arr[],int nreq,int head_start,int total_hm){
  printf("\nStepwise head movement is:\n");
  printf("[%d]",head_start);
  for(int i=0;i<nreq;i++){
      printf(" -> [%d]",arr[i]);
      total_hm+=(abs(head_start-arr[i]));
      head_start=arr[i];
  }
  printf("\n\n Total head movement= %d\n",total_hm);
}

void sstf(int arr[],int nreq,int head_start,int total_hm){
	arr[nreq]=head_start;
    int visited_sstf[nreq+3];
     for(int i=0;i<nreq+3;i++)
        visited_sstf[i]=0;

    int size=nreq+1;
    shell_sort(arr,size);
    int pos=-1;
    for(int i=0;i<size;i++){
      if(arr[i]==head_start){
        pos=i;
        break;
      }
    }
    printf("\nStepwise head movement is:\n");   
	printf("[%d]",arr[pos]);
    visited_sstf[pos]=1;    
    for(int i=0;i<size-1;i++){
        int d_left=INT_MAX,d_right=INT_MAX;
        int pos_left=-1,pos_right=-1;
        
        for(int i=pos-1;i>=0;i--){
          if(visited_sstf[i]==0){
            int diff=abs(arr[pos]-arr[i]);
            if(diff<d_left){
              d_left=diff;
              pos_left=i;
            }
            break;
          }
        }
        
        for(int i=pos+1;i<size;i++){
          if(visited_sstf[i]==0){
            int diff=abs(arr[pos]-arr[i]);
            if(diff<d_right){
              d_right=diff;
              pos_right=i;
            }

            break;
          }
        }

        int position=-1;
        if(d_left<d_right)
            position=pos_left;
        else
          position=pos_right;
        total_hm+=(abs(arr[pos]-arr[position]));
        printf(" -> [%d]",arr[position]);
        visited_sstf[position]=1;
        pos=position;
    }
    printf("\n\nTotal head movement: %d\n",total_hm);
}

void scan(int arr[],int nreq,int head_start,int total_hm,int nc,int direction){
  arr[nreq]=head_start;
  arr[nreq+1]=0;
  arr[nreq+2]=nc-1;
  int visited_sstf[nreq+3];
    for(int i=0;i<nreq+3;i++)
      visited_sstf[i]=0;

  int size=nreq+3; 
  shell_sort(arr,size);
  int pos=-1;
  for(int i=0;i<size;i++){
    if(arr[i]==head_start){
      pos=i;
      break;
    }
  }

  printf("Stepwise head movement is: \n");
    printf("[%d]",arr[pos]);
    if(direction==LEFT){

        for(int i=pos-1;i>=0;i--){
            printf(" -> [%d]",arr[i]);
            total_hm+=(arr[i+1]-arr[i]);
        }
        int right_distance=arr[pos]-0; 
        total_hm+=(right_distance);
        for(int i=pos+1;i<size;i++){
          if(arr[i]==(nc-1)) 
            break;
          printf(" -> [%d]",arr[i]);
          total_hm+=(arr[i]-arr[i-1]);
        }
    }

    else{
      for(int i=pos+1;i<size;i++){
        printf(" -> [%d]",arr[i]);
        total_hm+=(arr[i]-arr[i-1]);
      }

      int left_distance=(nc-1)-arr[pos];
      total_hm+=(left_distance);
      for(int i=pos-1;i>=0;i--){
        if(arr[i]==0)
          break;
          printf(" -> [%d]",arr[i]);
          total_hm+=(arr[i+1]-arr[i]);

      }
    }

    printf("\n\nTotal head movement: %d\n",total_hm);

}

void cscan(int arr[],int nreq,int head_start,int total_hm,int nc,int direction){
  arr[nreq]=head_start;
  arr[nreq+1]=0;
  arr[nreq+2]=nc-1;
  int visited_sstf[nreq+3];
    for(int i=0;i<nreq+3;i++)
      visited_sstf[i]=0;

  int size=nreq+3; 
  shell_sort(arr,size);
  int pos=-1;
  for(int i=0;i<size;i++){
    if(arr[i]==head_start){
      pos=i;
      break;
    }
  }

  printf("Stepwise head movement is: \n");
    printf("[%d]",arr[pos]);
    if(direction==LEFT){
        for(int i=pos-1;i>=0;i--){
            printf(" -> [%d]",arr[i]);
            total_hm+=(arr[i+1]-arr[i]);
        }
        int right_distance=(nc-1)-(0); 
        total_hm+=(right_distance);
        for(int i=size-1;i>pos+1;i--){
          printf(" -> [%d]",arr[i]);
          total_hm+=(arr[i]-arr[i-1]);
        }
    }

    else{
      for(int i=pos+1;i<size;i++){
        printf(" -> [%d]",arr[i]);
        total_hm+=(arr[i]-arr[i-1]);
      }

      int left_distance=(nc-1)-0;
      total_hm+=(left_distance);
      for(int i=0;i<pos;i++){
          printf(" -> [%d]",arr[i]);
          if(i!=pos-1)         
            total_hm+=(arr[i+1]-arr[i]);
      }
    }
    printf("\n\nTotal head movement: %d\n",total_hm);
}

void look(int arr[],int nreq,int head_start,int total_hm,int nc,int direction){
  arr[nreq]=head_start;
  arr[nreq+1]=0;
  arr[nreq+2]=nc-1;
  int visited_sstf[nreq+3];
    for(int i=0;i<nreq+3;i++)
      visited_sstf[i]=0;

  int size=nreq+3; 
  shell_sort(arr,size);
  int pos=-1;
  for(int i=0;i<size;i++){
    if(arr[i]==head_start){
      pos=i;
      break;
    }
  }

  printf("\nStepwise head movement is: \n");
    printf("[%d]",arr[pos]);
    if(direction==LEFT){
        for(int i=pos-1;i>=0;i--){
          if(arr[i]==0)
            break;
            printf(" -> [%d]",arr[i]);
            total_hm+=(arr[i+1]-arr[i]);
        }
        int right_distance=arr[pos]-arr[1]; 
        total_hm+=(right_distance);
        for(int i=pos+1;i<size;i++){
          if(arr[i]==(nc-1)) 
            break;
          printf(" -> [%d]",arr[i]);
          total_hm+=(arr[i]-arr[i-1]);         
        }
    }

    else{
      for(int i=pos+1;i<size;i++){
        if(arr[i]==(nc-1))
          break;
        printf(" -> [%d]",arr[i]);
        total_hm+=(arr[i]-arr[i-1]);
      }

      int left_distance=(arr[size-2])-arr[pos];
      total_hm+=(left_distance);
      for(int i=pos-1;i>=0;i--){
        if(arr[i]==0)
          break;
          printf(" -> [%d]",arr[i]);
          total_hm+=(arr[i+1]-arr[i]);
      }
    }
    printf("\n\nTotal head movement: %d\n",total_hm);

}

void clook(int arr[],int nreq,int head_start,int total_hm,int nc,int direction){
  arr[nreq]=head_start;
  arr[nreq+1]=0;
  arr[nreq+2]=nc-1;
  int visited_sstf[nreq+3];
    for(int i=0;i<nreq+3;i++)
      visited_sstf[i]=0;

  int size=nreq+3; 
  shell_sort(arr,size);
  int pos=-1;
  for(int i=0;i<size;i++){
    if(arr[i]==head_start){
      pos=i;
      break;
    }
  }

  printf("\nstepwise head movement : \n");
    printf("[%d]",arr[pos]);
    if(direction==LEFT){

        for(int i=pos-1;i>=0;i--){
          if(arr[i]==0)
            break;
            printf(" -> [%d]",arr[i]);
            total_hm+=(arr[i+1]-arr[i]);
        }
        int right_distance=arr[size-2]-arr[1];
        total_hm+=(right_distance);
        for(int i=size-2;i>pos;i--){

          printf(" -> [%d]",arr[i]);
          if(i!=pos+1){
            total_hm+=(arr[i]-arr[i-1]);
          }

        }
    }

    else{
      for(int i=pos+1;i<size;i++){
        if(arr[i]==(nc-1))
          break;
        printf(" -> [%d]",arr[i]);
        total_hm+=(arr[i]-arr[i-1]);
      }

      int left_distance=(arr[size-2])-arr[1];
      total_hm+=(left_distance);
      for(int i=1;i<pos;i++){
      printf(" -> [%d]",arr[i]);
          if(i!=(pos-1)){
            total_hm+=(arr[i+1]-arr[i]);
          }


      }
    }

    printf("\n\nTotal head movement: %d\n",total_hm);

}
int main() {
  int nc,choice,head_previous,head_start,nreq;
  printf("\nEnter the no of cylinders: ");
  scanf("%d",&nc);
  printf("\nEnter the Current Head Position: ");
  scanf("%d",&head_start);
  printf("\nEnter the Previous request Position:");
  scanf("%d",&head_previous);
  int direction;
  if(head_start<head_previous)
    direction=LEFT;
  else
    direction=RIGHT;

  printf("\nEnter the no of Requests: ");
  scanf("%d",&nreq);
  int *arr,*cpy;
	arr = (int *)calloc(nreq+3,sizeof(int));
    cpy = (int *)calloc(nreq+3,sizeof(int));
    
  printf("Enter the Request order: \n");
  for(int i=0;i<nreq;i++){
    scanf("%d",&arr[i] );

  }
  int total_hm=0;
	do{

		printf("\n-------------------Available Scheduling ALGORITHMS------------------\n");
		printf("0.exit    1.fcfs   2.sstf   3.scan\n");
		printf("4.cscan   5.look   6.clook\n ");
		printf("\nEnter your choice: ");
		int choice;
		scanf("%d",&choice);
		switch (choice) {
			case 0:
					printf("\nYou have opted to exit...\n");
					exit(0);
			case 1:
					copyarr(arr,cpy,nreq);	 
					fcfs(cpy,nreq,head_start,total_hm);
							break;
			case 2: 
					copyarr(arr,cpy,nreq);
					sstf(cpy,nreq,head_start,total_hm);
							break;
			case 3:
						copyarr(arr,cpy,nreq);					
					 scan(cpy,nreq,head_start,total_hm,nc,direction);
							break;
			case 4: 
					copyarr(arr,cpy,nreq);
					cscan(cpy,nreq,head_start,total_hm,nc,direction);
							break;
			case 5: 
					copyarr(arr,cpy,nreq);
					look(cpy,nreq,head_start,total_hm,nc,direction);
							break;
			case 6:  
					copyarr(arr,cpy,nreq);
					clook(cpy,nreq,head_start,total_hm,nc,direction);
							break;

		}
	}while(choice>0);

  return 0;
}

/*
Enter the no of cylinders: 200

Enter the Current Head Position: 53

Enter the Previous request Position:90

Enter the no of Requests: 8
Enter the Request order: 
98 183 37 122 14 124 65 67

-------------------Available Scheduling ALGORITHMS------------------
0.exit    1.fcfs   2.sstf   3.scan
4.cscan   5.look   6.clook
 
Enter your choice: 1

Stepwise head movement is:
[53] -> [98] -> [183] -> [37] -> [122] -> [14] -> [124] -> [65] -> [67]

 Total head movement= 640

-------------------Available Scheduling ALGORITHMS------------------
0.exit    1.fcfs   2.sstf   3.scan
4.cscan   5.look   6.clook
 
Enter your choice: 2

Stepwise head movement is:
[53] -> [65] -> [67] -> [37] -> [14] -> [98] -> [122] -> [124] -> [183]

Total head movement: 236

-------------------Available Scheduling ALGORITHMS------------------
0.exit    1.fcfs   2.sstf   3.scan
4.cscan   5.look   6.clook
 
Enter your choice: 3
Stepwise head movement is: 
[53] -> [37] -> [14] -> [0] -> [65] -> [67] -> [98] -> [122] -> [124] -> [183]

Total head movement: 236

-------------------Available Scheduling ALGORITHMS------------------
0.exit    1.fcfs   2.sstf   3.scan
4.cscan   5.look   6.clook
 
Enter your choice: 4
Stepwise head movement is: 
[53] -> [37] -> [14] -> [0] -> [199] -> [183] -> [124] -> [122] -> [98] -> [67]

Total head movement: 386

-------------------Available Scheduling ALGORITHMS------------------
0.exit    1.fcfs   2.sstf   3.scan
4.cscan   5.look   6.clook
 
Enter your choice: 5

Stepwise head movement is: 
[53] -> [37] -> [14] -> [65] -> [67] -> [98] -> [122] -> [124] -> [183]

Total head movement: 208

-------------------Available Scheduling ALGORITHMS------------------
0.exit    1.fcfs   2.sstf   3.scan
4.cscan   5.look   6.clook
 
Enter your choice: 6

stepwise head movement : 
[53] -> [37] -> [14] -> [183] -> [124] -> [122] -> [98] -> [67] -> [65]

Total head movement: 326

-------------------Available Scheduling ALGORITHMS------------------
0.exit    1.fcfs   2.sstf   3.scan
4.cscan   5.look   6.clook
 
Enter your choice: 0

You have opted to exit...
*/
