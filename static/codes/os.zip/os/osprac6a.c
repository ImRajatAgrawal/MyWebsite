//3.PRODUCER CONSUMER WITH SYNCHRONIZATION USING SEMAPHORES.
#include<stdio.h>
#include<semaphore.h>
#include<pthread.h>
#include<stdlib.h>
#define buffersize 10
pthread_mutex_t mutex;
pthread_t tidP[20],tidC[20];
sem_t full,empty;
int counter;
int buffer[buffersize];
void initialize(){
	pthread_mutex_init(&mutex,NULL);
	sem_init(&full,1,0);
	sem_init(&empty,1,buffersize);
	counter=0;
}
void * producer (void * param){
	int item;
	item=rand()%5;
	sem_wait(&empty);
	pthread_mutex_lock(&mutex);
	printf("\nProducer has produced item: %d\n",item);
	buffer[counter++]=item;
	pthread_mutex_unlock(&mutex);
	sem_post(&full);
}
void * consumer (void * param){
	int item;
	sem_wait(&full);
	pthread_mutex_lock(&mutex);
	item=buffer[--counter];
	printf("\nConsumer has consumed item: %d\n",item);
	pthread_mutex_unlock(&mutex);
	sem_post(&empty);
}

int main(){
	int n1,n2,i;
	initialize();
	printf("\nEnter the no of producers: ");
	scanf("%d",&n1);
	printf("\nEnter the no of consumers: ");
	scanf("%d",&n2);
	for(i=0;i<n1;i++)
		pthread_create(&tidP[i],NULL,producer,NULL);
	for(i=0;i<n2;i++)
		pthread_create(&tidC[i],NULL,consumer,NULL);
	for(i=0;i<n1;i++)
		pthread_join(tidP[i],NULL);
	for(i=0;i<n2;i++)
		pthread_join(tidC[i],NULL);
	exit(0);
}
/*
OUTPUT:
Enter the no of producers: 4
Enter the no of consumers: 3
Producer has produced item: 3
Producer has produced item: 1
Producer has produced item: 2
Producer has produced item: 0
Consumer has consumed item: 0
Consumer has consumed item: 2
Consumer has consumed item: 1
*/
