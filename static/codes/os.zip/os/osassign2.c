//1.Interprocess communication using pipes.
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<string.h>
#include<sys/wait.h>
int main(){
	pid_t pid;
	int f1=0,f2=1,f3,i,n,fd[2],j,k;
	if(pipe(fd)<0){
		fprintf(stderr,"pipe error\n");
		exit(1);
	}
	printf("\nEnter limit for fibonacci series:");
	scanf("%d",&n);
	int *arr=(int*)malloc(n*sizeof(int));
	int *brr=(int*)malloc(n*sizeof(int));
	int o[n],e[n];
	arr[0]=f1;
	arr[1]=f2;
	pid=fork();
	if(pid==0){
		printf("\nChild process:pid=%d ppid=%d",getpid(),getppid());
		for(i=2;i<n;i++){
			f3=f1+f2;
			f1=f2;
			f2=f3;
			arr[i]=f3;
		}
		printf("\nThe fibonacci series is: ");
		for(i=0;i<n;i++)
			printf("%d ",arr[i]);
		close(fd[0]);
		write(fd[1],arr,n*sizeof(int));
	}
	else if(pid>0){
		wait(NULL);
		printf("\nParent process: pid=%d",getpid());
		close(fd[1]);
		read(fd[0],brr,n*sizeof(int));
		j=0;
		k=0;
		for(i=0;i<n;i++){
			if(brr[i]%2==0){
				e[j]=brr[i];
				j++;
			}
			else{
					o[k]=brr[i];
					k++;
			}
		}
		printf("\nThe even nos are: ");
		for(i=0;i<j;i++){
			printf("%d ",e[i]);
		}
		printf("\nThe odd nos are: ");
		for(i=0;i<k;i++){
			printf("%d ",o[i]);
		}
		printf("\n");
	}
	return 0;
}
/*
OUTPUT:
Enter limit for fibonacci series:25

Child process:pid=2202 ppid=2201
The fibonacci series is: 0 1 1 2 3 5 8 13 21 34 55 89 144 233 377 610 987 1597 2584 
						 4181 6765 10946 17711 28657 46368 
Parent process: pid=2201
The even nos are: 0 2 8 34 144 610 2584 10946 46368 
The odd nos are: 1 1 3 5 13 21 55 89 233 377 987 1597 4181 6765 17711 28657 
*/
