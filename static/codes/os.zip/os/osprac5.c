//1.find sum of n numbers using shared memory
#include<sys/types.h>
#include<sys/shm.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<unistd.h>
#include<stdlib.h>
#include<stdio.h>
#include<sys/wait.h>
int main(){
pid_t pid;
int arr[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
int shmid;
shmid=shmget(IPC_PRIVATE,400,IPC_CREAT|0666);
int *total=(int *)shmat(shmid,(void*)0,0);
*total=0;
int i;
pid=fork();
if(pid==0){
	printf("child process\n");
	for(i=0;i<10;i++){
		*total=*total+arr[i];
	}
	printf(" child total:%d\n",*total);
}
else if(pid>0){
		printf("parent process\n");
	for(i=10;i<20;i++){
		*total=*total+arr[i];
	}
	printf("Parent total:%d",*total);
	pid=wait(NULL);
	if(pid!=-1){
		printf("\nTotal sum:%d\n",*total);
		shmdt(total);
		
	}
}
else{
		perror("Fork error");
		exit(0);
	}
return 0;
}
/*
OUTPUT:
parent process
child process
 child total:210
Parent total:155
Total sum:210
*/
