//program 14: Demonstrate fork pid and ppid,sleep,wait and exec system calls.
//1.Demonstrate Orphan process.
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
int main(){
int pid,i;
pid =fork();
if(pid==0){
	printf("I am child process \n");
	printf("child pid is %d\n",getpid()); 
	printf("child ppid is %d\n",getppid());	
	printf("\n");
	sleep(20);
	printf("now child pid is %d\n",getpid()); 
printf("now child ppid is %d\n",getppid());
}
if(pid>0){
	printf("I am parent process \n");
	printf("parent pid is %d\n",getpid()); 
	printf("parent's ppid is %d\n",getppid());
	printf("\n");
}
return 0;
}
/*
output:
I am parent process 
parent pid is 2237
parent's ppid is 2092
I am child process 
child pid is 2238
child ppid is 2237
rajat@rajat-HP-Pavilion-15-NoteBook-PC:~$ now child pid is 2238
now child ppid is 1017
*/
//2.Demonstrate Zombie process.
#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>
int main(){
	int pid1;
pid1 =fork();
if(pid1>0){
	printf("I am parent process \n");
	printf("parent pid is %d\n",getpid()); 
	printf("parent's ppid is %d\n",getppid());
	printf("\n");
	sleep(20);
}
else if(pid1==0){
	printf("I am child process \n");
	printf("child pid is %d\n",getpid()); 
	printf("child ppid is %d\n",getppid());	
	printf("\n");
}
	return 0;
}
/*
OUTPUT:
I am parent process 
parent pid is 2215
parent's ppid is 1916

I am child process 
child pid is 2216
child ppid is 2215
*/
//3.Demonstrate sleep and wait sysytem call
#include <stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>
void main(){
int pid1,i;
pid1 =fork();
if(pid1==0){
	printf("I am child process \n");
  for(i=0;i<30;i++){
	  printf("%d\n", i);
	  sleep(1);
 }
	exit(0);
}
else{
	//wait(0);
	sleep(10);
	printf("I am parent process\n ");
	//wait(0);
	sleep(10);
	printf("I am parent process\n ");
	//wait(0);
	}
}
/*
OUTPUT:
I am child process 
0
1
2
3
4
5
6
7
8
9
I am parent process
10
11
12
13
14
15
16
17
18
19
 I am parent process
 rajat@rajat-HP-Pavilion-15-NoteBook-PC:~$ 20
21
22
23
24
25
26
27
28
29
*/
