/*5.Program to show multiple threads with global and static variables*/
#include<stdio.h>
#include<stdlib.h>
#include <pthread.h>
#include <time.h>
#include <wait.h>
#include <errno.h>
#include <sys/types.h>
int global=0;
void *threadfun(void *arg){
    static int st=0;
    st+=1;
    global+=1;
    printf("Static: %d Global: %d\n",st,global);
}
int main(int argc, char const *argv[]) {
  pthread_t tid;
  pthread_attr_t attr;
  pthread_attr_init(&attr);
  for(int i=0;i<3;i++){
    pthread_create(&tid,&attr,threadfun,&i);
    printf("Thread id %d:%d\n",i+1,(int)tid);
  }
pthread_exit(NULL);
  return 0;
}
/*Output:
Thread id 1:1444869888
Static: 1 Global: 1
Thread id 2:1436477184
Static: 2 Global: 2
Thread id 3:1428084480
Static: 3 Global: 3
*/
