//lru replacement algorithm
#include<stdio.h>
#define min -999
int main(){
	int f,i,n,k,j,flag,x,t,z;
	printf("\nLRU REPLACEMENT ALGORITHM\n");
	printf("\nEnter the reference string length:");
	scanf("%d",&n);
	int arr[n];
	printf("\nEnter reference string:\n");
	for(i=0;i<n;i++)
		scanf("%d",&arr[i]);
	printf("\nEnter no of frames:");
	scanf("%d",&f);
	int frame[n*f],visited[f],q[n*f],fault=0,count;
	for(i=0;i<n*f;i++){
		frame[i]=min;
		q[i]=min;
	}
	x=0;
	printf("frames are:\n");
	for(i=0;i<f;i++)
	printf("| %d ",i);
	printf("|\n------------------\n");
	for(j=0;j<n;j++){
		flag=0;
		for(k=0;k<f;k++){
			if(frame[0]==min)
				break;
			else if(arr[j]==frame[k]){
				flag=1;
				break;
			}	
		}
		if(flag==0){
			if(x<f){
				frame[x]=arr[j];
				fault++;
				x++;
				for(i=0;i<x;i++)
					printf("| %d ",frame[i]);
				printf("|\n");
			
			}
			else{
				t=0;
				count=0;
				for(i=0;i<f;i++)
					visited[i]=0;
				for(i=j-1;i>=0;i--){
					for(z=0;z<f;z++){
						if(frame[z]==arr[i] && visited[z]==0){
							q[t]=z;
							t++;
							visited[z]=1;
						}
					}
				}
				for(i=0;i<f;i++){
					if(visited[i]==0){
						q[t]=i;
						t++;
						visited[i]=1;
						break;
					}

				}
			
				if(t>0){
					frame[q[t-1]]=arr[j];
					fault++;
				}
				for(i=0;i<f;i++)
					printf("| %d ",frame[i]);
				printf("|\n");
			}			
		}
		else{
			for(i=0;i<f;i++)
				printf("| %d ",frame[i]);
				printf("|:HIT");
			printf("\n");
		}
	}	
	printf("\nNo of page faults:%d",fault);
	printf("\nNo of hits:%d",n-fault);
	double d= (double)(n-fault)/n;
	printf("\nHit ratio:%lf\n",d);
	return 0;
}
/*
OUTPUT:
LRU REPLACEMENT ALGORITHM

Enter the reference string length:12
Enter reference string:
1 2 3 4 1 2 5 1 2 3 4 5

Enter no of frames:4
frames are:
| 0 | 1 | 2 | 3 |
------------------
| 1 |
| 1 | 2 |
| 1 | 2 | 3 |
| 1 | 2 | 3 | 4 |
| 1 | 2 | 3 | 4 |:HIT
| 1 | 2 | 3 | 4 |:HIT
| 1 | 2 | 5 | 4 |
| 1 | 2 | 5 | 4 |:HIT
| 1 | 2 | 5 | 4 |:HIT
| 1 | 2 | 5 | 3 |
| 1 | 2 | 4 | 3 |
| 5 | 2 | 4 | 3 |

No of page faults:8
No of hits:4
Hit ratio:0.333333
*/
