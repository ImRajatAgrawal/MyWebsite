//PROGRAM 9: Program to estimate working if fork()
//			 vfork() system call.
#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<unistd.h>
#include<string.h>
#include<errno.h>
int main(){
  int i, value;
  int status;
  pid_t f;
  value = 0;
  i = 0;
  status = 1;
  f = fork();
  if (f < 0){
      fprintf(stderr, "Error: %s - fork() < 0 (%d)\n", strerror(errno), f);
    }
  else if (f > 0){
      printf("\n===== Begin Parent =====\n\n");
      printf("fork() = %d\n", f);
      printf("getpid() = %d\n", getpid());
      while (i < 10){
          printf(" Parent -value = %d\n", value);
          ++value;
          ++i;
      }
    }
  else{								
      printf("\n===== Begin Child =====\n\n");
      printf("fork() = %d\n", f);
      printf("getpid() = %d\n", getpid());
      while (i < 10){
          printf("  Child -value = %d\n", value);
          ++value;
          ++i;
      }
    }
  printf("status = %d\n", status);
  printf("value = %d\n\n", value);
  printf("===== End =====\n\n");
  return 0;
}
/*
OUTPUT:
===== Begin Parent =====
fork() = 3689
getpid() = 3688
 Parent -value = 0
 Parent -value = 1
 Parent -value = 2
 Parent -value = 3
 Parent -value = 4
 Parent -value = 5
 Parent -value = 6
 Parent -value = 7
 Parent -value = 8
 Parent -value = 9
status = 1
value = 10
===== Begin Child =====
===== End =====
fork() = 0
getpid() = 3689
  Child -value = 0
  Child -value = 1
  Child -value = 2
  Child -value = 3
  Child -value = 4
  Child -value = 5
  Child -value = 6
  Child -value = 7
  Child -value = 8
  Child -value = 9
status = 1
value = 10
===== End =====
*/
//PROGRAM 10: using vfork system call.
#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<unistd.h>
#include<string.h>
#include<errno.h>
int main(){
  int i,j=0;
  int status;
  pid_t f;
  int forky;
  forky = 0;
  i = 0;
  status = 1;
  f = vfork();
  if (f < 0){
      fprintf(stderr, "Error: %s - fork() < 0 (%d)\n", strerror(errno), f);
  }
  else if (f > 0){
      printf("\n===== Begin Parent =====\n\n");
      printf("fork() = %d\n", f);
      printf("getpid() = %d\n", getpid());
      while (i < 10){
          printf(" Parent - forky.value = %d\n", forky);
          ++forky;
          ++i;
      }
    }
  else{
      printf("\n===== Begin Child =====\n\n");
      printf("fork() = %d\n", f);
      printf("getpid() = %d\n", getpid());
      while (j< 10){
          printf("  Child - forky.value = %d\n", forky);
          ++forky;
          ++j;
      }
      _exit(status);
    }
  printf("status = %d\n", status);
  printf("forky.value = %d\n\n", forky);
  printf("===== End =====\n\n");
  return 0;
}
/*
OUTPUT:
===== Begin Child =====

fork() = 0
getpid() = 4322
  Child - forky.value = 0
  Child - forky.value = 1
  Child - forky.value = 2
  Child - forky.value = 3
  Child - forky.value = 4
  Child - forky.value = 5
  Child - forky.value = 6
  Child - forky.value = 7
  Child - forky.value = 8
  Child - forky.value = 9

===== Begin Parent =====

fork() = 4322
getpid() = 4321
 Parent - forky.value = 10
 Parent - forky.value = 11
 Parent - forky.value = 12
 Parent - forky.value = 13
 Parent - forky.value = 14
 Parent - forky.value = 15
 Parent - forky.value = 16
 Parent - forky.value = 17
 Parent - forky.value = 18
 Parent - forky.value = 19
status = 1
forky.value = 20

===== End =====
*/
