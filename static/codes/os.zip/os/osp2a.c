//c program to simulate the working of ls command
#include<stdio.h>
#include<stdlib.h>
#include<dirent.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/stat.h>
int main(){
struct dirent **name;
int n,i;
char fname[100];
printf("\nEnter pathname:");
scanf("%s",fname);
getcwd(fname,sizeof(fname));
n=scandir(fname,&name,0,alphasort);
if(n<0)
	perror("error");
else
	for(i=0;i<n;i++){
		printf("%s   ",name[i]->d_name);
		if(i%6==0)
			printf("\n");
	}			
return 0;
}
/*
OUTPUT:
gcc osp2a.c
rajat@rajat-HP-Pavilion-15-NoteBook-PC:~$ ./a.out

Enter pathname:/home/rajat
.   
..   .ICEauthority   .Xauthority   .bash_history   .bash_logout   .bashrc   
.cache   .compiz   .config   .gconf   .hplip   .local   
.mozilla   .nano   .profile   .sudo_as_admin_successful   .thunderbird   .xsession-errors   
.xsession-errors.old   20_DSPD_P2_66.c   23_DSPD_P2_66.c   =   Desktop   Documents   
Downloads   Music   Pictures   Public   Rajatjava.java   Templates   
Videos   a.out   abc   abc.c   adt.c   algo.c   
anshit.c   anshit2.c   aplprac9b.cpp   average.pl   average3.perl   avg10.pl   
awkcode.awk   block4kb.c   bucketsort   bucketsort.cpp   cc1.c   cc2.c   
cc3.c   cc5.c   cc6.c   cc7.c   cc8.c   cc9.c   
ccc.c   ccc1.c   ccc2.c   ccc4.c   ccc5.c   ccc6.c   
ccc7.c   ccc8.c   ccc9.c   cccc.c   cccc1.c   cl   
clientprob.c   clients   copy.c   cpp-1.pdf   demo   demo.c   
dsi1.c   dspd.c   dspd.h   dspdcll.c   dspddll.c   dspddupl.c   
dspdprac1.c   dspdprac10.c   dspdprac10a.c   dspdprac11.c   dspdprac2.c   dspdprac3.c   
dspdprac4.c   dspdprac5.c   dspdprac6.c   dspdprac7.c   dspdprac8.c   dspdprac8a.c   
e   examapl1.c   examples.desktop   f2   f2.sh   first   
football.c   infix.c   libgraph-1.0.2   link.c   main.c   marine   
middle.pl   mozilla.pdf   my.txt   mybt.c   myclient.c   myds.c   
mydspd.c   myhash.pl   myproject.cpp   myserv.c   myserver.c   myshared.c   
myshared1.c   mysoc.c   mysorts.c   os1.c   os2.c   os3.c   
osp2.c   osp2a.c   osp2b.c   output.txt   p.c   p548.c   
perl5.pl   perl6.pl   perl7.pl   perl_tutorial.pdf   perlprac4.pl   perlrajat.pl   
perltutorial.ppt   pp1.c   pract2.c   pract3.c   process1.c   program.txt   
program1.txt   py.pl   quadratic.cpp   queueadt.h   r1.sh   r2   
r3   rajat   rajatfile.c   rajatperl2.pl   rajatperl3.pl   rajatperl4.pl   
rajatprob.cpp   rajatscript1.sh   rajatscript2.sh   rajatscript3.sh   rajatscript4.sh   rajatscript5.sh   
rajatscript6.sh   rajatscript7.sh   rajatscript8.sh   rajatscript9.sh   rajatsort.c   rema thareja.pdf   
result.txt   revpyramid.pl   rushabh10.c   rushabhrock.c   sales.awk   sales.txt   
second   second.sh   serverprob.c   servers   sortbucket.c   sorting.c   
sr   stackex1.c   starwars   switchcase.c   target.txt   train.c   
tree.c   treeADT.c   treeadt.h   welcome.pl   wl.pl   world   
yashdspd.c
*/
