//BANKER'S ALGORITHM-Detection  and recovery of deadlock.
#include<stdio.h>
#include<stdlib.h>
int main(){
	int n,m,i,j,flag=0,c,k,t,r,q,flag1;
	printf("\nEnter the no of processes:");
	scanf("%d",&n);
	q=n;
	printf("Enter no of resource types:");
	scanf("%d",&m);
	int allocation[n][m],available[m],request[n][m],work[m];
	int count,visited[n+1],mx[n+1],sum,m1,finish[n];
	printf("Enter allocation matrix:\n");
	for(i=0;i<n;i++){
	c=0;
	sum=0;
	visited[i]=0;
	printf("P%d: ",i);
		for(j=0;j<m;j++){
			scanf("%d",&allocation[i][j]);
			sum+=allocation[i][j];
			if(allocation[i][j]==0){
				c++;
			}
		
		
		}
		mx[i]=sum;
		if(c==m)
			finish[i]=1;
		else
			finish[i]=0;
	}
	printf("Enter request matrix:\n");
	for(i=0;i<n;i++){
	printf("P%d: ",i);
		for(j=0;j<m;j++){
			scanf("%d",&request[i][j]);
		}
	}
	int ct;
	printf("Enter available matrix:");
	for(i=0;i<m;i++){
			scanf("%d",&available[i]);
			work[i]=available[i];
	}
	label:
	ct=0;
	flag1=1;
	for(i=0;i<n;i++){
		if(flag1==1){
			flag1=0;
		for(j=0;j<n;j++){
		count=0;
			for(k=0;k<m;k++){
				if(finish[j]==0){
					if(request[j][k]<=work[k])
						count++;
				}
			}
			if(count==m && finish[j]==0){
				finish[j]=1;
				visited[ct]=j;
				ct++;
				flag1=1;
				for(t=0;t<m;t++){
						work[t]=work[t]+allocation[j][t];
				}
			}
			
		}
	}
	else
		break;	
	}
	flag=0;
	for(i=0;i<n;i++){
		if(finish[i]==0){
			flag=1;
			printf("\nDeadlocked\n");
			printf("Process: P%d",i);
		}
		}
		if(flag==1){
		m1=0;	
		for(j=0;j<n;j++){
			if(mx[j]>m1){
				m1=mx[j];
				r=j;
			}
		}
		mx[r]=0;
		for(j=0;j<m;j++){
			available[j]=available[j]+allocation[r][j];
			allocation[r][j]=0;
			finish[j]=0;
			work[j]=available[j];
		}
		finish[r]=1;
		q=q-1;
		printf("\nEntering into recovery...");
		goto label;
	}
	else if(flag==0){
		printf("\nThe sequence without deadlock is:\n");
		printf("< ");
		for(j=0;j<q;j++){
			printf("P%d ",visited[j]);
		}
		printf(">");
		printf("\n");
	}
	return 0;
}
/*
OUTPUT:
Enter the no of processes:5
Enter no of resource types:3
Enter allocation matrix:
P0: 0 1 0
P1: 2 0 0
P2: 3 0 3
P3: 2 1 1
P4: 0 0 2
Enter request matrix:
P0: 0 0 0 
P1: 2 0 2
P2: 0 0 1
P3: 1 0 0
P4: 0 0 2
Enter available matrix:0 0 0

Deadlocked
Process: P1
Deadlocked
Process: P2
Deadlocked
Process: P3
Deadlocked
Process: P4
Entering into recovery...
The sequence without deadlock is:
< P0 P1 P3 P4 >
*/
