//1.producer consumer problem without synchronization.
#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
void *producer();
void *consumer();
void *producer(void *param) {
for(int i=0; i<15 ; i++){
   printf("I am producer:%d\n",i+1);
  	sleep(1);
  }    
  pthread_exit(0);
}
void *consumer(void *param) {
for(int i=0; i<15 ; i++){
   printf("I am consumer:%d\n",i+1);
 	sleep(1);
  } 

   pthread_exit(0);
}
int main(){
	pthread_t ptid,ctid;
	pthread_create(&ptid,NULL,producer,NULL);
	pthread_create(&ctid,NULL,consumer,NULL);
	pthread_join(ptid,NULL);
	pthread_join(ctid,NULL);
return 0;
}
/*
OUTPUT:
I am producer:1
I am consumer:1
I am producer:2
I am consumer:2
I am producer:3
I am consumer:3
I am producer:4
I am consumer:4
I am producer:5
I am consumer:5
I am producer:6
I am consumer:6
I am producer:7
I am consumer:7
I am producer:8
I am consumer:8
I am producer:9
I am consumer:9
I am producer:10
I am consumer:10
I am producer:11
I am consumer:11
I am producer:12
I am consumer:12
I am producer:13
I am consumer:13
I am producer:14
I am consumer:14
I am producer:15
I am consumer:15
*/
