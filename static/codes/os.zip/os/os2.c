//program to create a file with 4K bytes free space.
#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<string.h>
#include<unistd.h>
int main(){
int fd;
char fname[25];
printf("\nEnter name of the file to create:");
scanf("%s",fname);
if((fd=creat(fname,0777))==-1){
	perror("creation error");
	exit(1);
}
if((lseek(fd,4095,SEEK_SET))==-1){
	perror("Error in positioning");
	exit(1);
}
write(fd,"\0",1);
printf("\nFile created");
close(fd);
return 0;
}

