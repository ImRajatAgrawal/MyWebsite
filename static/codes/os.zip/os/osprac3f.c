//PROGRAM 15:demonstrate all system calls in single program.  
#include<stdio.h>
#include<unistd.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<errno.h>
int main(){
	int pid;
	int status,i=0,j,value=1,total=0;
	pid=fork();
	if(pid==0){
		printf("CHILD PROCESS 1\n");
		printf("PID:%d\n",getpid());
		printf("PPID:%d\n",getppid());
		while (i < 10){
          printf("  Child 1 -value = %d\n", value);
          ++value;
          sleep(1);
          /*if(i%3==0){
          	system("ps -aux");
          }*/

          ++i;
      }
      printf("value = %d\n", value);
	}
	else{
			sleep(5);
			printf("PARENT PROCESS 1:\n");
			printf("PID:%d\n",getpid());
			pid_t pid1;
			pid1=vfork();
			if(pid1==0){
				printf("CHILD PROCESS 2:\n");
				printf("PID:%d\n",getpid());
				printf("PPID:%d\n",getppid());
				for(j=1;j<=10;j++){
					total+=j;
				}
				printf("CHILD 2 TOTAL:%d\n",total);
				execlp("date","date",(char *)0);
				_exit(status);		
			}
			else{
					printf("PARENT PROCESS 2:\n");
					printf("PID:%d\n",getpid());
					wait(&status);
					printf("parent 1 completed with status:%d\n",status);
					for(j=1;j<=10;j++){
						total+=j;
					}
					wait(&status);
					printf("parent 2 completed with status:%d\n",status);
					printf("parent 2 total:%d\n",total);
					/*printf("End status of program:\n");
					system("ps -aux");*/
			}	
	}
	printf("After process pid:%d\n",getpid());
	return 0;
}
/*
OUTPUT:
CHILD PROCESS 1
PID:2147
PPID:2146
  Child 1 -value = 1
  Child 1 -value = 2
  Child 1 -value = 3
  Child 1 -value = 4
  Child 1 -value = 5
PARENT PROCESS 1:
PID:2146
CHILD PROCESS 2:
PID:2148
PPID:2146
CHILD 2 TOTAL:55
PARENT PROCESS 2:
PID:2146
Tue Mar  6 11:08:09 IST 2018
parent 1 completed with status:0
  Child 1 -value = 6
  Child 1 -value = 7
  Child 1 -value = 8
  Child 1 -value = 9
  Child 1 -value = 10
value = 11
After process pid:2147
parent 2 completed with status:0
parent 2 total:110
After process pid:2146
*/
