package org.yourorghere;

import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;
import javax.swing.JFrame;

    
class thirdGLEventListener implements GLEventListener {
private GLU glu;

@Override
public void init(GLAutoDrawable gld) {
    GL gl = gld.getGL();
    glu = new GLU();

    gl.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    gl.glViewport(0,0,640,480);
    gl.glMatrixMode(GL.GL_PROJECTION);
    gl.glLoadIdentity();
    glu.gluOrtho2D(0,640,0,480);
}

@Override
public void display(GLAutoDrawable drawable) {
    GL gl = drawable.getGL();

    gl.glClear(GL.GL_COLOR_BUFFER_BIT);
    try {
        drawLine(gl);
    } catch (AWTException ex) {
        Logger.getLogger(thirdGLEventListener.class.getName()).log(Level.SEVERE, null, ex);
    }

}

@Override
public void reshape(GLAutoDrawable drawable, int x, int y, int width,
        int height) {
}

@Override
public void displayChanged(GLAutoDrawable drawable,
        boolean modeChanged, boolean deviceChanged) {
}

private void drawLine(GL gl) throws AWTException {
       gl.glColor3f(0f, 0f, 0f);
       ddafirst(320,0,320,480,gl,1);
       ddafirst(0,240,640,240,gl,1);
       gl.glColor3f(1f, 0.5f, 0f);
       ddafirst(380,280,420,280,gl,1);
       ddafirst(460,280,500,280,gl,1);
       ddafirst(420,280,420,320,gl,1);
       ddafirst(460,280,460,320,gl,1);
       ddafirst(380,280,380,380,gl,1);
       ddafirst(500,280,500,380,gl,1);
       ddafirst(420,320,460,320,gl,1);
       ddafirst(380,380,440,440,gl,1);
       ddafirst(500,380,440,440,gl,1);
       int arr[][]={{380,280,1},{420,280,1},{420,320,1},
                    {460,320,1},{460,280,1},{500,280,1},
                    {500,380,1},{440,440,1},{380,380,1}};
       int mat1[][]={{1,0,0},{0,1,0},{-320,-240,1}};
       int mat2[][]={{-1,0,0},{0,1,0},{0,0,1}};
       int mat3[][]=new int[9][3];
       int mat4[][]={{1,0,0},{0,1,0},{320,240,1}};
       int mat5[][]=new int[9][3];
       int mat6[][]={{1,0,0},{0,-1,0},{0,0,1}};
       int mat7[][]={{-1,0,0},{0,-1,0},{0,0,1}};
       reflect(arr,mat1,mat2,mat3,mat4,mat5,gl);//about y-axis
       reflect(arr,mat1,mat6,mat3,mat4,mat5,gl);//about x-axis
       reflect(arr,mat1,mat7,mat3,mat4,mat5,gl);//about origin
}
void reflect(int arr[][],int mat1[][],int mat2[][],int mat3[][],int mat4[][],int mat5[][],GL gl){
    int result[][]=new int[9][3],i,j,k;
    for(i=0;i<9;i++){
           for(j=0;j<3;j++){
               mat3[i][j]=0;
               for(k=0;k<3;k++)
                   mat3[i][j]+=arr[i][k]*mat1[k][j];
           }
       }
       for(i=0;i<9;i++){
           for(j=0;j<3;j++){
               mat5[i][j]=0;
               for(k=0;k<3;k++)
                   mat5[i][j]+=mat3[i][k]*mat2[k][j];
           }
       }
       for(i=0;i<9;i++){
           for(j=0;j<3;j++){
               result[i][j]=0;
               for(k=0;k<3;k++)
                   result[i][j]+=mat5[i][k]*mat4[k][j];
           }
       }
       for(i=0;i<8;i++)
            ddafirst(result[i][0],result[i][1],result[i+1][0],result[i+1][1],gl,1);
       ddafirst(result[i][0],result[i][1],result[0][0],result[0][1],gl,1);
}
void ddafirst(double x1,double y1,double x2,double y2,GL gl,int c){
    double len;
    double dx,dy,x,y;
    if(Math.abs(x2-x1)>Math.abs(y2-y1)){
        len=Math.abs(x2-x1);
    }
    else{
        len=Math.abs(y2-y1);
    }
    dx=(x2-x1)/len;
    dy=(y2-y1)/len;
    x=x1;
    y=y1;
    int i=1,j;
    gl.glBegin(GL.GL_POINTS);
    while(i<=len){
        if(c==1){ 
            gl.glVertex2i((int)(x),(int)(y));
            x=x+dx;
            y=y+dy;
            i=i+1;
        }
        else if(c==2){ 
            if(i%2==1) gl.glVertex2i((int)(x),(int)(y));
            x=x+dx;
            y=y+dy;
            i=i+1;
        }
        else if(c==3){
            if(i%2==1){
                for(j=0;j<5;j++){
                    gl.glVertex2i((int)(x),(int)(y));
                    x=x+dx;
                    y=y+dy;
                    i=i+1;
                }
                i+=2;
                x=x+dx;
                x=x+dx;
                y=y+dy;
                y=y+dy;
            }
            else{
                  gl.glVertex2i((int)(x),(int)(y));
                  i+=3;
                  x=x+dx;
                  x=x+dx;
                  y=y+dy;
                  y=y+dy;
            }
        }
        else{
            for(j=0;j<3;j++)
                gl.glVertex2i((int)(x-j),(int)(y+j));
            for(j=1;j<3;j++)
                gl.glVertex2i((int)(x+j),(int)(y-j));
            x=x+dx;
            y=y+dy;
            i=i+1;
        }

    }
    gl.glEnd();
}
public void dispose(GLAutoDrawable arg0)
{
    
}
}
public class Reflectioncg{
    public static void main(String args[]){
        //getting the capabilities object of GL2 profile
        //final GLProfile profile=GLProfile.get(GLProfile.GL);
        GLCapabilities capabilities=new GLCapabilities();
        // The canvas
        final GLCanvas glcanvas=new GLCanvas(capabilities);
        thirdGLEventListener b=new thirdGLEventListener();
        glcanvas.addGLEventListener(b);
        glcanvas.setSize(400, 400);
        //creating frame
        final JFrame frame=new JFrame("Basic Frame");
        //adding canvas to frame
        frame.add(glcanvas);
        frame.setSize(640,480);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

