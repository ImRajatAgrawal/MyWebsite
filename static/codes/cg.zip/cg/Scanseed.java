package org.yourorghere;

import java.awt.*;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.util.Pair;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;
import javax.swing.JFrame;

    
class thirdGLEventListener implements GLEventListener {
private GLU glu;

@Override
public void init(GLAutoDrawable gld) {
    GL gl = gld.getGL();
    glu = new GLU();

    //gl.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    gl.glViewport(0,0,640,480);
    gl.glMatrixMode(GL.GL_PROJECTION);
    gl.glLoadIdentity();
    glu.gluOrtho2D(0,640,0,480);
}

@Override
public void display(GLAutoDrawable drawable) {
    GL gl = drawable.getGL();

    gl.glClear(GL.GL_COLOR_BUFFER_BIT);
    try {
        /*
        * put your code here
        */
        //drawLine(gl, 0, 0, 100, 100);
        //gl.glColor3f(1.0f, 1.0f, 1.0f );
        drawLine(gl);
    } catch (AWTException ex) {
        Logger.getLogger(thirdGLEventListener.class.getName()).log(Level.SEVERE, null, ex);
    }

}

@Override
public void reshape(GLAutoDrawable drawable, int x, int y, int width,
        int height) {
}

@Override
public void displayChanged(GLAutoDrawable drawable,
        boolean modeChanged, boolean deviceChanged) {
}

private void drawLine(GL gl) throws AWTException {
       gl.glColor3f(1f, 1f, 1f);
       ddafirst(300,300,200,200,gl,1); 
       ddafirst(300,300,400,200,gl,1);
       ddafirst(200,200,200,50,gl,1);
       ddafirst(400,200,400,50,gl,1);
       ddafirst(200,50,400,50,gl,1);
       ddafirst(250,80,350,80,gl,1);
       ddafirst(250,160,350,160,gl,1);
       ddafirst(250,80,250,160,gl,1);
       ddafirst(350,80,350,160,gl,1);
       seedfill(300,250,gl);
}
void sleep(int i){
    while(i--!=0){
        for(int j=0;j<100000;j++){
            j++;
            j--;
        }
    }
}
void seedfill(int x,int y,GL gl){
     ByteBuffer buffer =ByteBuffer.allocate(4);
    byte[] rgb=buffer.array();
    int savex,savey,xleft,xright,pflag,xenter;
    Stack<Pair<Integer,Integer>>stk=new Stack<Pair<Integer,Integer> >();
    stk.push(new Pair(x,y));
    while(!stk.isEmpty()){
        Pair<Integer,Integer> p=stk.pop();
        x=p.getKey();
        y=p.getValue();
        gl.glColor3f(1f, 1f, 0.5f);
        gl.glBegin(gl.GL_POINTS);
        gl.glVertex2i(x, y);
        gl.glEnd();
        savex=x;
        savey=y;
        x=x+1;
        gl.glReadPixels(x,y,1,1,GL.GL_RGB,GL.GL_UNSIGNED_BYTE,buffer);
        while(rgb[0]==0 && rgb[1]==0 && rgb[2]==0){
            gl.glBegin(gl.GL_POINTS);
            gl.glVertex2i(x, y);
            gl.glEnd();
            x=x+1;
            gl.glReadPixels(x,y,1,1,GL.GL_RGB,GL.GL_UNSIGNED_BYTE,buffer);
        }
        xright=x-1;
        x=savex;
        x=x-1;
        gl.glReadPixels(x,y,1,1,GL.GL_RGB,GL.GL_UNSIGNED_BYTE,buffer);
        while(rgb[0]==0 && rgb[1]==0 && rgb[2]==0){
            gl.glBegin(gl.GL_POINTS);
            gl.glVertex2i(x, y);
            gl.glEnd();
            x=x-1;
            gl.glReadPixels(x,y,1,1,GL.GL_RGB,GL.GL_UNSIGNED_BYTE,buffer);
        }
        xleft=x+1;
        x=xleft;
        y=y+1;
        while(x<=xright){
            pflag=0;
            gl.glReadPixels(x,y,1,1,GL.GL_RGB,GL.GL_UNSIGNED_BYTE,buffer);
            while((rgb[0]==0 && rgb[1]==0 && rgb[2]==0)&& x<xright){
                if(pflag==0) pflag=1;
                x=x+1;
                gl.glReadPixels(x,y,1,1,GL.GL_RGB,GL.GL_UNSIGNED_BYTE,buffer);
            }
           
            if (pflag==1){
                gl.glReadPixels(x,y,1,1,GL.GL_RGB,GL.GL_UNSIGNED_BYTE,buffer);
                if(x==xright && (rgb[0]==0 && rgb[1]==0 && rgb[2]==0))
                    stk.push(new Pair(x,y));
                else
                    stk.push(new Pair(x-1,y));
                pflag=0;
            }
            xenter=x;
            gl.glReadPixels(x,y,1,1,GL.GL_RGB,GL.GL_UNSIGNED_BYTE,buffer);
            while(((rgb[0]==-1 && rgb[1]==-1 && rgb[2]==-1)|| !(rgb[0]==0 && rgb[1]==0 && rgb[2]==0))&& x<xright){
                x=x+1;
                gl.glReadPixels(x,y,1,1,GL.GL_RGB,GL.GL_UNSIGNED_BYTE,buffer);
            }
            if(x==xenter)x=x+1;
        }
        x=xleft;
        y=savey-1;
        while(x<=xright){
            pflag=0;
            gl.glReadPixels(x,y,1,1,GL.GL_RGB,GL.GL_UNSIGNED_BYTE,buffer);
            while((rgb[0]==0 && rgb[1]==0 && rgb[2]==0)&& x<xright){
                if(pflag==0) pflag=1;
                x=x+1;
                gl.glReadPixels(x,y,1,1,GL.GL_RGB,GL.GL_UNSIGNED_BYTE,buffer);
            }
            if (pflag==1){
                gl.glReadPixels(x,y,1,1,GL.GL_RGB,GL.GL_UNSIGNED_BYTE,buffer);
                if(x==xright && (rgb[0]==0 && rgb[1]==0 && rgb[2]==0)){
                    stk.push(new Pair(x,y));
                }
                else{
                    stk.push(new Pair(x-1,y));
                }
                pflag=0;
            }
            xenter=x;
            gl.glReadPixels(x,y,1,1,GL.GL_RGB,GL.GL_UNSIGNED_BYTE,buffer);
            while(((rgb[0]==-1 && rgb[1]==-1 && rgb[2]==-1)|| !(rgb[0]==0 && rgb[1]==0 && rgb[2]==0))&& x<xright){
                x=x+1;
                gl.glReadPixels(x,y,1,1,GL.GL_RGB,GL.GL_UNSIGNED_BYTE,buffer);
            }
            if(x==xenter)x=x+1;
        }
    }  
}
 void ddafirst(double x1,double y1,double x2,double y2,GL gl,int c){
        double len;
        double dx,dy,x,y;
        if(Math.abs(x2-x1)>Math.abs(y2-y1)){
            len=Math.abs(x2-x1);
        }
        else{
            len=Math.abs(y2-y1);
        }
        dx=(x2-x1)/len;
        dy=(y2-y1)/len;
        x=x1;
        y=y1;
        int i=1,j;
        gl.glBegin(GL.GL_POINTS);
        while(i<=len){
            if(c==1){ 
                gl.glVertex2i((int)(x),(int)(y));
                x=x+dx;
                y=y+dy;
                i=i+1;
            }
            else if(c==2){ 
                if(i%2==1) gl.glVertex2i((int)(x),(int)(y));
                x=x+dx;
                y=y+dy;
                i=i+1;
            }
            else if(c==3){
                if(i%2==1){
                    for(j=0;j<5;j++){
                        gl.glVertex2i((int)(x),(int)(y));
                        x=x+dx;
                        y=y+dy;
                        i=i+1;
                    }
                    i+=2;
                    x=x+dx;
                    x=x+dx;
                    y=y+dy;
                    y=y+dy;
                }
                else{
                      gl.glVertex2i((int)(x),(int)(y));
                      i+=3;
                      x=x+dx;
                      x=x+dx;
                      y=y+dy;
                      y=y+dy;
                }
            }
            else{
                for(j=0;j<3;j++)
                    gl.glVertex2i((int)(x-j),(int)(y+j));
                for(j=1;j<3;j++)
                    gl.glVertex2i((int)(x+j),(int)(y-j));
                x=x+dx;
                y=y+dy;
                i=i+1;
            }

        }
        gl.glEnd();
    }


public void dispose(GLAutoDrawable arg0)
{
    
}
}
public class Scanseed
{
public static void main(String args[])
{
    //getting the capabilities object of GL2 profile
    //final GLProfile profile=GLProfile.get(GLProfile.GL);
    GLCapabilities capabilities=new GLCapabilities();
    // The canvas
    final GLCanvas glcanvas=new GLCanvas(capabilities);
    thirdGLEventListener b=new thirdGLEventListener();
    glcanvas.addGLEventListener(b);
    glcanvas.setSize(400, 400);
    //creating frame
    final JFrame frame=new JFrame("Basic Frame");
    //adding canvas to frame
    frame.add(glcanvas);
    frame.setSize(640,480);
    frame.setVisible(true);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

