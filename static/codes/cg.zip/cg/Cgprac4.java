package org.yourorghere;

import java.awt.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;
import javax.swing.JFrame;



    
 class ThirdGLEventListener implements GLEventListener {
/**
 * Interface to the GLU library.
 */
private GLU glu;

/**
 * Take care of initialization here.
 */
@Override
public void init(GLAutoDrawable gld) {
    GL gl = gld.getGL();
    glu = new GLU();

    gl.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    gl.glViewport(0,0,640,480);
    gl.glMatrixMode(GL.GL_PROJECTION);
    gl.glLoadIdentity();
    glu.gluOrtho2D(0,640,0,480);
}

/**
 * Take care of drawing here.
 */
@Override
public void display(GLAutoDrawable drawable) {
    GL gl = drawable.getGL();

    gl.glClear(GL.GL_COLOR_BUFFER_BIT);
    try {
        /*
        * put your code here
        */
        //drawLine(gl, 0, 0, 100, 100);
        //gl.glColor3f(1.0f, 1.0f, 1.0f );
        drawLine(gl);
    } catch (AWTException ex) {
        Logger.getLogger(ThirdGLEventListener.class.getName()).log(Level.SEVERE, null, ex);
    }

}

@Override
public void reshape(GLAutoDrawable drawable, int x, int y, int width,
        int height) {
}

@Override
public void displayChanged(GLAutoDrawable drawable,
        boolean modeChanged, boolean deviceChanged) {
}

private void drawLine(GL gl) throws AWTException {
    gl.glColor3f(1.0f,0.7f,0.0f);
    bresenhamsellipse(300,240,100,100,gl);
    gl.glColor3f(1.0f,0.0f,0.0f);
    bresenhamsellipse(250,270,30,10,gl); 
    bresenhamsellipse(350,270,30,10,gl);
    gl.glColor3f(0.0f,0.0f,1.0f);
    bresenhamsellipse(300,200,40,10,gl);/*
    gl.glPolygonMode(GL.GL_FRONT_AND_BACK, GL.GL_LINE);      
   gl.glLineWidth(50f); 
   gl.glBegin(GL.GL_POLYGON);
        gl.glColor3f(0f, 1f, 0f);
        gl.glVertex2i(220, 290);
         gl.glColor3f(0f, 1f, 0f);
        gl.glVertex2i(320, 140);
         gl.glColor3f(0f, 1f, 0f);
        gl.glVertex2i(420, 290);
         gl.glColor3f(0f, 1f, 0f);
        gl.glVertex2i(320, 340);
         gl.glColor3f(0f, 1f, 0f);
        gl.glVertex2i(220, 290);
            oddeven(230,290);
        gl.glEnd();*/
    
  
}
void oddeven(int x,int y) throws AWTException{
    int c=0;
    Robot r = new Robot();
    Color cc;
    int c1=0;
    for(int i=x;i<640;i++){
        cc=r.getPixelColor(i, y);
         c1=cc.getGreen();
         System.out.println("color:"+c1);
    }
    
}
void bresenhamsellipse(int h,int k,int a,int b,GL gl){
   int xi = 0,yi=b;
   int deldash,del,deli = a*a - 2*a*a*b + b*b;
    while(yi>=0){
        gl.glPointSize(1.5f);
        gl.glBegin(gl.GL_POINTS);
        //gl.glColor3f(1.0f, 0.7f, 0.0f); 
        gl.glVertex2d( xi+h , yi+k );
        gl.glVertex2d( -xi+h , yi+k );
        gl.glVertex2d( xi+h , -yi+k );
        gl.glVertex2d( -xi+h , -yi+k );
        if(deli<0){
            del = 2*deli + 2*a*a*yi - a*a;
            if(del<=0){
               xi = xi + 1;
               deli = deli + 2*b*b*(xi+1) + b*b;
            }
            else{
                xi = xi + 1;
                 yi = yi - 1;
                deli = deli - 2*a*a*(yi-1) + 2*b*b*(xi+1) + a*a + b*b;
            }
              
        }
        else if(deli>0){
            deldash = 2*deli - 2*b*b*xi - b*b;
            if(deldash<=0){
                xi = xi + 1;
                yi = yi - 1;
                deli = deli - 2*a*a*(yi-1) + 2*b*b*(xi+1) + a*a + b*b;
            }
            else{
                yi = yi - 1;
                deli = deli - 2*a*a*(yi-1) + a*a;
            }
                
        }
        else{
            xi = xi + 1;
            yi = yi - 1;
            deli = deli - 2*a*a*(yi-1) + 2*b*b*(xi+1) + a*a + b*b;
        }
        gl.glEnd();
    }

}

public void dispose(GLAutoDrawable arg0)
{
    
}
}
public class Cgprac4
{
public static void main(String args[])
{
    //getting the capabilities object of GL2 profile
    //final GLProfile profile=GLProfile.get(GLProfile.GL);
    GLCapabilities capabilities=new GLCapabilities();
    // The canvas
    final GLCanvas glcanvas=new GLCanvas(capabilities);
    ThirdGLEventListener b=new ThirdGLEventListener();
    glcanvas.addGLEventListener(b);
    glcanvas.setSize(400, 400);
    //creating frame
    final JFrame frame=new JFrame("Basic Frame");
    //adding canvas to frame
    frame.add(glcanvas);
    frame.setSize(640,480);
    frame.setVisible(true);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

