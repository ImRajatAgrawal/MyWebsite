package org.yourorghere;

import java.awt.*;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.util.Pair;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;
import javax.swing.JFrame;

    
class thirdGLEventListener implements GLEventListener {
private GLU glu;

@Override
public void init(GLAutoDrawable gld) {
    GL gl = gld.getGL();
    glu = new GLU();

    gl.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    gl.glViewport(0,0,640,480);
    gl.glMatrixMode(GL.GL_PROJECTION);
    gl.glLoadIdentity();
    glu.gluOrtho2D(0,640,0,480);
}

@Override
public void display(GLAutoDrawable drawable) {
    GL gl = drawable.getGL();

    gl.glClear(GL.GL_COLOR_BUFFER_BIT);
    try {
        /*
        * put your code here
        */
        //drawLine(gl, 0, 0, 100, 100);
        //gl.glColor3f(1.0f, 1.0f, 1.0f );
        drawLine(gl);
    } catch (AWTException ex) {
        Logger.getLogger(thirdGLEventListener.class.getName()).log(Level.SEVERE, null, ex);
    }

}

@Override
public void reshape(GLAutoDrawable drawable, int x, int y, int width,
        int height) {
}

@Override
public void displayChanged(GLAutoDrawable drawable,
        boolean modeChanged, boolean deviceChanged) {
}

private void drawLine(GL gl) throws AWTException {
       int arr[]=new int[4];
       int brr[]=new int[4];
       gl.glColor3f(0f, 0f, 0f);
       ddafirst(320,0,320,480,gl,1); 
       ddafirst(50,100,300,100,gl,1);
       ddafirst(300,100,300,300,gl,1);
       ddafirst(300,300,50,300,gl,1);
       ddafirst(50,300,50,100,gl,1);
       ddafirst(340,100,590,100,gl,1);
       ddafirst(590,100,590,300,gl,1);
       ddafirst(590,300,340,300,gl,1);
       ddafirst(340,300,340,100,gl,1);
       gl.glColor3f(1.5f, 0f, 0f);
       ddafirst(80,50,270,350,gl,1);
       arr=outcode(80,50,50,100,300,300);
       brr=outcode(270,350,50,100,300,300);
       String s=visibility(arr, brr);
       System.out.println("s:"+s);
       if(s.equals("completely-invisible")){}
       else if(s.equals("completely-visible"))
           ddafirst(80,50,270,350,gl,1);
       else
           cohensutherland(80,50,270,350,50,100,300,300,arr,brr,gl);
       
      
}
void cohensutherland(int x1,int y1,int x2,int y2,int xl,int yb,int xr,int yt,int arr[],int brr[],GL gl){
    double m,yl,xb,xt,yr;
    int f=0;
    m=(double)(y2-y1)/(x2-x1);
    while(!(visibility(outcode(x1,y1,xl,yb,xr,yt),outcode(x2,y2,xl,yb,xr,yt)).equals("completely-visible"))){
        if(f==0){    
                if(arr[3]==1){
                    yl=m*(xl-x1)+y1;
                    arr=outcode(xl,(int)(yl),xl,yb,xr,yt);   
                    x1=xl;
                    y1=(int)yl;
                    continue;
                }
                if(arr[2]==1){
                    yr=m*(xr-x1)+y1;
                    arr=outcode(xr,(int)(yr),xl,yb,xr,yt);
                    x1=xr;
                    y1=(int)yr;
                    continue;
                }
                if(arr[1]==1){
                    xb=x1+(yb-y1)/m;
                    arr=outcode((int)xb,yb,xl,yb,xr,yt);
                    x1=(int)xb;
                    y1=yb;
                    continue;
                }
                if(arr[0]==1){
                    xt=x1+(yt-y1)/m;
                    arr=outcode((int)xt,yt,xl,yb,xr,yt);
                    x1=(int)xt;
                    y1=yt;
                    continue;
                }
                f=1;
          }
        
        else{
                if(brr[3]==1){
                    yl=m*(xl-x2)+y2;
                    brr=outcode(xl,(int)(yl),xl,yb,xr,yt);   
                    x2=xl;
                    y2=(int)yl;
                    continue;
                }
                if(brr[2]==1){
                    yr=m*(xr-x2)+y2;
                    brr=outcode(xr,(int)(yr),xl,yb,xr,yt);
                    x2=xr;
                    y2=(int)yr;
                    continue;
                }
                if(brr[1]==1){
                    xb=x2+(yb-y2)/m;
                    brr=outcode((int)xb,yb,xl,yb,xr,yt);
                    x2=(int)xb;
                    y2=yb;
                    continue;
                }
                if(brr[0]==1){
                    xt=x2+(yt-y2)/m;
                    brr=outcode((int)xt,yt,xl,yb,xr,yt);
                    x2=(int)xt;
                    y2=yt;
                    continue;
                }
        }
    }
    gl.glColor3f(1.5f, 0f, 0f);
    ddafirst(x1+290, y1, x2+290, y2, gl, 1);
        
}
int[] outcode(int x,int y,int xl,int yb,int xr,int yt){
   int arr[]=new int[4];
    if(x<xl) arr[3]=1;
   if(x>xr) arr[2]=1;
   if(y<yb) arr[1]=1;
   if(y>yt) arr[0]=1;
   return arr;
}
String visibility(int[]arr,int[]brr){
    int crr[]=new int[4];
    if (Arrays.stream(arr).distinct().count()==1 && Arrays.stream(brr).distinct().count()==1)return "completely-visible";
    else {
        for(int i=0;i<4;i++){
            crr[i]=arr[i]& brr[i];
            if (crr[i]!=0)
                return "completely-invisible";
        }
        return "partially-visible";
              
    }
}
 void ddafirst(double x1,double y1,double x2,double y2,GL gl,int c){
        double len;
        double dx,dy,x,y;
        if(Math.abs(x2-x1)>Math.abs(y2-y1)){
            len=Math.abs(x2-x1);
        }
        else{
            len=Math.abs(y2-y1);
        }
        dx=(x2-x1)/len;
        dy=(y2-y1)/len;
        x=x1;
        y=y1;
        int i=1,j;
        gl.glBegin(GL.GL_POINTS);
        while(i<=len){
            if(c==1){ 
                gl.glVertex2i((int)(x),(int)(y));
                x=x+dx;
                y=y+dy;
                i=i+1;
            }
            else if(c==2){ 
                if(i%2==1) gl.glVertex2i((int)(x),(int)(y));
                x=x+dx;
                y=y+dy;
                i=i+1;
            }
            else if(c==3){
                if(i%2==1){
                    for(j=0;j<5;j++){
                        gl.glVertex2i((int)(x),(int)(y));
                        x=x+dx;
                        y=y+dy;
                        i=i+1;
                    }
                    i+=2;
                    x=x+dx;
                    x=x+dx;
                    y=y+dy;
                    y=y+dy;
                }
                else{
                      gl.glVertex2i((int)(x),(int)(y));
                      i+=3;
                      x=x+dx;
                      x=x+dx;
                      y=y+dy;
                      y=y+dy;
                }
            }
            else{
                for(j=0;j<3;j++)
                    gl.glVertex2i((int)(x-j),(int)(y+j));
                for(j=1;j<3;j++)
                    gl.glVertex2i((int)(x+j),(int)(y-j));
                x=x+dx;
                y=y+dy;
                i=i+1;
            }

        }
        gl.glEnd();
    }


public void dispose(GLAutoDrawable arg0)
{
    
}
}
public class Lineclipping
{
public static void main(String args[])
{
    //getting the capabilities object of GL2 profile
    //final GLProfile profile=GLProfile.get(GLProfile.GL);
    GLCapabilities capabilities=new GLCapabilities();
    // The canvas
    final GLCanvas glcanvas=new GLCanvas(capabilities);
    thirdGLEventListener b=new thirdGLEventListener();
    glcanvas.addGLEventListener(b);
    glcanvas.setSize(400, 400);
    //creating frame
    final JFrame frame=new JFrame("Basic Frame");
    //adding canvas to frame
    frame.add(glcanvas);
    frame.setSize(640,480);
    frame.setVisible(true);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

