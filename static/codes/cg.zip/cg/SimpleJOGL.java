package org.yourorghere;

import static java.lang.Math.cos;
import static java.lang.Math.sin;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
//import javax.media.opengl.GLCapabilities;
import javax.media.opengl.glu.GLU;
import javax.swing.JFrame;


class ThirdGLEventListener implements GLEventListener {
/**
 * Interface to the GLU library.
 */
private GLU glu;

/**
 * Take care of initialization here.
 */
@Override
public void init(GLAutoDrawable gld) {
    GL gl = gld.getGL();
    glu = new GLU();

    gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    gl.glViewport(0,0,640,480);
    gl.glMatrixMode(GL.GL_PROJECTION);
    gl.glLoadIdentity();
    glu.gluOrtho2D(0,640,0,480);
}

/**
 * Take care of drawing here.
 */
@Override
public void display(GLAutoDrawable drawable) {
    GL gl = drawable.getGL();

    gl.glClear(GL.GL_COLOR_BUFFER_BIT);
    /*
     * put your code here
     */
    //drawLine(gl, 0, 0, 100, 100);
    gl.glColor3f(1.0f, 1.0f, 1.0f );
    drawLine(gl);

}

@Override
public void reshape(GLAutoDrawable drawable, int x, int y, int width,
        int height) {
}

@Override
public void displayChanged(GLAutoDrawable drawable,
        boolean modeChanged, boolean deviceChanged) {
}

private void drawLine(GL gl) {
   
   gl.glPolygonMode(GL.GL_FRONT_AND_BACK, GL.GL_LINE);      
   gl.glLineWidth(50f); 
   gl.glBegin(GL.GL_POLYGON);
        gl.glColor3f(0f, 1f, 0f);
        gl.glVertex2i(220, 290);
         gl.glColor3f(0f, 1f, 0f);
        gl.glVertex2i(320, 140);
         gl.glColor3f(0f, 1f, 0f);
        gl.glVertex2i(420, 290);
         gl.glColor3f(0f, 1f, 0f);
        gl.glVertex2i(320, 340);
         gl.glColor3f(0f, 1f, 0f);
        gl.glVertex2i(220, 290);
        
    gl.glEnd();
  gl.glPolygonMode(GL.GL_FRONT_AND_BACK, GL.GL_FILL);      
    gl.glBegin(GL.GL_POLYGON);
        gl.glColor3f(1f, 0.5f, 0f);
        gl.glVertex2i(220, 290);
        gl.glVertex2i(320, 140);
        gl.glVertex2i(420, 290);
        gl.glVertex2i(320, 340);
        gl.glVertex2i(220, 290);
        
    gl.glEnd();
    gl.glBegin(GL.GL_POLYGON);
        gl.glColor3f(1f, 1f, 0f);
        gl.glVertex2i(240, 290);
        
        gl.glVertex2i(320, 140);
        gl.glVertex2i(400, 290);
        gl.glVertex2i(320, 340);
        gl.glVertex2i(240, 290);
    gl.glEnd();
   gl.glPolygonMode(GL.GL_FRONT_AND_BACK, GL.GL_LINE);      
   gl.glLineWidth(5f); 
    
    gl.glBegin(GL.GL_POLYGON);
        gl.glColor3f(0f, 1f, 0f);
        gl.glVertex2i(320, 140);
        gl.glVertex2i(340, 100);
        gl.glVertex2i(300,100);
        gl.glVertex2i(320, 140);
    gl.glEnd();
    gl.glBegin(GL.GL_TRIANGLE_FAN);
        gl.glColor3f(1f, 0f, 0f);
        gl.glVertex2i(320, 290);
        for(int i = 0; i <=20;i++) { 
			gl.glVertex2d(320f + (20 * cos(i *  2*3.14 / 20)), 290f+ (20 * sin(i * 2*3.14 / 20)));
}
    gl.glEnd();
}
public void dispose(GLAutoDrawable arg0)
{
    
}
}
public class SimpleJOGL
{
public static void main(String args[])
{
    //getting the capabilities object of GL2 profile
    //final GLProfile profile=GLProfile.get(GLProfile.GL);
    GLCapabilities capabilities=new GLCapabilities();
    // The canvas
    final GLCanvas glcanvas=new GLCanvas(capabilities);
    ThirdGLEventListener b=new ThirdGLEventListener();
    glcanvas.addGLEventListener(b);
    glcanvas.setSize(400, 400);
    //creating frame
    final JFrame frame=new JFrame("Basic frame");
    //adding canvas to frame
    frame.add(glcanvas);
    frame.setSize(640,480);
    frame.setVisible(true);
}
}