package org.yourorghere;

import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCanvas;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;
import javax.swing.JFrame;



    
 class ThirdGLEventListener implements GLEventListener {
/**
 * Interface to the GLU library.
 */
private GLU glu;

/**
 * Take care of initialization here.
 */
@Override
public void init(GLAutoDrawable gld) {
    GL gl = gld.getGL();
    glu = new GLU();

    gl.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    gl.glViewport(0,0,640,480);
    gl.glMatrixMode(GL.GL_PROJECTION);
    gl.glLoadIdentity();
    glu.gluOrtho2D(0,640,0,480);
}

/**
 * Take care of drawing here.
 */
@Override
public void display(GLAutoDrawable drawable) {
    GL gl = drawable.getGL();

    gl.glClear(GL.GL_COLOR_BUFFER_BIT);
    /*
     * put your code here
     */
    //drawLine(gl, 0, 0, 100, 100);
    gl.glColor3f(1.0f, 1.0f, 1.0f );
    drawLine(gl);

}

@Override
public void reshape(GLAutoDrawable drawable, int x, int y, int width,
        int height) {
}

@Override
public void displayChanged(GLAutoDrawable drawable,
        boolean modeChanged, boolean deviceChanged) {
}

private void drawLine(GL gl) {
    gl.glColor3f(0.0f,0.0f,1.0f);
    drawcircle(0,50,100,240,50,0,gl);
    gl.glColor3f(0.0f,0.0f,0.0f);
    drawcircle(0,50,220,240,50,0,gl);
    gl.glColor3f(1.0f,0.0f,0.0f);
    drawcircle(0,50,340,240,50,0,gl);
    gl.glColor3f(1.0f,1.0f,0.0f);
    drawcircle(0,50,155,200,50,0,gl);
    gl.glColor3f(0.0f,1.0f,0.0f);
    drawcircle(0,50,275,200,50,0,gl);
    gl.glColor3f(0.0f,0.0f,1.0f);
    drawcircle(0,50,100,240,50,1,gl);
    gl.glColor3f(0.0f,0.0f,0.0f);
    drawcircle(0,50,220,240,50,2,gl);
    gl.glColor3f(1.0f,0.0f,0.0f);
    drawcircle(0,50,340,240,50,3,gl);
     
    
}
void drawcircle(int x,int y,int h,int k,int r,int m,GL gl){
    int di,del,del1,i,j;
    di=2*(1-r);
    gl.glBegin(GL.GL_POINTS);
    while(y>=0){
        if(m==1){
            for(j=-2;j<2;j++) 
                gl.glVertex2i(x+h+j, y+k+j);
        }
        else if(m==2){
                for(j=-2;j<2;j++){
                    gl.glVertex2i(x+h+j, y+k+j);
                    gl.glVertex2i(-x+h+j, -y+k+j);
                }
        }
        else if(m==3){
            for(j=-2;j<2;j++)
                gl.glVertex2i(-x+h+j, -y+k+j);
        }
        else{
         for(j=-2;j<2;j++){
             gl.glVertex2i(x+h+j, y+k+j);
             gl.glVertex2i(-x+h+j, y+k+j);
             gl.glVertex2i(-x+h+j, -y+k+j);
             gl.glVertex2i(x+h+j, -y+k+j);
            }
        }
       if(di<0){
           del=2*di+2*y-1;
           if(del<=0){ 
               x+=1;
               di=di+2*x+1;
           }
           else{
               x+=1;
               y=y-1;
               di=di+2*x-2*y+2;
           }
           
       }
       else if(di>0){
           del1=2*di-2*x-1;
           if(del1<=0){
               x+=1;
               y=y-1;
               di=di+2*x-2*y+2;
           }
           else{
                y=y-1;
                di=di-2*y+1;
           }
       }
       else{
                x+=1;
               y=y-1;
               di=di+2*x-2*y+2;
       }
       
    }
    gl.glEnd();
}

public void dispose(GLAutoDrawable arg0)
{
    
}
}
public class Cgprac3a
{
public static void main(String args[])
{
    //getting the capabilities object of GL2 profile
    //final GLProfile profile=GLProfile.get(GLProfile.GL);
    GLCapabilities capabilities=new GLCapabilities();
    // The canvas
    final GLCanvas glcanvas=new GLCanvas(capabilities);
    ThirdGLEventListener b=new ThirdGLEventListener();
    glcanvas.addGLEventListener(b);
    glcanvas.setSize(400, 400);
    //creating frame
    final JFrame frame=new JFrame("Basic frame");
    //adding canvas to frame
    frame.add(glcanvas);
    frame.setSize(640,480);
    frame.setVisible(true);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}

