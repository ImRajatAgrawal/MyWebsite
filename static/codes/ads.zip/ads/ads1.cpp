#include<bits/stdc++.h>
using namespace std;
#define mx 999
#define ndt -1
int max(int a,int b){
	if(a>b)return a;
	return b;
}
int countleafs(int vll[]){
	int i=0,count=0;
	while(vll[i]!=mx){
		if(vll[i]!=ndt && (vll[2*i+1]==ndt|| vll[2*i+1]==mx) && (vll[2*i+2]==ndt || vll[2*i+2]==mx))
			count++;
		i++;
	}
	return count;
}

int recurleaf(int arr[],int i){
	if(arr[i]==ndt)
		return 0;
	if((arr[2*i+1]==ndt && arr[2*i+2]==ndt)|| arr[2*i+1]==mx||arr[2*i+2]==mx)
		return 1;
	return(recurleaf(arr,2*i+1)+recurleaf(arr,2*i+2));
}
int height(int arr[],int i){
	if((arr[2*i+1]==ndt  && arr[2*i+2]==ndt) || arr[2*i+1]==mx||arr[2*i+2]==mx)
		return 1;
	return max(height(arr,2*i+1),height(arr,2*i+2))+1;
}
int heightT(int arr[],int i){
	if(arr[i]==ndt || arr[i]==mx)
		return 0;
	else{
		int ld=heightT(arr,(2*i)+1);
		int rd=heightT(arr,(2*i)+2);
		if(ld>rd)
			return ld+1;
		else
			return rd+1;
	}
}
int main(){
int n,i,j,k,x;
int tree[mx]={0};
cout<<"Enter the tree as a list:";
i=-1;
do{
	++i;
	cin>>x;
		while(i!=0 && tree[(i-1)/2]==ndt)
			i+=1;
		tree[i]=x;
		tree[(2*i)+1]=ndt;
		tree[(2*i)+2]=ndt;
}while(x!=mx && i!=mx);

tree[i]=ndt;
tree[i+1]=mx;
cout<<"no of leaf nodes using iterative approach:"<<countleafs(tree)<<endl;
cout<<"height of the binary tree is "<<heightT(tree,0)<<endl;
cout<<"no of leaf nodes using recursive approach:"<<recurleaf(tree,0)<<endl;
return 0;
}

