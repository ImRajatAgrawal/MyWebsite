#include<bits/stdc++.h>
using namespace std;
string ss[]={"RED","BLACK"};
enum COLOR{RED,BLACK};
struct treenode{
        int data;
        struct treenode *lchild;
        struct treenode *rchild;
        COLOR color;
        struct treenode * parent;
    };
    typedef struct treenode tnode;
    typedef tnode *tree;
int getinput(char *str){
		int value;
		printf("\n%s",str);
		scanf("%d",&value);
		return value;
}
tree createnode(){
	tree neww;
	neww=(tree)malloc(sizeof(tnode));
	if(neww==NULL)
		printf("AVAIL STACK UNDERFLOW");
	return neww;
}
void preorder(tree root){
    if(root!=NULL){
        printf("%d  ",root->data);
        preorder(root->lchild);
        preorder(root->rchild);
    }
}            
void postorder(tree root){
    if(root!=NULL){
        postorder(root->lchild);
        postorder(root->rchild);
        printf("%d  ",root->data);
    }
}           
void inorder(tree root){
    if(root!=NULL){
        inorder(root->lchild);
        cout<<root->data<<" "<<ss[root->color]<<endl;
        inorder(root->rchild);
    }
}   
int leafbt(tree root){
    if(root==NULL)
        return 0;
    if(root->lchild==NULL && root->rchild==NULL){
        printf("%4d",root->data);
        return 1;
    }
    return (leafbt(root->lchild)+leafbt(root->rchild));
}
int parentbt(tree root){
    if(root==NULL || (root->lchild==NULL && root->rchild==NULL))
        return 0;
    printf("%4d",root->data);
    return (parentbt(root->lchild)+parentbt(root->rchild)+1);
}
int maxof(int l,int r){
   int max;
   if(l>r)
    max=l;
   else if(l<r)
    max=r;
   else
    max=l;
 return max;
}   
int heightT(tree root){
    int lefth,righth;
    if(root==NULL || (root->lchild==NULL && root->rchild==NULL))
        return 0;    
    lefth=heightT(root->lchild);
    righth=heightT(root->rchild);
    return (maxof(lefth,righth)+1);   
}
void printlevel(tree root,int i){
   if(root==NULL)
    return;
   if(i==1){
    cout<<"| "<<root->data<<" | "<<ss[root->color]<<" |";
    if(root->parent!=NULL)
    	cout<<" "<<root->parent->data<<" |";
    else
    	cout<<" "<<'N'<<" |";
    if(root->lchild!=NULL)
    	cout<<" "<<root->lchild->data<<" |";
    else
    	cout<<" "<<'N'<<" |";
    if(root->rchild!=NULL)
    	cout<<" "<<root->rchild->data<<" |";
    else
    	cout<<" "<<'N'<<" |";
    cout<<"        ";
    return;
   }
    printlevel(root->lchild,i-1);
    printlevel(root->rchild,i-1);        
}			

void levelorder(tree root){
    int i;
    for(i=1;i<=heightT(root)+1;i++){
        printlevel(root,i);
        cout<<"\n\n";
       }
}

