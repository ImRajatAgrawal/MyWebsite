package adsp7;
public class Adsp7 {
    String name;
    public Adsp7(String name){
        this.name=name;
    }
    @Override
    protected void finalize()throws Throwable{
        System.out.println("Object garbage collected is :"+this.name);
    }
    public static void main(String[] args) throws InterruptedException {
        Runtime rs = Runtime.getRuntime();
        System.out.println("Free memory in JVM before Garbage Collection = "+rs.freeMemory());
        Adsp7 aa=new Adsp7("obj1");
        aa=null;
        System.gc();
        Adsp7 bb=new Adsp7("obj2");
        Adsp7 cc=new Adsp7("obj3");
        bb=cc;
        System.gc();
        new Adsp7("obj4");
        System.gc();
        System.out.println("Free memory in JVM after Garbage Collection = "+rs.freeMemory());
        
    }
    
    
}
