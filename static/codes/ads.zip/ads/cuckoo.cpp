#include<bits/stdc++.h>
using namespace std;
int main(){
	int i,j,p,k,n,m,l,x,y,z,q;
	vector<int> vll;
	cout<<"Enter size of table 1:";
	cin>>n;
	cout<<"Enter size of table 2:";
	cin>>m;
	cout<<"Enter the sequence of insertions:\n";
	p=0;
	do{
		cin>>x;
		if(x==-1)
			break;
		vll.push_back(x);
		p+=1;
	}while(true);
	int brr[p+1]={0};
	int crr[p+1]={0};
	for(i=0;i<p;i++){
		x=vll[i]%n;
		k=0;
		if(brr[x]==0){
			brr[x]=vll[i];
		}
		else{
				y=brr[x]%m;
				if(crr[y]==0){
					crr[y]=brr[x];
					brr[x]=vll[i];
				}
				else{
					c:
					z=crr[y]%n;
					if(brr[z]==0){
						brr[z]=crr[y];
						crr[y]=brr[x];
						brr[x]=vll[i];
					}
					else{
							q=brr[z]%m;
                            if(crr[q]==0){
                                crr[q]=brr[z];
                                brr[z]=crr[y];
                                crr[y]=brr[x];
                                brr[x]=vll[i];
                            }
                            else{
                                if(k==p){
                                    cout<<"Deadlock element"<<vll[i]<<"cannot be inserted"<<endl;
                                    break;
                                   }
                                   cout<<y<<" ";
                                y=q;
                                k+=1;
                                goto c;
                            }
					}
				}
		}
	}
	cout<<"Hash Table 1"<<endl;
    for(i=0;i<p;i++){
        cout<<i<<":"<<brr[i]<<endl;
    }
    cout<<"Hash table 2"<<endl;
    for(i=0;i<p;i++){
        cout<<i<<":"<<crr[i]<<endl;
    }
    
	return 0;
}
