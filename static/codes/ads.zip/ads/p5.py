
def KMPSearch(pat, txt):
	M = len(pat)
	N = len(txt)

	prefixtab = [0]*M
	j = 0
	c=0
	prefixtable(pat, M, prefixtab)
	print("prefix table:")
	for i in pat:print(i,end=" ")
	print("\n------------------")
	for i in prefixtab:print(i,end=" ")
	print()
	i = 0
	f=0
	while i < N:
		if pat[j] == txt[i]:
			i += 1
			j += 1
			c+=1
		if j == M:
			print("Found pattern at index " + str(i-j))
			f=1
			j = prefixtab[j-1]
			print("Total no of comparisions:",c)
		elif i < N and pat[j] != txt[i]:
			if j != 0:
				j = prefixtab[j-1]
				c+=1
			else:
				i += 1
				c+=1
	print("pattern not found in text" if f==0 else "")

def prefixtable(pat, M, prefixtab):
	len = 0
	prefixtab[0]
	i = 1

	while i < M:
		if pat[i]== pat[len]:
			len += 1
			prefixtab[i] = len
			i += 1
		else:
			if len != 0:
				len = prefixtab[len-1]
			else:
				prefixtab[i] = 0
				i += 1
txt=input("Enter text: ")
pat=input("Enter pattern: ")
KMPSearch(pat, txt)

