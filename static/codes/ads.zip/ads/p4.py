import numpy as np
def func(lst,arr,brr,n,nb,g,md,c):
    for k in lst:
        x = k % md
        bb = np.binary_repr(x, c)
        y =bb[0:g]
        z = int(y,2)
        if brr[z] < n:
            arr[z][brr[z]]=k
            brr[z] += 1
        else:
            print("bucket no",y, "is full for gain size ", g,"while inserting value",k)
            g += 1
            nb = 2 ** g
            arr = [[int(0) for i in range(n)] for j in range(nb)]
            brr = [int(0) for i in range(nb)]
            return func(lst,arr,brr,n,nb,g,md,c)
    print("gain size:",g,"   ","no of buckets[0-%d]:"%(nb-1),nb)
    print("keys","\t","mod",md,"\t","Binary","   ","Bucket no")
    print("-------------------------------------------")
    for i in range(nb):
        for j in range(n):
            if arr[i][j]!=0:
                print(arr[i][j],"\t","%.2d"%(arr[i][j]%md),"        ",np.binary_repr(arr[i][j]%md,c),"   ",i)
print("Enter bucket size:")
n=int(input())
print("Enter gain factor:")
g=int(input())
print("Enter modulo value:")
md=int(input())
print("Enter sequence of insertions:")
lst=[int(i) for i  in input().split(',')]
nb = 2 ** g
arr = [[0 for i in range(n)] for j in range(nb)]
brr = [0 for i in range(nb)]
crr=[4068,1752,3429,2130,2854,1591,2203,1423,3017,2333,3923,4817,4876]
c=len(bin(md-1))-2
func(lst,arr,brr,n,nb,g,md,c)

