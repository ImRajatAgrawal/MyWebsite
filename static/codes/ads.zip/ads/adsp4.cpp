//PROGRAM TO IMPLEMENT VARIOUS OPERATIONS ON A RED BLACK TREE
#include<bits/stdc++.h>
#include "treeadt.h"
using namespace std;
#define mxval 999
tree rr=NULL;
tree leftrotate(tree x,tree root){
    tree y = x->rchild;
    x->rchild = y->lchild;
    if(y->lchild!=NULL)
        y->lchild->parent = x;
    y->parent = x->parent;
    if(x->parent == NULL)
        root = y;
    else{
        if(x == x->parent->lchild)
            x->parent->lchild = y;
        else
            x->parent->rchild = y;
    }
    y->lchild = x;
    x->parent = y;
    return root;
}
tree rightrotate(tree x,tree root){
    tree y = x->lchild;
    x->lchild = y->rchild;
    if(y->rchild!=NULL)
        y->rchild->parent = x;
    y->parent = x->parent;
    if(x->parent == NULL)
        root = y;
    else{
        if(x == x->parent->rchild)
            x->parent->rchild = y;
        else
            x->parent->lchild = y;
    }
    y->rchild = x;
    x->parent = y;
    return root;
}

tree delete_fixup(tree x,tree root){
	tree w;
	while((x!=root)&&(x!=NULL)&&(x->color==BLACK)){
		if(x == x->parent->lchild){
		    w = x->parent->rchild;
		    if(w!=NULL){
		        if(w->color==RED){
		        	cout<<"case 3.1 DB SIBLING IS RED"<<endl;
		            w->color = BLACK;
		            x->parent->color = RED;
		            root=leftrotate(x->parent,root);
		            w = x->parent->rchild;
		        }
		        if(((w->lchild==NULL)||(w->lchild->color==BLACK))&&((w->rchild==NULL)||(w->rchild->color==BLACK))){
		            cout<<"case 3.2 DB SIBLING IS BLACK AND BOTH ITS CHILDREN ARE ALSO BLACK"<<endl;
		            w->color = RED;
		            x = x->parent;
		        }
		        else{
		            if((w->rchild==NULL)||(w->rchild->color==BLACK)){
		               	cout<<"case 3.3 TRIANGLE CASE"<<endl;
		                if(w->lchild!=NULL)
		                    w->lchild->color = BLACK;
		                w->color = RED;
		                root=rightrotate(w,root);
		                w = x->parent->rchild;
		            }
		            cout<<"case 3.4 : SL EXISTS WITH RED COLOR"<<endl;
		            w->color = x->parent->color;
		            x->parent->color = BLACK;
		            w->rchild->color = BLACK;
		            root=leftrotate(x->parent,root);
		            x = root;
		        }
		    }
		}
		else{
		    w = x->parent->lchild;
		    if(w!=NULL)
		    {
		        if(w->color==RED)
		        {
		            cout<<"case 3.1 DB SIBLING IS RED"<<endl;
		            w->color = BLACK;
		            x->parent->color = RED;
		            root=rightrotate(x->parent,root);
		            w = x->parent->lchild;
		        }
		        if(((w->rchild==NULL)||(w->rchild->color==BLACK))&&((w->lchild==NULL)||(w->lchild->color==BLACK)))
		        {
		            w->color = RED;
		            x = x->parent;
		             cout<<"case 3.2 DB SIBLING IS BLACK AND BOTH ITS CHILDREN ARE ALSO BLACK"<<endl;
		        }
		        else
		        {
		            if((w->lchild==NULL)||(w->lchild->color==BLACK))
		            {
		               cout<<"case 3.3 Triangle case"<<endl;
		                if(w->rchild!=NULL)
		                    w->rchild->color = BLACK;
		                w->color = RED;
		                root=leftrotate(w,root);
		                w = x->parent->lchild;
		            }
		            cout<<"case 3.4 :SL EXISTS WITH RED COLOUR"<<endl;
		            w->color = x->parent->color;
		            x->parent->color = BLACK;
		            w->lchild->color = BLACK;
		            root=rightrotate(x->parent,root);
		            x = root;
		        }
		    }
		}
	}
	if(x!=NULL)
    x->color = BLACK;
    return root;
}
tree search(int data,tree root){
    tree n = root;
    while(n != NULL){
        if(n->data==data)
            return n;
        else{
            if(data<n->data)
                n = n->lchild;
            else
                n = n->rchild;
        }
    }
    cout<<"Data not found";
    return NULL;
}
 tree successor(tree n,tree root){
    tree m = root;
    if(n->rchild!=NULL){
        tree c = n->rchild;
        while(c->lchild!=NULL)
            c = c->lchild;
        return c;
    }
    else{
        tree p = n->parent;
        while(p!=NULL&&(n==p->rchild)){
            n = p;
            p = p->parent;
        }
        return p;
    }
}
tree predecessor(tree n,tree root){
    tree m = root;
    if(n->lchild!=NULL){
        tree c = n->lchild;
        while(c->rchild!=NULL)
            c = c->rchild;
        return c;
    }
    else{
        tree p = n->parent;
        while(p!=NULL&&(n==p->lchild)){
            n = p;
            p = p->parent;
        }
        return p;
    }
}

tree deletenode(int data,tree root){
    tree z = search(data,root);
    if(z==NULL)
        return root;
    tree y = NULL, x;
    if((z->lchild==NULL)&&(z->rchild==NULL))
        y = z;
    else
        y = predecessor(z,root);
    if(y==NULL)
        y = successor(z,root);
    if(y->lchild!=NULL)
        x = y->lchild;
    else
        x = y->rchild;
    if(x!=NULL)
        x->parent = y->parent;
    if(y->parent==NULL)
        root=x;
    if(y!=z)
        z->data = y->data;
    if(y->color==BLACK)
        root=delete_fixup(y,root);
    else
    	cout<<"case 1: deleted node is red"<<endl;
   	if(y == y->parent->lchild)
        y->parent->lchild = x;
    else
        y->parent->rchild = x;
    return root;
}
int atlevel(tree root,int key,int level){
	if(root==NULL)
		return 0;
	if(root->data==key)
		return level;
	int lev= atlevel(root->lchild,key,level+1);
	if(lev!=0)
		return lev;
	lev= atlevel(root->rchild,key,level+1);
	return lev;
}


tree fixredred(tree z,tree root){
    while(z!=root && z->parent->color==RED){
        
        if(z->parent==z->parent->parent->lchild){
        
            tree y = z->parent->parent->rchild;
            if(y!=NULL && y->color==RED){
                cout<<"case 2: z.uncle is red"<<endl;
                z->parent->color = BLACK;
                y->color = BLACK;
                z->parent->parent->color = RED;
                z = z->parent->parent;
            }
            else{
                if(z==z->parent->rchild){
                   	cout<<"case 3: triangle case and z.uncle is black"<<endl;
                    z = z->parent;
                    root=leftrotate(z,root);
                }
                cout<<"case 4: z.uncle is black and new node makes a line"<<endl;
                z->parent->color = BLACK;
                z->parent->parent->color = RED;
                root=rightrotate(z->parent->parent,root);
            }
        }
        else{
            tree y = z->parent->parent->lchild;
            if(y!=NULL && y->color==RED){
            	cout<<"case 2: z.uncle is red"<<endl;
                z->parent->color = BLACK;
                y->color = BLACK;
                z->parent->parent->color = RED;
                z = z->parent->parent;
            }
            else{
                if(z==z->parent->lchild){
                    cout<<"case 3: triangle case and z.uncle is black"<<endl;
                    z = z->parent;
                    root=rightrotate(z,root);
                }
                cout<<"case 4: z.uncle is black and new node makes a line"<<endl;
                z->parent->color = BLACK;
                z->parent->parent->color = RED;
                root=leftrotate(z->parent->parent,root);
            }
        }
    }
    root->color = BLACK;
    return root;
}
tree insertbst(tree root,int key,tree y){
	if(root==NULL){
		root=createnode();
		if(root==NULL)
			printf("\ninsert failed,avail underflow");
			else{
					root->data=key;
					root->lchild=root->rchild=NULL;
					root->color=RED;
					root->parent=y;
					if(root->parent!=NULL){
						if(root->data<root->parent->data)
							root->parent->lchild=root;
						else
							root->parent->rchild=root;
					}
					if(rr!=NULL)
						cout<<"Initial level of the key "<<key<<" is:"<<atlevel(rr,key,1)<<endl;
					else
						cout<<"Initial level of the key "<<key<<" is:"<<1<<endl;
					if(root->parent!=rr){
						rr=fixredred(root,rr);
					}
				}
   }
   else{
   	if(key<root->data)
   		return insertbst(root->lchild,key,root);
   	else if(key>root->data)
   		return insertbst(root->rchild,key,root);
   	else
   		printf("\nDuplicate key");
   	}
   	return root;
}
tree createbst(){
	int key,c=0;
	tree root=NULL;
	tree y=NULL;
	do{
		printf("\nEnter key to insert[%d to end]:",mxval);
			scanf("%d",&key);
			if(key!=mxval){
				root=insertbst(root,key,y);
				if(c==0){
					root->color=BLACK;
					cout<<"case 1: inserting root node"<<endl;
					rr=root;
					c=1;
				}
				else
					root=rr;
					
			}
	}while(key!=mxval);
	return root;
}
int main(){
	tree root=NULL,root1=NULL;
	int key;
	root=createbst();
	cout<<"Level order traversal of the tree is:"<<endl;
	levelorder(root);
	cout<<"Enter node to delete:";
	cin>>key;
	root=deletenode(key,root);
	levelorder(root);
	cout<<"Enter node to delete:";
	cin>>key;
	root=deletenode(key,root);
	levelorder(root);
	cout<<"Enter node to delete:";
	cin>>key;
	root=deletenode(key,root);
	levelorder(root);
	return 0;
}

/*
OUTPUT:

Enter key to insert[999 to end]:6
Initial level of the key 6 is:1
case 1: inserting root node

Enter key to insert[999 to end]:4
Initial level of the key 4 is:2

Enter key to insert[999 to end]:7
Initial level of the key 7 is:2

Enter key to insert[999 to end]:2
Initial level of the key 2 is:3
case 2: z.uncle is red

Enter key to insert[999 to end]:5
Initial level of the key 5 is:3

Enter key to insert[999 to end]:20
Initial level of the key 20 is:3

Enter key to insert[999 to end]:17
Initial level of the key 17 is:4
case 3: triangle case and z.uncle is black
case 4: z.uncle is black and new node makes a line

Enter key to insert[999 to end]:16
Initial level of the key 16 is:4
case 2: z.uncle is red

Enter key to insert[999 to end]:999
Level order traversal of the tree is:
| 6 | BLACK | N | 4 | 17 |        

| 4 | BLACK | 6 | 2 | 5 |        | 17 | RED | 6 | 7 | 20 |        

| 2 | RED | 4 | N | N |   | 5 | RED | 4 | N | N |   | 7 | BLACK | 17 | N | 16 |  
      
      | 20 | BLACK | 17 | N | N |        

| 16 | RED | 7 | N | N |        

Enter node to delete:6
case 1: deleted node is red
| 5 | BLACK | N | 4 | 17 |        

| 4 | BLACK | 5 | 2 | N |        | 17 | RED | 5 | 7 | 20 |        

| 2 | RED | 4 | N | N |  | 7 | BLACK | 17 | N | 16 |   | 20 | BLACK | 17 | N | N |        

| 16 | RED | 7 | N | N |        

Enter node to delete:4
case 1: deleted node is red
| 5 | BLACK | N | 2 | 17 |        

| 2 | BLACK | 5 | N | N |        | 17 | RED | 5 | 7 | 20 |        

| 7 | BLACK | 17 | N | 16 |        | 20 | BLACK | 17 | N | N |        

| 16 | RED | 7 | N | N |        

Enter node to delete:20
case 3.3 Triangle case
case 3.4 :SL EXISTS WITH RED COLOUR
| 5 | BLACK | N | 2 | 16 |        

| 2 | BLACK | 5 | N | N |        | 16 | RED | 5 | 7 | 17 |        

| 7 | BLACK | 16 | N | N |        | 17 | BLACK | 16 | N | N |        


*/
