#include<bits/stdc++.h>
using namespace std;
int hashfun(int x,int n){
	return x%(n);
}
vector<pair<int,double> > linear(int l,int n,int arr[],vector<int>vll,vector<pair<int,double> >vrr){
	int x,p,i,c=0,coll=0;
	double ld;
	i=0;
	cout<<"data "<<" "<<"collisions"<<" "<<"load factor"<<endl;
	while(true){
		coll=0;
		x=hashfun(vll[i],n);
		p=x;
		if(arr[x]==0){
			cout<<"  "<<vll[i]<<"       ";
			arr[x]=vll[i++];
			ld=double(i)/n;
			vrr.push_back(make_pair(coll,ld));
			cout<<coll<<"          "<<ld<<endl;
		}
		else{
				if(x<l)
					x+=1;
				else
					x=0;
				coll+=1;
				while(x!=p){
					if(arr[x]==0){
                        cout<<"  "<<vll[i]<<"       ";
						arr[x]=vll[i++];
						ld=double(i)/n;
						vrr.push_back(make_pair(coll,ld));
						cout<<coll<<"          "<<ld<<endl;
						break;
					}
					x+=1;
					coll+=1;
					if(x==l)
						x=0;
				}
				if(x==p){
					cout<<"element cannot be inserted,no space available"<<endl;
					i++;
				}
		}
		if(i==l)
			break;
	}
	return vrr;

}
int quadhash(int x,int n,int i){
	return (hashfun(x,n)+(i*i))%n;
}
vector<pair<int,double> > quadratic(int p,int n,int arr[],vector<int>vll,vector<pair<int,double> >vrr){
	int i=0,x,k=1,c=0,coll=0,j;
	double ld;
	cout<<"data "<<" "<<"collisions"<<" "<<"load factor"<<endl;
	for(j=0;j<p;j++){
		k=0;
		coll=0;
		x=quadhash(vll[j],n,k);
		if(arr[x]==0){
			arr[x]=vll[j];
			cout<<"  "<<vll[j]<<"       ";
			c+=1;
			ld=double(c)/(n);
			vrr.push_back(make_pair(coll,ld));
			cout<<coll<<"          "<<ld<<endl;
		}
		else{
				coll+=1;
				k+=1;
				while(k!=(n+1)/2){
					x=quadhash(vll[j],n,k);
					if(arr[x]==0){
						cout<<"  "<<vll[j]<<"       ";
						c+=1;
						ld=double(c)/(n);
						arr[x]=vll[j];
						vrr.push_back(make_pair(coll,ld));
						cout<<coll<<"          "<<ld<<endl;
						break;
					}
					else
						coll+=1;
					k+=1;
				}
				if(k==(n+1)/2)
					cout<<"element "<<vll[j]<<" cannot be inserted,index out of bound"<<endl;
		}
	}
	return vrr;
}
void initialize(int arr[],int n){
	for(int i=0;i<n;i++){
		arr[i]=0;
	}
}
int hash1(int x,int n,int i){
	return (x+(i*(7-(x%7))))%n;
}
vector<pair<int,double> > doublehash(int p,int n,int arr[],vector<int>vll,vector<pair<int,double> >vrr){
	int c,i,j,x,k,l,coll=0;
	double ld;
	c=0;
	cout<<"data "<<" "<<"collisions"<<" "<<"load factor"<<endl;
	for(i=0;i<p;i++){
		j=0;
		coll=0;
		x=hash1(vll[i],n,j);
		if(arr[x]==0){
			arr[x]=vll[i];
			cout<<"  "<<vll[i]<<"       ";
			c+=1;
			ld=double(c)/(n);
			vrr.push_back(make_pair(coll,ld));
			cout<<coll<<"          "<<ld<<endl;
		}
		else{
			coll+=1;
			j+=1;
			while(j<=7){
					x=hash1(vll[i],n,j);
					if(arr[x]==0){
						cout<<"  "<<vll[i]<<"       ";
						c+=1;
						ld=double(c)/(n);
						arr[x]=vll[i];
						vrr.push_back(make_pair(coll,ld));
						cout<<coll<<"          "<<ld<<endl;
						break;
					}
					else
						coll+=1;
					j+=1;
			}
				if(j>7)
					cout<<"element "<<vll[i]<<" cannot be inserted,space full"<<endl;

		}
	}
	return vrr;
}
int main(){
	vector<int>vll;
	int n,i,x,c,p=0;
	double ld;
	cout<<"Enter table size:";
	cin>>n;
	int arr[n+1];
	cout<<"Enter the sequence of data elements:"<<endl;
	while(true){
		cin>>x;
		if(x==-1)
			break;
		vll.push_back(x);
		p+=1;
	}
	do{
		cout<<"_______hashing techniques______"<<endl;
		cout<<"0.Exit"<<endl;
		cout<<"1.linear probing"<<endl;
		cout<<"2.quadratic hashing"<<endl;
		cout<<"3.double hashing"<<endl;
		cout<<"Enter your choice:";
		cin>>c;
		switch(c){
			case 0:
					exit(0);
			case 1:{
					vector<pair<int,double> >vrr;
					initialize(arr,n);
					vrr=linear(p,n,arr,vll,vrr);
					for(i=0;i<n;i++){
						if(arr[i]!=0)
							cout<<i<<":"<<arr[i]<<endl;
						else
							cout<<i<<":"<<"__"<<endl;
					}
					break;
				}
			case 2:
					{vector<pair<int,double> >vrr;
					initialize(arr,n);
					vrr=quadratic(p,n,arr,vll,vrr);
					for(i=0;i<n;i++){
						if(arr[i]!=0)
							cout<<i<<":"<<arr[i]<<endl;
						else
							cout<<i<<":"<<"__"<<endl;
					}
					break;
					}
			case 3:{
					vector<pair<int,double> >vrr;
					initialize(arr,n);
					vrr=doublehash(p,n,arr,vll,vrr);
					for(i=0;i<n;i++){
						if(arr[i]!=0)
							cout<<i<<":"<<arr[i]<<endl;
						else
							cout<<i<<":"<<"__"<<endl;
					}
					break;
					}				
			default:{
					cout<<"Invalid input"<<endl;
					}
		}

	}while(c>0);
	return 0;
}

