#include<bits/stdc++.h>
using namespace std;
struct kdnode{
	int point[2];
	kdnode *lchild,*rchild;
};
typedef struct kdnode tnode;
typedef tnode *tree;
tree createkdnode(){
	tree neww;
	neww=(tree)malloc(sizeof(tnode));
	if (neww==NULL)
		cout<<"Avail stack underflow";
	return neww;
}
tree insertnode(tree root,int point[],int depth,int k){
	if(root==NULL){
		root=createkdnode();
		root->point[0]=point[0];
		root->point[1]=point[1];
		return root;
	}
	int c=depth%k;
	if(point[c]<root->point[c])
		root->lchild=insertnode(root->lchild,point,depth+1,k);
	else
		root->rchild=insertnode(root->rchild,point,depth+1,k);
	return root;
}
void printlevel(tree root,int i){
	if (root==NULL)
		return;
	if(i==1){
		cout<<root->point[0]<<" | "<<root->point[1]<<"    ";
		return;
	}
	printlevel(root->lchild,i-1);
	printlevel(root->rchild,i-1);
}
int heightT(tree root){ 
   if (root==NULL)  
       return 0; 
   else{ 
       int lDepth = heightT(root->lchild); 
       int rDepth = heightT(root->rchild); 
  
       if (lDepth > rDepth)  
           return(lDepth+1); 
       else return(rDepth+1); 
   } 
}  
void levelorder(tree root){
	for(int i=1;i<=heightT(root);i++){
		printlevel(root,i);
		cout<<"\n\n";
	}
}
void rangesearch(tree root,int xmn,int xmx,int ymn,int ymx){
	if(root!=NULL){
		rangesearch(root->lchild,xmn,xmx,ymn,ymx);
		if(root->point[0]>=xmn && root->point[0]<=xmx && root->point[1]>=ymn && root->point[1]<=ymx)
			cout<<root->point[0]<<" | "<<root->point[1]<<"\n";
		rangesearch(root->rchild,xmn,xmx,ymn,ymx);
	}	
}
int main(){
	tree root=NULL;
	int x,y,xmn,xmx,ymn,ymx;
	cout<<"Enter nodes as (x,y) to create a kd-tree [ 999 to exit]:\n";
	do{
		int point[2];
		cin>>x>>y;
		if(x==999 || y==999)
			break;
		point[0]=x;
		point[1]=y;
		root=insertnode(root,point,0,2);
	}while(x!=999 && y!=999);
	cout<<"level order traversal of the tree is:"<<endl;
	levelorder(root);
	cout<<"Enter a range of points for range-search:"<<endl;
	cin>>xmn>>xmx>>ymn>>ymx;
	rangesearch(root,xmn,xmx,ymn,ymx);
	return 0;
}
