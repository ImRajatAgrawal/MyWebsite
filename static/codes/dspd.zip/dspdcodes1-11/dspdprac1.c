/*FILENAME	:DSPDPRAC1.C*/
/*AUTHOR NAME	:RAJAT AGRAWAL*/
/*AIM	:TO STUDY ARRAY ADT AND TO IMPLEMENT VARIOUS OPERATIONS ON AN ARRAY ADT*/
/*PROBLEM STATEMENT    : CREATE AN ARRAY AND IMPLEMENT THE OPERATIONS -TRAVERSE(),INSERT_ELEMENT(),DELETE_ELEMENT(),SORT(),SEARCH(),MERGE(),COPY(),CREATE(),ISFULL(),ISEMPTY() AND LENGTH().WRITE A CPROGRAM TO DEMONSTRATE AN ARRAY ADT USING DEFINED OPERATIONS APPROPRIATELY USING A MENU DRIVEN APPROACH. YOUR PROGRAM SHOULD BE ABLE TO PRINT THE ARRAY CONTENTS APPROPRIATELY AT ANY OR ALL INSTANCES.YOU MUST ALSO ENSURE THAT NO INPUT IS ACQUIRED WITHIN THE BODY OF FUNCTIONS,NOR DISPLAY ANY PROMPTS/RESULTS.*/
/*HEADER FILE INCLUSION*/
    #include<stdio.h>
    #include<stdlib.h>
/*PRE-PROCESSOR DIRECTIVES DECLARATION*/
    #define maxsize 5
    #define minval -999
/*USER DEFINED FUNCTION DECLARATION*/
    int getvalue();
    void initialize(int arr[]);
    void create(int arr[],int *);
    int length(int arr[]);
    int isfull(int arr[]);
    int isempty(int arr[]);
    void traverse(int arr[],int );
    void display(int arr[]);
    int insert_element(int[],int ,int ,int );
    void search(int arr[],int ,int );
    int delete_element(int arr[],int ,int );
    void sort(int arr[],int ,int );
    int copy(int arr[],int brr[],int );
    int merge(int arr[],int brr[],int crr[],int ,int );
/*THE DRIVER FUNCTION*/
void main()
{
int len=0,i,pos,arr[maxsize],brr[maxsize], crr[maxsize*2],choice,value,len1,len2=0;
initialize(arr);
  do{
   printf("\n");
   printf("____________________________ARRAY ADT_________________________________");
   printf("\n0.exit()     1.create()      2.isempty()   3.isfull()     4.length()");
   printf("\n5.display()  6.insert()      7.delete()    8.search()     9.sort()");
   printf("\n10.merge()   11.copy()       12.traverse  ");
   printf("\nEnter operation to perform:");
   scanf("%d",&choice);
      switch(choice){
		   case 0:
		   		  printf("\tYOU HAVE OPTED TO EXIT...\n");
				  exit(0);
		   case 1:
				  create(arr,&len);
				  break;
		   case 2:
				  printf("ISEMPTY=%d",isempty(arr));
				  break;
		   case 3:
				  printf("ISFULL=%d",isfull(arr));
				  break;
		   case 4:
			      len=length(arr);
				  printf("LENGTH=%d",len);
				  break;
		   case 5:
				  display(arr);
				  break;
		   case 6:
			      if(len==maxsize)
			      {	
			      	printf("\nARRAY IS FULL:INSERTION NOT POSSIBLE");
			      	break;
			      }
			      do
			      {
			        printf("ENTER INDEX(0-%d):",len);
			        scanf("%d",&pos);
			      }while((pos>len)||(pos<0));
			      value = getvalue();
			      	len=insert_element(arr,value,pos,len);
			      break;
		   case 7:
		   		  if(len==0)
		   			printf("ARRAY IS EMPTY NOTHING TO DELETE");
		   		  else{
		   		  do
			      {
			        printf("ENTER INDEX TO DELETE AT(0-%d):",len-1);
			        scanf("%d",&pos);
			      }while((pos>len-1)||(pos<0));
			      	len=delete_element(arr,len,pos);
			      }
			      break;
		   case 8:
			      printf("\nENTER ELEMENT TO SEARCH:");
			      scanf("%d",&value);
			      	search(arr,value,len);
			      break;
		   case 9:
			      printf("\n1.SORT IN ASCENDING ORDER");
			      printf("\n2.SORT IN DESCENDING ORDER");
			      printf("\nENTER OPERATION?");
			      scanf("%d",&choice);
			      	sort(arr,len,choice);
			      break;
		   case 10:
			       len1=merge(arr,brr,crr,len,len2);
			       printf("\n MERGED ARRAY:");
			         for(i=0;i<len1;i++)
			            printf("%d ",crr[i]);
			       break;
		   case 11:
			       len2=copy(arr,brr,len);
			       printf("\nCOPIED ARRAY:");
			       for(i=0;i<len2;i++)
			          printf("%d ",brr[i]);
			       break;
		   case 12:
			       printf("\nARRAY ELEMENTS AFTER TRAVERSING ARE:");
			      	 traverse(arr,len);
			       break;
		   default:
				   printf("INVALID CHOICE");
		   }
	}while(choice!=0);
}
/*FUNCTIONS DEFINITION*/
void initialize(int arr[]){
   arr[0]=minval;
}
int getvalue(){
	int val;
	printf("ENTER VALUE OF ELEMENT:");
	 	 scanf("%d",&val);
    return val;
}
int length(int arr[]){
	int len=0;
	while (arr[len]!= minval || len>maxsize)
		len += 1;
	return len;
}
void traverse(int arr[],int len){
	int i=0;
	for(i=0;i<len;i++)
		printf("%d ",arr[i]+10);
}
int isfull(int arr[]){
   if(length(arr)==maxsize)
       return 1;
   return 0;
}
int isempty(int arr[]){
   if(length(arr)==0)
      return 1;
   return 0;
}
int copy(int arr[],int brr[],int len){  
   int i,count=0;
    for(i=0;i<len;i++)
    {    brr[i]=arr[i];
         count++;
    }
   return count;
}
void create(int arr[], int *len){
  int val;
	do{
		if(*len == maxsize){
			printf("\n\tARRAY BOUNDS EXCEEDED...\n");
			break;
			}
		else{
			val = getvalue();
			if(val == minval)
			continue;
			*len = insert_element(arr, val,*len,*len);
			}
	}while((*len == maxsize)||(val != minval));
}
void display(int arr[])
{
 int i;
 printf("\nARRAY ELEMENTS:");
  for(i=0;i<length(arr);i++)
    printf("%d ",arr[i]);
}
int insert_element(int arr[], int val, int index, int len){
	int i;
	if(len ==maxsize){
		printf("\tARRAY BOUNDS REACHED..\n");
		return len;
	}
	for(i = len; i >= index; i--)
		arr[i+1] = arr[i];
	arr[index] = val;
	return (len+1);
}
int delete_element(int arr[],int len,int index){
	int i;
	for (i=index;i<len;i++)
		arr[i] = arr[i+1];
	len=len-1;
	return len;
}
void search(int arr[],int value,int len){
    int i,pos,flag=0;
    for(i=0;i<len;++i)
    {    if(arr[i]==value)
         {
            pos=i+1;
            flag=1;
         }
    }
    if(flag==0)
    printf("ELEMENT NOT FOUND");
    else
    printf("%d IS FOUND AT POSITION:%d",value,pos);
}
void sort(int arr[],int len,int choice1){
    int i,j,flag;
    if(choice1==1)
    {
        for(i=0;i<len;++i)
        {
            for(j=0;j<len-1;++j)
            {
                if(arr[j]>arr[j+1])
                {
                    flag=arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=flag;
                }
            }
        }
        printf("THE ARRAY IN ASCENDING ORDER IS:");
      for(i=0;i<len;i++)
         printf("%d ",arr[i]);
     }
     else
     if(choice1==2)
     {
     for(i=0;i<len;++i)
        {
            for(j=0;j<len-1;++j)
            {
                if(arr[j]<arr[j+1])
                {
                    flag=arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=flag;
                }
            }
        }
        printf("THE ARRAY IN DESCENDING ORDER IS:");
      for(i=0;i<len;i++)
         printf("%d ",arr[i]);
     }
     else
        printf("INVALID INPUT:");
}
int merge(int arr[],int brr[],int crr[],int len,int len2){
    int i,index=0;
    for(i=0;i<len;i++){
        crr[index]=arr[i];
        index++;
    }
    for(i=0;i<len2;i++){
        crr[index]=brr[i];
        index++;
        if(brr[i]==minval)
        len2=len2-1;
    }
   return (len+len2);
}
/*EXECUTION TRAIL:
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:2
ISEMPTY=1
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:3
ISFULL=0
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:4
LENGTH=0
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:5

ARRAY ELEMENTS:
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:1
ENTER VALUE OF ELEMENT:1
ENTER VALUE OF ELEMENT:2
ENTER VALUE OF ELEMENT:3
ENTER VALUE OF ELEMENT:-999

____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:2
ISEMPTY=0
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:3
ISFULL=0
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:4
LENGTH=3
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:5

ARRAY ELEMENTS:1 2 3 
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:6
ENTER INDEX(0-3):3
ENTER VALUE OF ELEMENT:4

____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:4
LENGTH=4
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:5

ARRAY ELEMENTS:1 2 3 4 
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:11

COPIED ARRAY:1 2 3 4 
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:7
ENTER INDEX TO DELETE AT(0-3):1

____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:4
LENGTH=3
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:5

ARRAY ELEMENTS:1 3 4 
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:8

ENTER ELEMENT TO SEARCH:1
1 IS FOUND AT POSITION:1
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:9

1.SORT IN ASCENDING ORDER
2.SORT IN DESCENDING ORDER
ENTER OPERATION?2
THE ARRAY IN DESCENDING ORDER IS:4 3 1 
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:12

ARRAY ELEMENTS AFTER TRAVERSING ARE:14 13 11 
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:10

 MERGED ARRAY:4 3 1 1 2 3 4 
____________________________ARRAY ADT_________________________________
0.exit()     1.create()      2.isempty()   3.isfull()     4.length()
5.display()  6.insert()      7.delete()    8.search()     9.sort()
10.merge()   11.copy()       12.traverse  
Enter operation to perform:0
	YOU HAVE OPTED TO EXIT...
*/
