/* FILE NAME: DSPDPRAC3.c*/ 
/* AUTHOR NAME:	RAJAT AGRAWAL*/
/* AIM:	TO STUDY AND IMPLEMENT THE DIVIDE AND CONQUER SORTING METHODS-MERGE,QUICK AND HEAP*/
/* HEADER FILE INCLUSION*/
	#include<stdio.h>
	#include<stdlib.h>
	#include<time.h>
	#include"dspd.h"
/* PREPROCESSOR-DIRECTIVES INCLUSION*/
	#define swap(x,y,t) {t=x;x=y;y=t;} 
/* FUNCTION DECLARATIONS*/
	void quick_sort(int *,int,int);
	int partition (int *,int,int);
	int get(char *text);
	void merge(int [],int,int,int);
	void merge_sort(int [],int,int);
	void max_heapify(int [],int,int);
	void build_maxheap(int [],int);
	void heap_sort(int [],int);
	int  left(int);
	int right(int);
	int parent(int);
/* DRIVER FUNCTION*/
void main(){
int *arr,*cpy;
int n,choice,mode,i,k;
double elapsed_t;
time_t begin_t,end_t;
do{
    do{
        n=get("Enter the size of the array(multiple of 10):");
      }while(n%10!=0);
    arr = (int *)calloc(n,sizeof(int));
    cpy = (int *)calloc(n,sizeof(int));
    do{
	    printf("\n________________List creation modes________________\n");
	    printf("\n1.Ascending             2.Descending\n");
	    printf("\n3.Partial Ascending     4.Random\n");
	    mode=get("Enter mode:");
	    begin_t=clock();
        create(arr,n,mode);
        end_t=clock();
	  }while(mode<=0 || mode>=5);
    elapsed_t=(double)(end_t-begin_t)/CLOCKS_PER_SEC;
    printf("\nTotal time taken for list creation:%lf",elapsed_t);
    do{
        printf("\n_____Sorting methods for checking time complexity____\n");
        printf("\n>exit         >quick      >merge   >heap   >shell");  
        printf("\n>insertion    >selection  >bubble  >bucket\n");
        choice=get("Enter '1' to print time complexities & '0' to exit:"); 
        switch(choice){
         case 0:
                printf("\nyou have opted to exit....\n");
                exit(0);
         case 1:
                 copyarr(arr,cpy,n);
                begin_t=clock();
                quick_sort(cpy,0,n-1);
                end_t=clock();
                elapsed_t=(double)(end_t-begin_t)/CLOCKS_PER_SEC;
                printf("\nTime for quick sort is:%lf seconds",elapsed_t);
         case 2:
         		copyarr(arr,cpy,n);
         		begin_t=clock();
				merge_sort(cpy,0,n-1);
				end_t=clock();
				elapsed_t=(double)(end_t-begin_t)/CLOCKS_PER_SEC;
				printf("\nTime for merge sort is:%lf seconds",elapsed_t);    
         case 3:
         		copyarr(arr,cpy,n);
                begin_t=clock();
                heap_sort(cpy,n);
                end_t=clock();
                elapsed_t=(double)(end_t-begin_t)/CLOCKS_PER_SEC;
                printf("\nTime for heap sort is:%lf seconds",elapsed_t);
         case 4: 
         		copyarr(arr,cpy,n);
                begin_t=clock();
                shell_sort(cpy,n);
                end_t=clock();
                elapsed_t=(double)(end_t-begin_t)/CLOCKS_PER_SEC;
                printf("\nTime for shell sort is:%lf seconds",elapsed_t);
         case 5:
         		copyarr(arr,cpy,n);
                begin_t=clock();
				insertion_sort(cpy,n);
				end_t=clock();
				elapsed_t=(double)(end_t-begin_t)/CLOCKS_PER_SEC;
				printf("\nTime for insertion sort is:%lf seconds",elapsed_t);
	     case 6:
	     		copyarr(arr,cpy,n);
      			begin_t=clock();
                selection_sort(cpy,n);
                end_t=clock();
                elapsed_t=(double)(end_t-begin_t)/CLOCKS_PER_SEC;
                printf("\nTime for  selection sort is:%lf seconds",elapsed_t);
         case 7:
         		copyarr(arr,cpy,n);
                begin_t=clock();
        		bubble_sort(cpy,n);
        		end_t=clock();
        		elapsed_t=(double)(end_t-begin_t)/CLOCKS_PER_SEC;
                printf("\nTime for bubble sort is:%lf seconds",elapsed_t);
         case 8:
         		copyarr(arr,cpy,n);
                begin_t=clock();
                bucket_sort(cpy,n);
                end_t=clock();
                elapsed_t=(double)(end_t-begin_t)/CLOCKS_PER_SEC;
                printf("\nTime for bucket sort is:%lf seconds",elapsed_t);
                break;
        default:
               printf("INVALID CHOICE");
      }
   }while(choice>=0 && choice<=8);
   k=get("Do you want to continue-Press 1 to continue....");
  }while(k == 1);
}
int get(char *text){
    int n;
    printf("\n%s",text);
    scanf("%d",&n);
    return n;
}
void quick_sort(int *arr, int p, int r){
    int loc;
    if(p<r){
        loc = partition(arr,p,r);
        quick_sort(arr,p,loc-1);
        quick_sort(arr,loc+1,r);
    }
}
int partition(int *arr, int p, int r){
	int i, j, x, t;
	i = p - 1;
	x = arr[r];	
	for(j = p; j < r; j++){
		if(arr[j] <= x){
			i++;
		    swap(arr[i],arr[j],t);
		}
	}
	arr[r] = arr[i + 1];
	arr[i + 1] = x;	
	return(i + 1);
}
void merge(int arr[],int p,int q,int r){
	int n1,n2,i,j,k,*left,*right;
	n1=q-p+1;
	n2=r-q;
    left=(int*)calloc(n1+1,sizeof(int));
	right=(int*)calloc(n2+1,sizeof(int));
	for(i=0;i<n1;i++)
		left[i]=arr[p+i];
	for(j=0;j<n2;j++)
		right[j]=arr[q+j+1];
    left[i]=999999999;
    right[j]=999999999;
    i=0;
    j=0;
	for(k=p;k<=r;k++){
     	if(left[i]<=right[j])
	 	arr[k]=left[i++];
	 	else
	 	arr[k]=right[j++];
   }
   return;
}
void merge_sort(int arr[], int p, int r){
    int mid;
    if(p<r){
        mid=(p+r)/2;
        merge_sort(arr,p,mid);
        merge_sort(arr,mid+1,r);
        merge(arr,p,mid,r);
    }
}
int parent(int i){
	return i/2;
}
int left(int i){
	return (2*i);
}
int right(int i){
	return ((2*i)+1);
}
void max_heapify(int arr[],int i,int heap_size){
	int l=left(i);
    int r=right(i);
    int largest,t;
    if(l<=heap_size-1 && arr[l]>arr[i])
    	largest=l;
    else
    	largest=i;
    if(r<=heap_size-1 && arr[r]>arr[largest])
    	largest=r;
    if(largest != i){
    	swap(arr[i],arr[largest],t);
    	max_heapify(arr,largest,heap_size);
    }
}
void build_maxheap(int arr[],int n){
	int i;
	for(i=(n-1)/2;i>=0;i--)
		max_heapify(arr,i,n);
}	   	
void heap_sort(int arr[],int n){
	build_maxheap(arr,n);
	int i,t,m;
	m=n;
	for(i=n-1;i>=1;i--){
		swap(arr[0],arr[i],t);
		m=m-1;
		max_heapify(arr,0,m);
    }	
}
/*OUTPUT:
Enter the size of the array(multiple of 10):100000

________________List creation modes________________
1.Ascending             2.Descending

3.Partial Ascending     4.Random

Enter mode:4

Total time taken for list creation:0.003360
_________________Sorting methods for checking time complexity_______________
>exit         >quick      >merge   >heap   >shell
>insertion    >selection  >bubble  >bucket

Enter '1' to print time complexities & '0' to exit:1

Time for quick sort is:0.023199 seconds
Time for merge sort is:0.040603 seconds
Time for heap sort is:0.053655 seconds
Time for shell sort is:0.043822 seconds
Time for insertion sort is:11.234693 seconds
Time for selection sort is:52.766794 seconds
Time for bubble sort is:48.769575 seconds
Time for bucket sort is:0.080237 seconds

________________List creation modes________________
1.Ascending             2.Descending

3.Partial Ascending     4.Random

Enter mode:3

Total time taken for list creation:0.001920
_________________Sorting methods for checking time complexity_______________
>exit         >quick      >merge   >heap   >shell
>insertion    >selection  >bubble  >bucket

Enter '1' to print time complexities & '0' to exit:1

Time for quick sort is:2.594948 seconds
Time for merge sort is:0.028702 seconds
Time for heap sort is:0.046154 seconds
Time for shell sort is:0.015297 seconds
Time for insertion sort is:1.374405 seconds
Time for selection sort is:31.025433 seconds
Time for bubble sort is:20.415255 seconds
Time for bucket sort is:0.049591 seconds

________________List creation modes________________
1.Ascending             2.Descending

3.Partial Ascending     4.Random

Enter mode:2

Total time taken for list creation:0.001544
_________________Sorting methods for checking time complexity_______________
>exit         >quick      >merge   >heap   >shell
>insertion    >selection  >bubble  >bucket

Enter '1' to print time complexities & '0' to exit:1

Time for quick sort is:26.121598 seconds
Time for merge sort is:0.028183 seconds
Time for heap sort is:0.043184 seconds
Time for shell sort is:0.013396 seconds
Time for insertion sort is:22.474537 seconds
Time for selection sort is:36.413152 seconds
Time for bubble sort is:34.373948 seconds
Time for bucket sort is:0.064330 seconds

________________List creation modes________________
1.Ascending             2.Descending

3.Partial Ascending     4.Random

Enter mode:1

Total time taken for list creation:0.001536
_________________Sorting methods for checking time complexity_______________
>exit         >quick      >merge   >heap   >shell
>insertion    >selection  >bubble  >bucket

Enter '1' to print time complexities & '0' to exit:1

Time for quick sort is:31.717573 seconds
Time for merge sort is:0.028422 seconds
Time for heap sort is:0.045292 seconds
Time for shell sort is:0.009239 seconds
Time for insertion sort is:0.000612 seconds
Time for selection sort is:31.577148 seconds
Time for bubble sort is:19.661682 seconds
Time for bucket sort is:0.047084 seconds
_________________Sorting methods for checking time complexity_______________
>exit         >quick      >merge   >heap   >shell
>insertion    >selection  >bubble  >bucket

Enter '1' to print time complexities & '0' to exit:0
you have opted to exit....
*/
