/*FILE NAME : dspdprac7.c*/
/*AUTHOR: RAJAT AGRAWAL*/
/*DATE :22/09/2017*/
/*AIM:TO STUDY A TREE DATA STRUCTURE AND DEMONSTRATE DIFFERENT TRAVERSALS
		ON IT-IN-ORDER,PRE-ORDER,POST-ORDER*/	 
/*HEADER FILES INCLUSION*/
#include<stdio.h>
#include<stdlib.h>
/*PRE-PROCESSOR DIRECTIVES DECLARATION*/
    #define mx 50
    #define ndt -1
    #define mxval 999
/* TREE NODE DEFINITION */
    struct treenode{
        int data;
        struct treenode *lchild;
        struct treenode *rchild;
    };
    typedef struct treenode tnode;
    typedef tnode *tree;
/*FUNCTION DECLARATION*/
tree buildtree(int *,int len ,int index);
void inorder(tree root);
void postorder(tree root);
void preorder(tree root);
int getlchild(int *,int ,int);
int getrchild(int *,int ,int);
tree createnode();
int leafbt(tree root);
int getinput(char *);
int parentbt(tree root);
int lengthlist(int []);
int heightT(tree);
int parentchild2(tree root);
int validtree(int list[],int len);
int locate(int [],int);
/*DRIVER FUNCTION*/
void main(){
int choice,i=-1,k,list[mx],flag,count,key,len;
tree root;
root=NULL;
do{
	printf("\nEnter a valid list to create a tree:");
	i=-1;
	do{
		 ++i;
		 scanf("%d",&list[i]);
		}while(list[i]!=mxval && i!=mx);
	list[i]=ndt;
	list[i+1]=mxval;
	len=lengthlist(list);
	k=validtree(list,len);  
}while(k!=1);
root=buildtree(list,len,0);
do{
    printf("\n_______BINARY TREE________");
    printf("\n0.EXIT");
    printf("\n1.HEIGHT OF TREE         2.LENGTH OF LIST");
    printf("\n3.DISPLAY PARENT NODES   4.DISPLAY LEAF NODES");
    printf("\n5.INORDER WALK   	 6.PRE-ORDER WALK");
    printf("\n7.POST-ORDER WALK   	 8.LOCATE A NODE");
    choice=getinput("Enter operation to perform:");
    switch(choice){
        case 0:
                printf("\nYou have opted to exit...\n");
                exit(0);
        case 1:
                printf("\nHeight of tree:%d",heightT(root));
                break;
        case 2:
                printf("Length of list:%d",lengthlist(list));
                break;
       case 3:
               printf("\nparent nodes:");
               count=parentbt(root);
               printf("\nNo of parent nodes:%d",count); 
               printf("\nparent nodes with two children:");
               count=parentchild2(root);
               printf("\nNo of parent with 2 children:%d",count); 
               break;
      case 4:
               printf("\nleaf nodes:"); 
               count=leafbt(root);
               printf("\nNo of Leaf nodes:%d",count);                
               break;
       case 5:
               printf("\nIN-ORDER TRAVERSAL:");
               inorder(root);
               break;
       case 6:
              printf("\nPRE-ORDER TRAVERSAL:");
              preorder(root);
              break;   
       case 7:
               printf("\nPOST-ORDER TRAVERSAL:");
               postorder(root);
               break;
       case 8:
       			key=getinput("Enter key to search:");
       			flag=locate(list,key);
       			if(flag!=1)
       				printf("\nNode not found");
       			break;          
       default:
                printf("\ninvalid choice");
      }
   }while(choice>0 && choice<=8);
}
/*FUNCTION DEFINITIONS*/
int getinput(char *str){
	int value;
	printf("\n%s",str);
	scanf("%d",&value);
	return value;
}
tree createnode(){
	tree neww;
	neww=(tree)malloc(sizeof(tnode));
	if(neww==NULL)
		printf("AVAIL STACK UNDERFLOW");
	return neww;
}
int lengthlist(int list[]){
	int i=0;
	while(list[i]!=mxval)
	    i=i+1;
	return(i-1);
}	
int validtree(int list[],int len){
	int i;
	if(list[0]==ndt){
		printf("\ninvalid list");
		return 0;
	}
	else{
			for(i=len-1;i>(len/2)-1;i--){
				if(i%2!=0&&list[i/2]==ndt&&list[i]!=ndt&&list[i+1]==ndt&&i+1==len){
					printf("\ninvalid list");
					return 0;
				}
				if(i%2!=0 && list[i/2]==ndt && list[i+1]!=ndt){
					printf("\ninvalid list");
					return 0;
				}
				if((i%2==0) && list[(i/2)-1]==ndt && list[i-1]!=ndt){
					printf("\ninvalid list");
					return 0;
				}
			}
		}	
	return 1;
}								    
tree buildtree(int list[],int len,int index){
    tree temp=NULL;
    if(list[index]!=ndt){
        temp=createnode();
        temp->lchild=buildtree(list,len,getlchild(list,len,index));
        temp->data=list[index];
        temp->rchild=buildtree(list,len,getrchild(list,len,index));    
    }
    return temp;
}
int locate(int list[],int key){
	int i,flag=0;
		for(i=0;i<lengthlist(list);i++){
			if(list[i]==key && key!=ndt){
				printf("\nNode found at index:%d",i);	
				flag=1;
				return flag;
			}		
		}
	return flag;	
}				
int parentchild2(tree root){
	if(root->lchild==NULL && root->rchild==NULL)
		return 0;
	if(root->lchild!=NULL && root->rchild!=NULL){
		printf("%4d",root->data);	
		return(1+parentchild2(root->lchild)+parentchild2(root->rchild));
	}
	if(root->lchild==NULL && root->rchild!=NULL)
		return parentchild2(root->rchild);
	if(root->lchild!=NULL && root->rchild==NULL)
		return(parentchild2(root->lchild));
}		
int getlchild(int list[],int len,int index){
    if(((2*index)+1)>len)
        return len;
    return (2*index+1);
}
int getrchild(int list[],int len,int index){
    if(((2*index)+2)>len)
        return len;
    return ((2*index)+2);
}
void preorder(tree root){
    if(root!=NULL){
        printf("%4d",root->data);
        preorder(root->lchild);
        preorder(root->rchild);
    }
}            
void postorder(tree root){
    if(root!=NULL){
        postorder(root->lchild);
        postorder(root->rchild);
        printf("%4d",root->data);
    }
}           
void inorder(tree root){
    if(root!=NULL){
        inorder(root->lchild);
        printf("%4d",root->data);
        inorder(root->rchild);
    }
}           
int leafbt(tree root){
    if(root==NULL)
        return 0;
    if(root->lchild==NULL && root->rchild==NULL){
        printf("%4d",root->data);
        return 1;
    }
    return (leafbt(root->lchild)+leafbt(root->rchild));
}
int parentbt(tree root){
    if(root==NULL || (root->lchild==NULL && root->rchild==NULL))
        return 0;
    printf("%4d",root->data);
    return (parentbt(root->lchild)+parentbt(root->rchild)+1);
}
int maxof(int l,int r){
   int max;
   if(l>r)
    max=l;
   else if(l<r)
    max=r;
   else
    max=l;
 return max;
}   
int heightT(tree root){
    int lefth,righth;
    if(root==NULL || (root->lchild==NULL && root->rchild==NULL))
        return 0;    
    lefth=heightT(root->lchild);
    righth=heightT(root->rchild);
    return (maxof(lefth,righth)+1);   
}

/*EXECUTION TRAIL:
Enter a valid list to create a tree:1 2 -1 3 4 5 6 999

invalid list
Enter a valid list to create a tree:1 2 3 -1 4 -1 5 999

_______BINARY TREE________
0.EXIT
1.HEIGHT OF TREE         2.LENGTH OF LIST
3.DISPLAY PARENT NODES   4.DISPLAY LEAF NODES
5.INORDER WALK   	       6.PRE-ORDER WALK
7.POST-ORDER WALK     	 8.LOCATE A NODE
Enter operation to perform:1

Height of tree:2

_______BINARY TREE________
0.EXIT
1.HEIGHT OF TREE         2.LENGTH OF LIST
3.DISPLAY PARENT NODES   4.DISPLAY LEAF NODES
5.INORDER WALK   	       6.PRE-ORDER WALK
7.POST-ORDER WALK   	    8.LOCATE A NODE
Enter operation to perform:2
Length of list:7
_______BINARY TREE________
0.EXIT
1.HEIGHT OF TREE         2.LENGTH OF LIST
3.DISPLAY PARENT NODES   4.DISPLAY LEAF NODES
5.INORDER WALK   	       6.PRE-ORDER WALK
7.POST-ORDER WALK   	    8.LOCATE A NODE
Enter operation to perform:3

parent nodes:   1   2   3
No of parent nodes:3
parent nodes with two children:   1
No of parent with 2 children:1
_______BINARY TREE________
0.EXIT
1.HEIGHT OF TREE         2.LENGTH OF LIST
3.DISPLAY PARENT NODES   4.DISPLAY LEAF NODES
5.INORDER WALK   	       6.PRE-ORDER WALK
7.POST-ORDER WALK   	    8.LOCATE A NODE
Enter operation to perform:4

leaf nodes:   4   5
No of Leaf nodes:2
_______BINARY TREE________
0.EXIT
1.HEIGHT OF TREE         2.LENGTH OF LIST
3.DISPLAY PARENT NODES   4.DISPLAY LEAF NODES
5.INORDER WALK   	       6.PRE-ORDER WALK
7.POST-ORDER WALK   	    8.LOCATE A NODE
Enter operation to perform:5

IN-ORDER TRAVERSAL:   2   4   1   3   5
_______BINARY TREE________
0.EXIT
1.HEIGHT OF TREE         2.LENGTH OF LIST
3.DISPLAY PARENT NODES   4.DISPLAY LEAF NODES
5.INORDER WALK   	       6.PRE-ORDER WALK
7.POST-ORDER WALK    	 8.LOCATE A NODE
Enter operation to perform:6

PRE-ORDER TRAVERSAL:   1   2   4   3   5
_______BINARY TREE________
0.EXIT
1.HEIGHT OF TREE         2.LENGTH OF LIST
3.DISPLAY PARENT NODES   4.DISPLAY LEAF NODES
5.INORDER WALK   	       6.PRE-ORDER WALK
7.POST-ORDER WALK   	    8.LOCATE A NODE
Enter operation to perform:7

POST-ORDER TRAVERSAL:   4   2   5   3   1
_______BINARY TREE________
0.EXIT
1.HEIGHT OF TREE         2.LENGTH OF LIST
3.DISPLAY PARENT NODES   4.DISPLAY LEAF NODES
5.INORDER WALK   	       6.PRE-ORDER WALK
7.POST-ORDER WALK   	 	 8.LOCATE A NODE
Enter operation to perform:8

Enter key to search:4

Node found at index:4
_______BINARY TREE________
0.EXIT
1.HEIGHT OF TREE         2.LENGTH OF LIST
3.DISPLAY PARENT NODES   4.DISPLAY LEAF NODES
5.INORDER WALK   	 		 6.PRE-ORDER WALK
7.POST-ORDER WALK   	 	 8.LOCATE A NODE
Enter operation to perform:8

Enter key to search:9

Node not found
_______BINARY TREE________
0.EXIT
1.HEIGHT OF TREE         2.LENGTH OF LIST
3.DISPLAY PARENT NODES   4.DISPLAY LEAF NODES
5.INORDER WALK		   	 6.PRE-ORDER WALK
7.POST-ORDER WALK 	  	 8.LOCATE A NODE
Enter operation to perform:0

You have opted to exit...
*/
