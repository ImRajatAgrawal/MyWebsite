/**FILE NAME: DSPDPRAC11.C*/
/**AUTHOR NAME: RAJAT AGRAWAL*/
/**DATE: 14/10/17*/
/*AIM:TO DEMONSTRATE DIFFERENT SHORTEST PATH ALGORITHMS-WARSHALL'S ALGORITHM AND
		DIJKSTRA'S ALGORITHM*/
/*HEADER FILE INCLUSION*/
#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<unistd.h>
/*PRE-PROCESSOR DIRECTIVES*/
#define mx 10
#define inf 999
/*FUNCTION DECLARATION*/
int getinput(char *str);
void createadj(int adj[][mx],int u,int v,int cost,int type);
void initialize(int adj[][mx],int v);
void floydwarshall(int adj[mx][mx],int ver,int dist[mx][mx],int next[mx][mx]);
void dijkstra_sssp(int adj[][mx],int ver,int src,int dis[],int prev[],int visited[]);
void Initialize(int dis[],int prev[],int visited[],int ver);
void primmst(int adj[][mx],int mstparent[],int dis[],int visited[],int ver);
void path(int u,int v,int next[][mx]);
/*driver function*/
void main(){
    int adj[mx][mx],dis[mx],prev[mx],visited[mx],mstparent[mx],x;
    int src,dist[mx][mx],next[mx][mx],i,j,choice,ver=0,u,v,cost=0;
    int type;
	do{
		printf("\n_________SHORTEST PATH ALGORITHMS_________");
		printf("\n0.EXIT");
		printf("\n1.CREATE GRAPH");
		printf("\n2.EXECUTE FLOYD WARSHALL'S ALGORITHM");
		printf("\n3.EXECUTE DIJKSTRA'S ALGORITHM");	 	
		printf("\n4.EXECUTE PRIM'S ALGORITHM");
		choice=getinput("Enter your choice:");
		switch(choice){
			case 0:
				printf("\nyou have opted to exit...\n");
				exit(0);
			case 1:		 
					printf("\nEnter type of graph:[0: UNDIRECTED] := ");
				scanf("%d",&type);
				if(type!=0)
					type=1;
				do{
					 printf("\nEnter no of vertices:(<=%d)",mx);
					 scanf("%d",&ver);
				  }while(ver>mx || ver<1);
				printf("\nEnter edges as(u,v) & -1 to terminate:");
			  printf("\n\t\t 'u'    |      'v'     |       COST     |   REMARK\n");
			  printf("\t   -----------------------------------------------------");
			  printf("\n");
				initialize(adj,ver);
 				initialize(dist,ver);
					for(i=0;i<ver;i++){
				       for(j=0;j<ver;j++)
						  next[i][j]=-1;
					 }
				  do{
				  	  printf("\t\t  ");
					  scanf("%d%d%d",&u,&v,&cost);
					  if(u==-1 || v==-1 || cost<0)
						  break;
						else if(adj[u][v]<inf && u<ver && v<ver)
							  printf("\t\t\t\t\t\t\t  EDGE EXISTS\n");
					  else if((u<ver && v<ver) && (u>-1 || v>-1)){
					  		if((u==v && cost>0)||(u!=v && cost==0))
					  			printf("\t\t\t\t\t\t  INVALID COST\n");
					  		else{	
						  	createadj(adj,u,v,cost,type);
						  	printf("\t\t\t\t\t\t\t  EDGE TAKEN\n");
						  	}
					  }		
						else
						  printf("\t\t\t\t\t\t\t  INVALID EDGE\n");
					 }while(u<mx && v<mx);
					 printf("\nADJACENCY MATRIX :\n");
					 printf("\n u|v |");
					 for(i=0;i<ver;i++)
						 printf("    %d",i);
						 printf("\n");
						 for(i=0;i<7*ver;i++)
					 			printf("-");
					 	printf("\n");		
				  for(i=0;i<ver;i++){
				  	printf("  %d  | ",i);
					 for(j=0;j<ver;j++)
						  printf("%4d ",adj[i][j]);
				  printf("\n");
				  }
			break;
		case 2:			  
	  		floydwarshall(adj,ver,dist,next);
	  		do{
	  			printf("\nWarshall's algorithm for different source??[0 to stop]");
	  				scanf("%d",&x);
	  			if(x!=0 && x>0){
	  				do{	
	  				printf("ENTER SOURCE VERTEX TO PRINT PATH[0-%d]:",ver-1);
	  				scanf("%d",&src);
	  				}while(src>=ver || src<0);
	  				printf(" vertex   cost\t  path");
	  				printf("\n---------------------------------");
	  				for(i=0;i<ver;i++){
	  					if(src!=i){
	  					 printf("\n  %d->%d\t   %d \t  %d",src,i,dist[src][i],src);
	  					path(src,i,next);
	  					}	
	  				}
	  		printf("\n");
	  		}
	  		}while(x!=0 && 	x>0);
			break;
		case 3:
			do{
				printf("\nEnter source vertex:[0-%d]",ver-1);
				scanf("%d",&src);
			}while(src>ver-1);
			dijkstra_sssp(adj,ver,src,dis,prev,visited);		
			break;	
		case 4:
			primmst(adj,mstparent,dis,visited,ver);
		break;			
		default:
				printf("\nINVALID CHOICE");
		}
	}while(choice>0);					 
}
/*USER DEFINED FUNCTIONS*/
 int getinput(char *str){
		int value;
		printf("\n%s",str);
		scanf("%d",&value);
		return value;
}
void initialize(int adj[][mx],int v){
    int i,j;
    for(i=0;i<v;i++)
        for(j=0;j<v;j++){
            adj[i][j]=inf;
        }
}
 void createadj(int adj[][mx],int u,int v,int cost,int type){
 if(type==1)
 	adj[u][v]=cost;
 else
 	adj[u][v]=adj[v][u]=cost;	
 }
void floydwarshall(int adj[mx][mx],int ver,int dist[mx][mx],int next[mx][mx]){
    int u,v,i,j,k;
    for(u=0;u<ver;u++)
        for(v=0;v<ver;v++){
            if(u==v && dist[u][v]==inf){
                dist[u][v]=0;
                next[u][v]=v;
             }
            else{
                dist[u][v]=adj[u][v];
                next[u][v]=v;
               }
        }
    for(k=0;k<ver;k++){
        for(i=0;i<ver;i++){
            for(j=0;j<ver;j++){
                if(dist[i][j]>(dist[i][k]+dist[k][j])){
                    dist[i][j]=dist[i][k]+dist[k][j];
                    next[i][j]=next[i][k];
                }
           }
        }
        sleep(3);
       printf("\n\n\tITERATION [%d]...\n",k+1); 
        printf("\nCOST MATRIX :\n");
		 printf("\n u|v |");
		 for(i=0;i<ver;i++)
			 printf("    %d",i);
			 printf("\n");
			 for(i=0;i<7*ver;i++)
		 			printf("-");
		 	printf("\n");		
	  for(i=0;i<ver;i++){
	  	printf("  %d  | ",i);
		 for(j=0;j<ver;j++)
			  printf("%4d ",dist[i][j]);
	  printf("\n");
	  }
	  printf("\nPATH MATRIX :\n");
		 printf("\n u|v |");
		 for(i=0;i<ver;i++)
			 printf("    %d",i);
			 printf("\n");
			 for(i=0;i<7*ver;i++)
		 			printf("-");
		 	printf("\n");		
	  for(i=0;i<ver;i++){
	  	printf("  %d  | ",i);
		 for(j=0;j<ver;j++)
			  printf("%4d ",next[i][j]);
	  printf("\n");
	  }
   }
}

void Initialize(int dis[],int prev[],int visited[],int ver){
	int v;
	for(v=0;v<ver;v++){
		dis[v]=inf;
		prev[v]=-1;
		visited[v]=0;
	}
}	
void dijkstra_sssp(int adj[][mx],int ver,int src,int dis[],int prev[],int visited[]){
	int u,v,c,i,alt,min;
	Initialize(dis,prev,visited,ver);
	dis[src]=0;
	for(c=0;c<ver-1;c++){
		min=inf;
		for(i=0;i<ver;i++){
			if(visited[i]==0 && dis[i]<=min){
				min=dis[i];
				u=i;
			}	
		}
		visited[u]=1;
		for(v=0;v<ver;v++){
			if(adj[u][v]>0 && dis[u]!=inf){
				alt=dis[u]+adj[u][v];
				if(alt<dis[v]){
					dis[v]=alt;
					prev[v]=u;
				}
			}
		}
	sleep(3);	
	printf("\n\n\tITERATION[%d]...\n\n",c+1);
	printf("  ");	
	for(i=0;i<12*ver;i++)
 		printf("-");
	 printf("\n");
	printf("\t\t ");
	for(i=0;i<ver;i++)
		 printf("%4d | ",i);
	printf("\n");
	printf("  ");	 
	for(i=0;i<12*ver;i++)
 		printf("-");	 	 	
	printf("\n    DIST[]      |");
	for(i=0;i<ver;i++)
		printf("%4d | ",dis[i]);
	printf("\n");
	printf("  ");	
	for(i=0;i<12*ver;i++)
 		printf("-");
	 printf("\n");
	printf("    PREV[]      |");
	for(i=0;i<ver;i++)
		printf("%4d | ",prev[i]);
	printf("\n");	
	printf("  ");	
	for(i=0;i<12*ver;i++)
 		printf("-");
	 printf("\n");
	printf("    VISITED[]   |");
	for(i=0;i<ver;i++)
		printf("%4d | ",visited[i]);
	printf("\n");
	printf("  ");	
	for(i=0;i<12*ver;i++)
 		printf("-");	
	}
}				
void primmst(int adj[][mx],int mstparent[],int dis[],int visited[],int ver){
	int min,i,u,c,v;
	Initialize(dis,mstparent,visited,ver);
	dis[0]=0;
	for(c=0;c<ver-1;c++){
		min=inf;
		for(i=0;i<ver;i++){
			if(visited[i]==0 && dis[i]<=min){
				min=dis[i];
				u=i;
			}	
		}
		visited[u]=1;
		for(v=0;v<ver;v++){
			if(adj[u][v] && visited[v]==0 && adj[u][v]<dis[v]){
				mstparent[v]=u;
				dis[v]=adj[u][v];
			}
		}
			sleep(3);	
		printf("\n\n\tITERATION[%d]...\n\n",c+1);
		printf("  ");	
		for(i=0;i<12*ver;i++)
	 		printf("-");
		 printf("\n");
		printf("\t\t ");
		for(i=0;i<ver;i++)
			 printf("%4d | ",i);
		printf("\n");
		printf("  ");	 
		for(i=0;i<12*ver;i++)
	 		printf("-");	 	 	
		printf("\n    DIST[]      |");
		for(i=0;i<ver;i++)
			printf("%4d | ",dis[i]);
		printf("\n");
		printf("  ");	
		for(i=0;i<12*ver;i++)
	 		printf("-");
		 printf("\n");
		printf("    MSTPARENT[] |");
		for(i=0;i<ver;i++)
			printf("%4d | ",mstparent[i]);
		printf("\n");	
		printf("  ");	
		for(i=0;i<12*ver;i++)
	 		printf("-");
		 printf("\n");
		printf("    VISITED[]   |");
		for(i=0;i<ver;i++)
			printf("%4d | ",visited[i]);
		printf("\n");
		printf("  ");	
		for(i=0;i<12*ver;i++)
	 		printf("-");	
	}	
}				
void path(int u,int v,int next[][mx]){	
	int path;
	if(next[u][v]==-1)
		return;
	path=next[u][v];
	while(u!=v){
		u=next[u][v];
		path=u;
		printf("->%d",path);
	}		
}			

/**EXECUTION TRAIL**
_________SHORTEST PATH ALGORITHMS_________
0.EXIT
1.CREATE GRAPH
2.EXECUTE FLOYD WARSHALL'S ALGORITHM
3.EXECUTE DIJKSTRA'S ALGORITHM
4.EXECUTE PRIM'S ALGORITHM
Enter your choice:1

Enter type of graph:[0: UNDIRECTED] := 1

Enter no of vertices:(<=10)6

Enter edges as(u,v) & -1 to terminate:
		 'u'    |      'v'     |       COST     |   REMARK
	   -----------------------------------------------------
		  0				1				50
								  			 		EDGE TAKEN
		  0				3				10
							  						EDGE TAKEN
		  3				0				20
							  						EDGE TAKEN
		  3				4				15
							  						EDGE TAKEN
		  1				2				10
							 						EDGE TAKEN
		  1				3				15
							  						EDGE TAKEN
		  4				1				20
							 					    EDGE TAKEN
		  4				2				30
								  					EDGE TAKEN
		  2				4				35
							  						EDGE TAKEN
		  2				5				5
							  						EDGE TAKEN
		  5				4				3
							  						EDGE TAKEN
		  -1			-1				0

ADJACENCY MATRIX :

 u|v |    0    1    2    3    4    5
------------------------------------------
  0  |  999   50  999   10  999  999 
  1  |  999  999   10   15  999  999 
  2  |  999  999  999  999   35    5 
  3  |   20  999  999  999   15  999 
  4  |  999   20   30  999  999  999 
  5  |  999  999  999  999    3  999 

_________SHORTEST PATH ALGORITHMS_________
0.EXIT
1.CREATE GRAPH
2.EXECUTE FLOYD WARSHALL'S ALGORITHM
3.EXECUTE DIJKSTRA'S ALGORITHM
4.EXECUTE PRIM'S ALGORITHM
Enter your choice:2


	ITERATION [1]...

COST MATRIX :

 u|v |    0    1    2    3    4    5
------------------------------------------
  0  |    0   50  999   10  999  999 
  1  |  999    0   10   15  999  999 
  2  |  999  999    0  999   35    5 
  3  |   20   70  999    0   15  999 
  4  |  999   20   30  999    0  999 
  5  |  999  999  999  999    3    0 

PATH MATRIX :

 u|v |    0    1    2    3    4    5
------------------------------------------
  0  |    0    1    2    3    4    5 
  1  |    0    1    2    3    4    5 
  2  |    0    1    2    3    4    5 
  3  |    0    0    2    3    4    5 
  4  |    0    1    2    3    4    5 
  5  |    0    1    2    3    4    5 


	ITERATION [2]...

COST MATRIX :

 u|v |    0    1    2    3    4    5
------------------------------------------
  0  |    0   50   60   10  999  999 
  1  |  999    0   10   15  999  999 
  2  |  999  999    0  999   35    5 
  3  |   20   70   80    0   15  999 
  4  |  999   20   30   35    0  999 
  5  |  999  999  999  999    3    0 

PATH MATRIX :

 u|v |    0    1    2    3    4    5
------------------------------------------
  0  |    0    1    1    3    4    5 
  1  |    0    1    2    3    4    5 
  2  |    0    1    2    3    4    5 
  3  |    0    0    0    3    4    5 
  4  |    0    1    2    1    4    5 
  5  |    0    1    2    3    4    5 


	ITERATION [3]...

COST MATRIX :

 u|v |    0    1    2    3    4    5
------------------------------------------
  0  |    0   50   60   10   95   65 
  1  |  999    0   10   15   45   15 
  2  |  999  999    0  999   35    5 
  3  |   20   70   80    0   15   85 
  4  |  999   20   30   35    0   35 
  5  |  999  999  999  999    3    0 

PATH MATRIX :

 u|v |    0    1    2    3    4    5
------------------------------------------
  0  |    0    1    1    3    1    1 
  1  |    0    1    2    3    2    2 
  2  |    0    1    2    3    4    5 
  3  |    0    0    0    3    4    0 
  4  |    0    1    2    1    4    2 
  5  |    0    1    2    3    4    5 


	ITERATION [4]...

COST MATRIX :

 u|v |    0    1    2    3    4    5
------------------------------------------
  0  |    0   50   60   10   25   65 
  1  |   35    0   10   15   30   15 
  2  |  999  999    0  999   35    5 
  3  |   20   70   80    0   15   85 
  4  |   55   20   30   35    0   35 
  5  |  999  999  999  999    3    0 

PATH MATRIX :

 u|v |    0    1    2    3    4    5
------------------------------------------
  0  |    0    1    1    3    3    1 
  1  |    3    1    2    3    3    2 
  2  |    0    1    2    3    4    5 
  3  |    0    0    0    3    4    0 
  4  |    1    1    2    1    4    2 
  5  |    0    1    2    3    4    5 


	ITERATION [5]...

COST MATRIX :

 u|v |    0    1    2    3    4    5
------------------------------------------
  0  |    0   45   55   10   25   60 
  1  |   35    0   10   15   30   15 
  2  |   90   55    0   70   35    5 
  3  |   20   35   45    0   15   50 
  4  |   55   20   30   35    0   35 
  5  |   58   23   33   38    3    0 

PATH MATRIX :

 u|v |    0    1    2    3    4    5
------------------------------------------
  0  |    0    3    3    3    3    3 
  1  |    3    1    2    3    3    2 
  2  |    4    4    2    4    4    5 
  3  |    0    4    4    3    4    4 
  4  |    1    1    2    1    4    2 
  5  |    4    4    4    4    4    5 


	ITERATION [6]...

COST MATRIX :

 u|v |    0    1    2    3    4    5
------------------------------------------
  0  |    0   45   55   10   25   60 
  1  |   35    0   10   15   18   15 
  2  |   63   28    0   43    8    5 
  3  |   20   35   45    0   15   50 
  4  |   55   20   30   35    0   35 
  5  |   58   23   33   38    3    0 

PATH MATRIX :

 u|v |    0    1    2    3    4    5
------------------------------------------
  0  |    0    3    3    3    3    3 
  1  |    3    1    2    3    2    2 
  2  |    5    5    2    5    5    5 
  3  |    0    4    4    3    4    4 
  4  |    1    1    2    1    4    2 
  5  |    4    4    4    4    4    5 

Warshall's algorithm for different source??[0 to stop]1
ENTER SOURCE VERTEX TO PRINT PATH[0-5]:0
 vertex   cost	  path
---------------------------------
  0->1	   45 	  0->3->4->1
  0->2	   55 	  0->3->4->2
  0->3	   10 	  0->3
  0->4	   25 	  0->3->4
  0->5	   60 	  0->3->4->2->5

Warshall's algorithm for different source??[0 to stop]1
ENTER SOURCE VERTEX TO PRINT PATH[0-5]:1
 vertex   cost	  path
---------------------------------
  1->0	   35 	  1->3->0
  1->2	   10 	  1->2
  1->3	   15 	  1->3
  1->4	   18 	  1->2->5->4
  1->5	   15 	  1->2->5

Warshall's algorithm for different source??[0 to stop]0

_________SHORTEST PATH ALGORITHMS_________
0.EXIT
1.CREATE GRAPH
2.EXECUTE FLOYD WARSHALL'S ALGORITHM
3.EXECUTE DIJKSTRA'S ALGORITHM
4.EXECUTE PRIM'S ALGORITHM
Enter your choice:3

Enter source vertex:[0-5]0


	ITERATION[1]...

  ------------------------------------------------------------------------
	  	            0 |    1 |    2 |    3 |    4 |    5 | 
  ------------------------------------------------------------------------
    DIST[]      |   0 |   50 |  999 |   10 |  999 |  999 | 
  ------------------------------------------------------------------------
    PREV[]      |  -1 |    0 |   -1 |    0 |   -1 |   -1 | 
  ------------------------------------------------------------------------
    VISITED[]   |   1 |    0 |    0 |    0 |    0 |    0 | 
  ------------------------------------------------------------------------

	ITERATION[2]...

  ------------------------------------------------------------------------
		    		0 |    1 |    2 |    3 |    4 |    5 | 
  ------------------------------------------------------------------------
    DIST[]      |   0 |   50 |  999 |   10 |   25 |  999 | 
  ------------------------------------------------------------------------
    PREV[]      |  -1 |    0 |   -1 |    0 |    3 |   -1 | 
  ------------------------------------------------------------------------
    VISITED[]   |   1 |    0 |    0 |    1 |    0 |    0 | 
  ------------------------------------------------------------------------

	ITERATION[3]...

  ------------------------------------------------------------------------
		    		0 |    1 |    2 |    3 |    4 |    5 | 
  ------------------------------------------------------------------------
    DIST[]      |   0 |   45 |   55 |   10 |   25 |  999 | 
  ------------------------------------------------------------------------
    PREV[]      |  -1 |    4 |    4 |    0 |    3 |   -1 | 
  ------------------------------------------------------------------------
    VISITED[]   |   1 |    0 |    0 |    1 |    1 |    0 | 
  ------------------------------------------------------------------------

	ITERATION[4]...

  ------------------------------------------------------------------------
		    		0 |    1 |    2 |    3 |    4 |    5 | 
  ------------------------------------------------------------------------
    DIST[]      |   0 |   45 |   55 |   10 |   25 |  999 | 
  ------------------------------------------------------------------------
    PREV[]      |  -1 |    4 |    4 |    0 |    3 |   -1 | 
  ------------------------------------------------------------------------
    VISITED[]   |   1 |    1 |    0 |    1 |    1 |    0 | 
  ------------------------------------------------------------------------

	ITERATION[5]...

  ------------------------------------------------------------------------
		    		0 |    1 |    2 |    3 |    4 |    5 | 
  ------------------------------------------------------------------------
    DIST[]      |   0 |   45 |   55 |   10 |   25 |   60 | 
  ------------------------------------------------------------------------
    PREV[]      |  -1 |    4 |    4 |    0 |    3 |    2 | 
  ------------------------------------------------------------------------
    VISITED[]   |   1 |    1 |    1 |    1 |    1 |    0 | 
  ------------------------------------------------------------------------
_________SHORTEST PATH ALGORITHMS_________
0.EXIT
1.CREATE GRAPH
2.EXECUTE FLOYD WARSHALL'S ALGORITHM
3.EXECUTE DIJKSTRA'S ALGORITHM
4.EXECUTE PRIM'S ALGORITHM
Enter your choice:4


	ITERATION[1]...

  ------------------------------------------------------------------------
		  		  	0 |    1 |    2 |    3 |    4 |    5 | 
  ------------------------------------------------------------------------
    DIST[]      |   0 |   50 |  999 |   10 |  999 |  999 | 
  ------------------------------------------------------------------------
    MSTPARENT[] |  -1 |    0 |   -1 |    0 |   -1 |   -1 | 
  ------------------------------------------------------------------------
    VISITED[]   |   1 |    0 |    0 |    0 |    0 |    0 | 
  ------------------------------------------------------------------------

	ITERATION[2]...

  ------------------------------------------------------------------------
		    		0 |    1 |    2 |    3 |    4 |    5 | 
  ------------------------------------------------------------------------
    DIST[]      |   0 |   50 |  999 |   10 |   15 |  999 | 
  ------------------------------------------------------------------------
    MSTPARENT[] |  -1 |    0 |   -1 |    0 |    3 |   -1 | 
  ------------------------------------------------------------------------
    VISITED[]   |   1 |    0 |    0 |    1 |    0 |    0 | 
  ------------------------------------------------------------------------

	ITERATION[3]...

  ------------------------------------------------------------------------
		    		0 |    1 |    2 |    3 |    4 |    5 | 
  ------------------------------------------------------------------------
    DIST[]      |   0 |   20 |   30 |   10 |   15 |  999 | 
  ------------------------------------------------------------------------
    MSTPARENT[] |  -1 |    4 |    4 |    0 |    3 |   -1 | 
  ------------------------------------------------------------------------
    VISITED[]   |   1 |    0 |    0 |    1 |    1 |    0 | 
  ------------------------------------------------------------------------

	ITERATION[4]...

  ------------------------------------------------------------------------
		    		0 |    1 |    2 |    3 |    4 |    5 | 
  ------------------------------------------------------------------------
    DIST[]      |   0 |   20 |   10 |   10 |   15 |  999 | 
  ------------------------------------------------------------------------
    MSTPARENT[] |  -1 |    4 |    1 |    0 |    3 |   -1 | 
  ------------------------------------------------------------------------
    VISITED[]   |   1 |    1 |    0 |    1 |    1 |    0 | 
  ------------------------------------------------------------------------

	ITERATION[5]...

  ------------------------------------------------------------------------
		    		0 |    1 |    2 |    3 |    4 |    5 | 
  ------------------------------------------------------------------------
    DIST[]      |   0 |   20 |   10 |   10 |   15 |    5 | 
  ------------------------------------------------------------------------
    MSTPARENT[] |  -1 |    4 |    1 |    0 |    3 |    2 | 
  ------------------------------------------------------------------------
    VISITED[]   |   1 |    1 |    1 |    1 |    1 |    0 | 
  ------------------------------------------------------------------------
_________SHORTEST PATH ALGORITHMS_________
0.EXIT
1.CREATE GRAPH
2.EXECUTE FLOYD WARSHALL'S ALGORITHM
3.EXECUTE DIJKSTRA'S ALGORITHM
4.EXECUTE PRIM'S ALGORITHM
Enter your choice:0

you have opted to exit...
**/		
	 
  
