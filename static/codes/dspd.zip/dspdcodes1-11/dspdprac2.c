/* FILE NAME:   dspdprac2.C*/
/* AUTHOR NAME:	RAJAT AGRAWAL*/
/* AIM:	TO STUDY AND IMPLEMENT BASIC SORTING METHODS-
        SELECTION,INSERTION,BUBBLE,SHELL AND BUCKET*/
/* PRE-PROCESSOR DIRECTIVES INCLUSION*/
	 #define maxsize 1000000000
	 #define swap(x,y,t) {t=x;x=y;y=t;} 
/* HEADER FILE INCLUSION*/
	 #include<stdio.h>
	 #include<stdlib.h>
	 #include<malloc.h>
	 #include<time.h>
/*USER DEFINED FUNCTIONS DECLARATION*/
	 void bubble_sort(int arr[],int);
	 void selection_sort(int arr[],int);
	 void insertion_sort(int arr[],int);
	 void shell_sort(int arr[],int);
	 void bucket_sort(int arr[],int);
	 void create( int arr[],int length,int mode);
	 void display_list(int arr[],int length);
	 void copyarr(int arr[],int cpy[],int length);
	 int getinput(char *);
/*DRIVER FUNCTION*/
void main(){
  int *arr,*cpy;
  int ans,choice,mode,i,op;
  int length;
   do
   {
	   do{
		  length=getinput("Enter size of array(Multiple of 10):");
         }while(length%10!=0 || length>maxsize);
	   do{
		     printf("\n____________LIST CREATION MODES__________");
			 printf("\n1.increasing order             2.decreasing order");
			 printf("\n3.increasing partial order     4.random order\t");
			 mode=getinput("Enter mode:");
			 arr=(int *)malloc(length*sizeof(int));
			 cpy=(int *)malloc(length*sizeof(int));
			 create(arr,length,mode);
			 copyarr(arr,cpy,length);
		 }while(mode>4 || mode<=0);
	   do{
		    printf("\n__________SORTING METHODS__________________");
		    printf("\n0.exit()	1.bubble()     2.insertion()");
		    printf("\n3.selection()   4.shell()      5.bucket()");
		    choice=getinput("Enter operation to perform:");
		    
		    switch(choice){
		        case 0:
		                printf("\nyou have opted to exit....\n");
		                break;
		        case 1:
		                printf("\n__________ORIGINAL LIST_________\n"); 
		                display_list(cpy,length);
		                bubble_sort(arr,length);
		                printf("\n\n_________SORTED LIST___________\n");
		                display_list(arr,length);
		                break;
		        case 2:
		                    
		                printf("\n__________ORIGINAL LIST_________\n");  
		                display_list(cpy,length);
		                insertion_sort(arr,length);
		                printf("\n\n_________SORTED LIST___________\n");
		                display_list(arr,length);
		                break;
		        case 3:
		                printf("\n__________ORIGINAL LIST_________\n"); 
		                display_list(cpy,length);
		                selection_sort(arr,length);
		                printf("\n\n_________SORTED LIST___________\n");
		                display_list(arr,length);
		                break;
		        case 4:
		                printf("\n__________ORIGINAL LIST_________\n"); 
		                display_list(cpy,length);
		                shell_sort(arr,length);
		                printf("\n\n_________SORTED LIST___________\n");
		                display_list(arr,length);
		                break;
		       case 5:
		                printf("\n__________ORIGINAL LIST_________\n"); 
		                display_list(cpy,length);
		                bucket_sort(arr,length);
		                printf("\n\n_________SORTED LIST___________\n");
		                display_list(arr,length);
		                break;
		      default:
		               printf("INVALID CHOICE");

		    }
		 }while(choice>0 && choice<=5);
	  ans=getinput("Do you want to continue:(press 1 to continue)");
  }while(ans==1);
}
/*FUNCTION DEFINITIONS*/
int getinput(char *text){
	int i;
	printf("\n%s",text);
	scanf("%d",&i);
	return i;
}
void copyarr(int arr[],int cpy[],int length){  
   int i;
   for(i=0;i<length;i++)
      cpy[i]=arr[i];   
}
void create(int arr[],int length,int mode){
	int offset,i;
	switch(mode){
		case 1:
				offset=1000000;
				for(i=0;i<length;i++)
				   arr[i]=offset+(25*i);
				break;
	    case 2:
	    		offset=1000000000;
				for(i=0;i<length;i++)
				  arr[i]=offset-(25*i);
				break;
		case 3:
				offset=1000000;
				for(i=0;i<length;i++){
					if(!(i%7))
				    	arr[i]=offset+(25*i);
				    else
				    	arr[i]=offset+(50*i);
			    }	
				break;
		case 4: offset=100000000;
				srandom(offset);
				for(i=0;i<length;i++)
					arr[i]=random()/10;
			    break;	
	    default:
	    		printf("Enter a valid mode");
	}
}		
void display_list(int arr[],int length){
    int i;
    for(i=0;i<length;i++){
   		 if(!(i%10))
    	 printf("\n");
    	 printf("%12d ",arr[i]);
    }
}
void bubble_sort(int arr[],int length){
    int i,j,t;	
    for(i=1;i<length;i++)
        for(j=0;j<length-i;j++)
            if(arr[j]>arr[j+1])
                swap(arr[j],arr[j+1],t);
}
void insertion_sort(int arr[],int length){
    int i,j,key;
	for(j=1;j<length;j++){
	    key=arr[j];
	    i=j-1;
	    while(i>=0 && arr[i]>key){
	        arr[i+1]=arr[i];
	        i=i-1;
	     }
	    arr[i+1]=key;
	 }	 
}
void selection_sort(int arr[],int length){
    int i,min,max,j,t;
	for(i=0;i<length;i++){
	    min=i;
	    for(j=i+1;j<length;j++){
	        if(arr[j]<arr[min])
	              min=j;
	          swap(arr[i],arr[min],t);
	     }
	}
}
void shell_sort(int arr[],int length){
    int i,gap,j,key;
	for(gap=(length/2)-1;gap>0;gap/=2){
	    for(i=gap;i<=length-1;i++){
	        key=arr[i];
	        for(j=i;j>=gap && arr[j-gap]>key;j-=gap)
	            arr[j]=arr[j-gap];
	        arr[j]=key;
	    }
	}
}      
void bucket_sort(int arr[],int n){
	int flag=0,pos,k,j,m,i;
	int **bucket=(int **) malloc(10 * sizeof(int *));
	for (i=0; i<10; i++){
		bucket[i]=(int *)malloc(maxsize*sizeof(int));
	}
	for(pos=1;flag!=n;pos*=10){
		flag=0;
		for(k=0;k<n;k++){
			bucket[(arr[k]/pos)%10][k]=arr[k];
			if((arr[k]/pos)%10==0)
				flag++;
		}
		if(flag==n)
			return;
		for(j=0,m=0;j<10;j++){
			for(k=0;k<n;k++){
		 		if(bucket[j][k]>0){
		 			arr[m]=bucket[j][k];
		 			bucket[j][k]=0;
		 			m++;
		 		}
		   }
		}          
	}		
} 
/*EXECUTION TRAIL:
Enter size of array(Multiple of 10):50

____________LIST CREATION MODES__________
1.increasing order             2.decreasing order
3.increasing partial order     4.random order	
Enter mode:2

__________SORTING METHODS__________________
0.exit()	1.bubble()     2.insertion()
3.selection()   4.shell()      5.bucket()
Enter operation to perform:2

__________ORIGINAL LIST_________

  1000000000    999999975    999999950    999999925    999999900    999999875   
   999999850    999999825    999999800    999999775    999999750    999999725   
   999999700    999999675    999999650    999999625    999999600    999999575   
   999999550    999999525    999999500    999999475    999999450    999999425  
   999999400    999999375    999999350    999999325    999999300    999999275 
   999999250    999999225    999999200    999999175    999999150    999999125  
   999999100    999999075    999999050    999999025    999999000    999998975  
   999998950    999998925    999998900    999998875    999998850    999998825 
   999998800    999998775 

_________SORTED LIST___________

   999998775    999998800    999998825    999998850    999998875    999998900  
   999998925    999998950    999998975    999999000    999999025    999999050
   999999075    999999100    999999125    999999150    999999175    999999200 
   999999225    999999250    999999275    999999300    999999325    999999350   
   999999375    999999400    999999425    999999450    999999475    999999500 
   999999525    999999550    999999575    999999600    999999625    999999650 
   999999675    999999700    999999725    999999750    999999775    999999800 
   999999825    999999850    999999875    999999900    999999925    999999950   
   999999975   1000000000 
__________SORTING METHODS__________________
0.exit()	1.bubble()     2.insertion()
3.selection()   4.shell()      5.bucket()
Enter operation to perform:4

__________ORIGINAL LIST_________

  1000000000    999999975    999999950    999999925    999999900    999999875   
   999999850    999999825    999999800    999999775    999999750    999999725   
   999999700    999999675    999999650    999999625    999999600    999999575   
   999999550    999999525    999999500    999999475    999999450    999999425  
   999999400    999999375    999999350    999999325    999999300    999999275 
   999999250    999999225    999999200    999999175    999999150    999999125  
   999999100    999999075    999999050    999999025    999999000    999998975  
   999998950    999998925    999998900    999998875    999998850    999998825 
   999998800    999998775 

_________SORTED LIST___________

   999998775    999998800    999998825    999998850    999998875    999998900  
   999998925    999998950    999998975    999999000    999999025    999999050
   999999075    999999100    999999125    999999150    999999175    999999200 
   999999225    999999250    999999275    999999300    999999325    999999350   
   999999375    999999400    999999425    999999450    999999475    999999500 
   999999525    999999550    999999575    999999600    999999625    999999650 
   999999675    999999700    999999725    999999750    999999775    999999800 
   999999825    999999850    999999875    999999900    999999925    999999950   
   999999975   1000000000 
____________LIST CREATION MODES__________
1.increasing order             2.decreasing order
3.increasing partial order     4.random order	
Enter mode:4

__________SORTING METHODS__________________
0.exit()	1.bubble()     2.insertion()
3.selection()   4.shell()      5.bucket()
Enter operation to perform:1

__________ORIGINAL LIST_________

   136755752    150831882    159924058    158141984    186525239    119228228  
   176628324    143575393     29005706     29636944    181914466    108884373
    42171165      2698435      7300970    132066422    211841729     70269083    
    51973802    209997518     70219789    128935376    159156417     76619388  
    91867890     42221033    185551808    185240181     10856294    187198630 
    31316654    147612046    123282148    191240712     91005665     95059022    
    95720575     52885625     23886050    124726282     82522570    205800517   
    18862291    124693736    208498953     26163261     42011793    205592318  
    96432344     93985596 

_________SORTED LIST___________

     2698435      7300970     10856294     18862291     23886050     26163261  
    29005706     29636944     31316654     42011793     42171165     42221033  
    51973802     52885625     70219789     70269083     76619388     82522570 
    91005665     91867890     93985596     95059022     95720575     96432344
   108884373    119228228    123282148    124693736    124726282    128935376 
   132066422    136755752    143575393    147612046    150831882    158141984
   159156417    159924058    176628324    181914466    185240181    185551808    
   186525239    187198630    191240712    205592318    205800517    208498953   
   209997518    211841729 
__________SORTING METHODS__________________
0.exit()	1.bubble()     2.insertion()
3.selection()   4.shell()      5.bucket()
Enter operation to perform:5

__________ORIGINAL LIST_________

   136755752    150831882    159924058    158141984    186525239    119228228  
   176628324    143575393     29005706     29636944    181914466    108884373
    42171165      2698435      7300970    132066422    211841729     70269083    
    51973802    209997518     70219789    128935376    159156417     76619388  
    91867890     42221033    185551808    185240181     10856294    187198630 
    31316654    147612046    123282148    191240712     91005665     95059022    
    95720575     52885625     23886050    124726282     82522570    205800517   
    18862291    124693736    208498953     26163261     42011793    205592318  
    96432344     93985596 

_________SORTED LIST___________

     2698435      7300970     10856294     18862291     23886050     26163261  
    29005706     29636944     31316654     42011793     42171165     42221033  
    51973802     52885625     70219789     70269083     76619388     82522570 
    91005665     91867890     93985596     95059022     95720575     96432344
   108884373    119228228    123282148    124693736    124726282    128935376 
   132066422    136755752    143575393    147612046    150831882    158141984
   159156417    159924058    176628324    181914466    185240181    185551808    
   186525239    187198630    191240712    205592318    205800517    208498953   
   209997518    211841729 
____________LIST CREATION MODES__________
1.increasing order             2.decreasing order
3.increasing partial order     4.random order	
Enter mode:3

__________SORTING METHODS__________________
0.exit()	1.bubble()     2.insertion()
3.selection()   4.shell()      5.bucket()
Enter operation to perform:3

__________ORIGINAL LIST_________

     1000000      1000050      1000100      1000150      1000200      1000250  
     1000300      1000175      1000400      1000450      1000500      1000550 
     1000600      1000650      1000350      1000750      1000800      1000850    
     1000900      1000950      1001000      1000525      1001100      1001150    
     1001200      1001250      1001300      1001350      1000700      1001450 
     1001500      1001550      1001600      1001650      1001700      1000875    
     1001800      1001850      1001900      1001950      1002000      1002050  
     1001050      1002150      1002200      1002250      1002300      1002350   
     1002400      1001225 

_________SORTED LIST___________

     1000000      1000050      1000100      1000150      1000175      1000200    
     1000250      1000300      1000400      1000450      1000500      1000525   
     1000350      1000550      1000600      1000650      1000750      1000800 
     1000850      1000875      1000700      1000900      1000950      1001000 
     1001100      1001150      1001200      1001225      1001050      1001250 
     1001300      1001350      1001450      1001500      1001550      1001600  
     1001650      1001700      1001800      1001850      1001900      1001950 
     1002000      1002050      1002150      1002200      1002250      1002300  
     1002350      1002400 
Enter size of array(Multiple of 10):23

Enter size of array(Multiple of 10):50

____________LIST CREATION MODES__________
1.increasing order             2.decreasing order
3.increasing partial order     4.random order	
Enter mode:5
Enter a valid mode
____________LIST CREATION MODES__________
1.increasing order             2.decreasing order
3.increasing partial order     4.random order	
Enter mode:1

__________SORTING METHODS__________________
0.exit()	1.bubble()     2.insertion()
3.selection()   4.shell()      5.bucket()
Enter operation to perform:6
INVALID CHOICE
Do you want to continue:(press 1 to continue)0
*/
