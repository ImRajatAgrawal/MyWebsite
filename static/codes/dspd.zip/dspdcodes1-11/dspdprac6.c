/* FILE NAME: dspdprac6.c*/ 
/* AUTHOR NAME:	RAJAT AGRAWAL*/
/* AIM:	TO STUDY SINGLY LINKED LISTS AND IMPLEMENT VARIOUS OPERATIONS ON IT-
			INSERT,DELETE,REVERSE,ORDER,LOCATE,MERGE,LINKED STACK,QUEUE */
/* HEADER FILE INCLUSION*/
	#include<stdio.h>
	#include<stdlib.h>
/*PRE-PROCESSOR DIRECTIVES DECLARATION*/
	#define minval -9999
/*USER-DEFINED FUNCTION DECLARATION*/
 struct nodell{
	int data;
	struct nodell *link;
};
typedef struct nodell node;
typedef node *list;
list insertatbeg(list first,list *tail,int key);
list insertatend(list first,list *tail,int key);
list insertorderedll(list first,list *tail,int key);
list insertatpos(list first,list *tail,int pos,int key);
list deleteatbeg(list first,list *tail);
list deleteatpos(list first,list *tail,int pos);
list deleteatend(list first,list *tail);
list sortll(list first,int mode);
list mergell(list first,list *tail,list dupl);
list copyll(list first);
list reversell(list first,list *tail);
list createnode();
int lengthll(list first);
int isemptyll(list first);
int locate_nd(list first,int val);
int getinput(char *);
void displayll(list first);
/*DRIVER FUNCTION*/
void main(){
int choice,inp,a,b,c,key,ans,mode,pos;
list first,tail,dupl,mlist;
do{
	first=tail=dupl=NULL;
	printf("\n______LINKED LIST MENU_________");
	printf("\n0.EXIT    1.LINEAR LIST    2.LINKED STACK   3.LINKED QUEUE");
	inp=getinput("Enter operation to perform:"); 
	switch(inp){
		case 0:
				printf("\nyou have opted to exit\n");
				exit(0);
		case 1:
				do{
					printf("\n_________________SIMPLE LINEAR LIST_________________");
					printf("\n0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE");
					printf("\n5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE");
					choice=getinput("Enter operation to perform:");
					switch(choice){
						case 0:
								printf("\nExiting from linear list menu...");
								break;
						case 1:
								a=isemptyll(first);	
								if(a==1)
									printf("\nLIST IS EMPTY");
								else
									printf("\nLIST IS NOT EMPTY");
								break;			
						case 2:
								printf("\n1.INSERTAT_BEG   2.INSERTAT_END"); 
								printf("\n3.INSERTAT_POS   4.INSERT_SORTED");
								choice=getinput("Enter operation to perform:");
								switch(choice){
									case 1:
											key=getinput("Enter element to insert:");
											first=insertatbeg(first,&tail,key);
											break;
									case 2:
											key=getinput("Enter element to insert:");
											if(first==NULL)
												first=insertatend(first,&tail,key);
											else
												tail=insertatend(first,&tail,key);
												break;
									case 3:
											if(isemptyll(first)){
												printf("\nVALID POSITION INDEXES:(0 to 0)");	
												pos=getinput("Enter position:");
												key=getinput("Enter element to insert:");
												first=insertatpos(first,&tail,pos,key);
											}
											else{
												printf("\nVALID POSITION INDEXES:(0 to");
												printf(" %d)",lengthll(first)-1);	
												pos=getinput("Enter position:");
												key=getinput("Enter element to insert:");
												first=insertatpos(first,&tail,pos,key);
											}	
											break;
									case 4:
											key=getinput("Enter element to insert:");
											first=insertorderedll(first,&tail,key);
											break;
									default:
											printf("\nInvalid choice");
								}
								break;	
						case 3:
								if(!(isemptyll(first))){
									printf("\n1.DELETEAT_BEG  2.DELETEAT_END"); 
									printf("\n3.DELETEAT_POS");
									choice=getinput("Enter operation to perform:");
									switch(choice){
										case 1:
												first=deleteatbeg(first,&tail);
												printf("\nNODE DELETED");
												break;
										case 2:
												if(first->link==NULL)
													first=deleteatend(first,&tail);
												else	
													tail=deleteatend(first,&tail);
												printf("\nNODE DELETED");
												break;
										case 3:
												if(!(isemptyll(first))){
													printf("\nVALID POSITION INDEXES:(0 to");
													printf(" %d)",lengthll(first)-1);		
													pos=getinput("Enter position:");
													if(pos>lengthll(first)-1)
														printf("\nInvalid position");
													else	
														first=deleteatpos(first,&tail,pos);
											}
											else
												printf("\nLIST EMPTY:DELETION FAILED");
											break;
										default:
												printf("\ninvalid choice");
									}
								}
								else
									printf("\nLIST IS EMPTY:DELETION FAILED");
								break;
						case 4:
								key=getinput("Enter data value of node to search:");
								pos=locate_nd(first,key);
								if(pos==minval)
									printf("\nNODE NOT FOUND");
								else 
									printf("\nThe node is found at pos=%d",pos);
								break;
						case 5:
								if(!(isemptyll(first))){
									mode=getinput("Enter mode(0 or 1)");
									first=sortll(first,mode);		
									printf("\nSORTED LIST=");
									printf("[First]");
									displayll(first);
									printf(" <-[Tail]");
								}
								else
									printf("\nLIST EMPTY NOTHING TO SORT");
								break;
						case 6:
								dupl=copyll(first);
								if(!(isemptyll(first))){
									mlist=mergell(first,&tail,dupl);
									printf("\nmerged list: ");
									printf("[First]");
									displayll(mlist);
									printf(" <-[Tail]");
									tail->link=NULL;
								}
								else
									printf("\nLIST EMPTY:MERGE FAILED");
								break;
						case 7:
								if(!(isemptyll(first))){
									printf("\nLIST CONTENTS:");
									printf("[First]");
									displayll(first);
									printf(" <-[Tail]");
								}
								else
								displayll(first);
								break;
						case 8:
								printf("\nLENGTH=%d",lengthll(first));
								break;
						case 9:
								if(!(isemptyll(first))){
									printf("\nREVERSED LIST:");
									first=reversell(first,&tail);
									printf("[First]");
									displayll(first);
									printf(" <-[Tail]");
								}
								else
								displayll(first);
								break;	
						default:
								printf("\ninvalild choice");
					}
				}while((choice>0 && choice<=9)||(choice>9));
				break;								
		case 2:
				do{
					printf("\n___________OPERATIONS ON A STACK__________\n");
					printf("\n0.EXIT     1.ISEMPTY    2.PUSH   3.POP");   
					printf("\n4.DISPLAY  5.LENGTH     6.AT-TOP");
					choice=getinput("Enter opereration to perform:");
					switch(choice){
						case 0:
								printf("\nEXITING FROM STACK MENU...");
								break;
						case 1:
								a=isemptyll(first);
								if(a==1)
									printf("\nSTACK IS EMPTY");
								else
									printf("\nSTACK IS NOT EMPTY");
								break;
						case 2:
						        key=getinput("Enter element to Push:");
								first=insertatbeg(first,&tail,key);
								break;
						case 3:
								if(!(isemptyll(first))){
									first=deleteatbeg(first,&tail);
									printf("\nNODE DELETED");
								}
								else
									printf("\nSTACK IS EMPTY:CANNOT POP");
								break;
						case 4:
								if(!(isemptyll(first))){
									printf("\nSTACK CONTENTS=");
									printf("TOP");
									displayll(first);
								}
								else{
									displayll(first);
								}
								break;
						case 5:
								printf("\nLENGTH=%d",lengthll(first));
								break;
						case 6:
								if(!(isemptyll(first)))
									printf("\nVALUE AT TOP=%d",first->data);
								else
									printf("\nVALUE AT TOP=%d",minval);
								break;
					    default:
					    		printf("\nINVALID INPUT");
					 }
				}while(choice>0 && choice<=6);
				 break;
		case 3:
				do{
					printf("\n___________OPERATIONS ON A QUEUE__________\n");
					printf("\n0.EXIT     1.ISEMPTY   2.INSERT      3.DELETE");
					printf("\n4.DISPLAY  5.LENGTH    6.AT-FRONT    7.AT-REAR");
					choice=getinput("Enter opereration to perform:");
					switch(choice){
						case 0:
								printf("\nEXITING FROM QUEUE MENU...");
								break;
						case 1:
								a=isemptyll(first);
								if(a==1)
									printf("\nQUEUE IS EMPTY");
								else
									printf("\nQUEUE IS NOT EMPTY");
								break;
						case 2:
						      key=getinput("Enter element to insert:");
						      if(isemptyll(first))
									first=insertatend(first,&tail,key);
								else
									tail=insertatend(first,&tail,key);
								break;
						case 3:
								if(!(isemptyll(first))){
									first=deleteatbeg(first,&tail);
									printf("\nNODE DELETED");
								}
								else
									printf("\nQUEUE IS EMPTY:DELETION FAILED");
								break;
						case 4:
								if(!(isemptyll(first))){
									printf("\nQUEUE CONTENTS:");
									printf("[Front]");
									displayll(first);
									printf(" <-[rear]");
								}
								else
								displayll(first);
								break;
						case 5:
								printf("\nLENGTH=%d",lengthll(first));
								break;
					   case 6:
					   		if(!(isemptyll(first)))
					   			printf("\nVALUE AT FRONT=%d",first->data);
					   		else
					   			printf("\nVALUE AT FRONT=%d",minval);
					   		break;
					   case 7:
					  			if(!(isemptyll(first)))
					   			printf("\nVALUE AT REAR=%d",tail->data);
					   		else
					   			printf("\nVALUE AT REAR=%d",minval);
					   		break;
					    default:
					    		printf("\nINVALID INPUT");
					 }
				}while(choice>0 && choice<=7);
				 break;
					
		default:
				printf("\nINVALID INPUT");
		}
	}while(inp>0 && inp<=3);		 
}			
/*FUNCTION DEFINITIONS*/
list createnode(){
	list neww;
	neww=(list)malloc(sizeof(node));
	if(neww==NULL)
		printf("AVAIL STACK UNDERFLOW");
	return neww;
}
list insertatbeg(list first,list *tail ,int key){
	list neww;
	neww=createnode();
	neww->data=key;
	neww->link=NULL;
	if(first==NULL)
		*tail=NULL;
	if(first==NULL){
		*tail=neww;
		return neww;
	}
	neww->link=first;
	return neww;
}
list insertatend(list first,list *tail,int key){
	list neww,temp;
	neww=createnode();
	neww->data=key;
	neww->link=NULL;
	if(first==NULL)
		*tail=NULL;
	if(first==NULL){
		*tail=neww;
		return neww;
	}
	(*tail)->link=neww;
	return neww;	
}
list insertatpos(list first,list *tail,int pos,int key){
	int ndx=-1;
	int len=lengthll(first);
	list neww,temp;
	if(!isemptyll(first)){
		if(pos>=len && first->link==NULL){
			printf("\nIncorrect position insert failed");
			return first;
		}
	}	
	if(pos<0 || pos>len){
		printf("\nIncorrect position insert failed");
		return first;
	}
	neww=createnode();
	if(neww==NULL){
		printf("\nNode not allocated,insert failed");
		return first;
	}
	neww->data=key;
	neww->link=NULL;
	if(pos==0){
		neww->link=first;
		*tail=neww;
		return neww;
	}
	temp=first;
	while(ndx++<pos-2)
		temp=temp->link;
	neww->link=temp->link;
	temp->link=neww;
	return first;
}
list insertorderedll(list first,list *tail,int key){
	list neww,temp;
	neww=createnode();
	if(first==NULL)
		*tail=NULL;
	if(neww==NULL){
		printf("\nNode not allocated,insert failed");
		return first;
	}
	neww->data=key;
	neww->link=NULL;
	if(first==NULL){
		*tail=neww;
		return neww;
	}
	if(first->data>=neww->data){
		neww->link=first;
		return neww;
	}
	temp=first;
	while(temp->link!=NULL && temp->link->data<=neww->data)
		temp=temp->link;
	neww->link=temp->link;
	temp->link=neww;
	return first;
}				
int isemptyll(list first){
	if(first==NULL)
		return 1;
	else
		return 0;
}						
list deleteatbeg(list first,list *tail){
	list temp;
	int key;
	key=first->data;
	temp=first;
	first=first->link;
	free(temp);
	if(first==NULL)
		*tail=NULL;
	return first;
}
list deleteatend(list first,list *tail){
	int key;
	list temp;
	if(first->link==NULL){
		key=first->data;
		*tail=NULL;
		free(first);
		return *tail;
	}
	temp=first;
	while(temp->link->link!=NULL)
		temp=temp->link;
	key=temp->link->data;
	free(temp->link);
	temp->link=NULL;
	return temp;
}		
list deleteatpos(list first,list *tail,int pos){
	list temp,t;
	int ctr=0,len;
	len=lengthll(first);
	temp=first;
	t=first;
	while(ctr<pos){
		t=temp;
		temp=temp->link;
		ctr=ctr+1;
	}
	t->link=temp->link;
	if(pos==0)
		first=t->link;
	if(pos==len-1)
		*tail=t;	
	free(temp);
	return first;
}
		
list mergell(list first,list *tail,list dupl){
	(*tail)->link=dupl;
	return first;
}
list sortll(list first,int mode){
	list iptr,jptr;
	int key;
	if(first==NULL || first->link==NULL)
		return first;
	for(iptr=first;iptr->link!=NULL;iptr=iptr->link){
		for(jptr=iptr->link;jptr!=NULL;jptr=jptr->link){
			switch(mode){
				case 0:	
						if(iptr->data>jptr->data){
							key=iptr->data;
							iptr->data=jptr->data;
							jptr->data=key;
						}
						break;
				case 1:
						if(iptr->data<jptr->data){
							key=iptr->data;
							iptr->data=jptr->data;
							jptr->data=key;
						}
						break;
				default:
						printf("\ninvalid mode");
			}
		}
	}
	return first;
}
list copyll(list first){
	list neww,dupl,cpy,temp;
	if(first==NULL)
		return NULL;
	neww=createnode();
	neww->data=first->data;
	neww->link=NULL;
	dupl=neww;
	temp=first;
	while(temp->link!=NULL){
		cpy=neww;
		temp=temp->link;
		neww=createnode();
		neww->data=temp->data;
		neww->link=NULL;
		cpy->link=neww;
	}
	neww->link=NULL;
	return dupl;				
}	
int lengthll(list first){
	int len=0;
	list neww;
	if(first==NULL)
		return len;
	neww=first;
	while(neww!=NULL){
		len++;
		neww=neww->link;
	}
	return len;
}	
int locate_nd(list first,int val){
	list temp;
	int pos=minval,i=0;
	temp=first;
	while(temp!=NULL){
		if(temp->data==val){
			pos=i;
			break;
		}
		i++;
		temp=temp->link;
	}
	return pos;
}	
list reversell(list first,list *tail){
	list rev,p1,p2;
	rev=first;
	*tail=rev;
	p2=first->link->link;
	p1=first->link;
	rev->link=NULL;
	p1->link=rev;
	while(p2!=NULL){
		rev=p1;
		p1=p2;
		p2=p2->link;
		p1->link=rev;
	}	
return p1;
}				
void displayll(list first){
	list neww;
	neww=first;
	if(first==NULL)
		printf("LIST EMPTY:NOTHING TO DISPLAY");
	else{
		while(neww!=NULL){
			printf("-> %d",neww->data);
			printf("[%p]",(void *)neww);
			neww=neww->link;
		}
	}	
}					
int getinput(char *str){
		int value;
		printf("\n%s",str);
		scanf("%d",&value);
		return value;
}

/*EXECUTION TRAIL
______LINKED LIST MENU_________
0.EXIT    1.LINEAR LIST    2.LINKED STACK   3.LINKED QUEUE
Enter operation to perform:1

_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:1

LIST IS EMPTY
_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:2

1.INSERTAT_BEG  2.INSERTAT_END  3.INSERTAT_POS
4.INSERT_SORTED
Enter operation to perform:1

Enter element to insert:4

_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:2

1.INSERTAT_BEG  2.INSERTAT_END  3.INSERTAT_POS
4.INSERT_SORTED
Enter operation to perform:2

Enter element to insert:4

_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:2

1.INSERTAT_BEG  2.INSERTAT_END  3.INSERTAT_POS
4.INSERT_SORTED
Enter operation to perform:3

VALID POSITION INDEXES:(0 to 1)
Enter position:1

Enter element to insert:7

_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:2

1.INSERTAT_BEG  2.INSERTAT_END  3.INSERTAT_POS
4.INSERT_SORTED
Enter operation to perform:4

Enter element to insert:5

_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:7

LIST CONTENTS:[First]-> 4[0x55f25a813830]-> 5[0x55f25a813890]-> 7[0x55f25a813870]
					-> 4[0x55f25a813850] <-[Tail]
_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:3

1.DELETEAT_BEG  2.DELETEAT_END  3.DELETEAT_POS
Enter operation to perform:1

NODE DELETED
_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:3

1.DELETEAT_BEG  2.DELETEAT_END  3.DELETEAT_POS
Enter operation to perform:2

NODE DELETED
_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:3

1.DELETEAT_BEG  2.DELETEAT_END  3.DELETEAT_POS
Enter operation to perform:3

VALID POSITION INDEXES:(0 to 1)
Enter position:1

_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:4

Enter data value of node to search:7

NODE NOT FOUND
_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:7

LIST CONTENTS:[First]-> 5[0x55f25a813890] <-[Tail]
_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:2

1.INSERTAT_BEG  2.INSERTAT_END  3.INSERTAT_POS
4.INSERT_SORTED
Enter operation to perform:2

Enter element to insert:7

_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:4

Enter data value of node to search:7

The node is found at pos=1
_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:2

1.INSERTAT_BEG  2.INSERTAT_END  3.INSERTAT_POS
4.INSERT_SORTED
Enter operation to perform:1

Enter element to insert:10

_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:5

Enter mode(0 or 1)0

SORTED LIST=[First]-> 5[0x55f25a813850]-> 7[0x55f25a813890]-> 10[0x55f25a813870] <-[Tail]
_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:6

merged list: [First]-> 5[0x55f25a813850]-> 7[0x55f25a813890]-> 10[0x55f25a813870]
				-> 5[0x55f25a813830]-> 7[0x55f25a8138b0]-> 10[0x55f25a8138d0] <-[Tail]
_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:8

LENGTH=3
_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:9

REVERSED LIST:[First]-> 10[0x55f25a813870]-> 7[0x55f25a813890]-> 5[0x55f25a813850] <-[Tail]
_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:1

LIST IS NOT EMPTY
_________________SIMPLE LINEAR LIST_________________
0.EXIT    1.ISEMPTY    2.INSERT    3.DELETE   4.LOCATE
5.SORT    6.MERGE      7.DISPLAY   8.LENGTH   9.REVERSE
Enter operation to perform:0

Exiting from linear list menu...
______LINKED LIST MENU_________
0.EXIT    1.LINEAR LIST    2.LINKED STACK   3.LINKED QUEUE
Enter operation to perform:2      

___________OPERATIONS ON A STACK__________

0.EXIT     1.ISEMPTY    2.PUSH   3.POP
4.DISPLAY  5.LENGTH     6.AT-TOP
Enter opereration to perform:2

Enter element to Push:4

___________OPERATIONS ON A STACK__________

0.EXIT     1.ISEMPTY    2.PUSH   3.POP
4.DISPLAY  5.LENGTH     6.AT-TOP
Enter opereration to perform:2

Enter element to Push:5

___________OPERATIONS ON A STACK__________

0.EXIT     1.ISEMPTY    2.PUSH   3.POP
4.DISPLAY  5.LENGTH     6.AT-TOP
Enter opereration to perform:5

LENGTH=2
___________OPERATIONS ON A STACK__________

0.EXIT     1.ISEMPTY    2.PUSH   3.POP
4.DISPLAY  5.LENGTH     6.AT-TOP
Enter opereration to perform:4

STACK CONTENTS=TOP-> 5[0x55f25a813910]-> 4[0x55f25a8138f0]
___________OPERATIONS ON A STACK__________

0.EXIT     1.ISEMPTY    2.PUSH   3.POP
4.DISPLAY  5.LENGTH     6.AT-TOP
Enter opereration to perform:3

NODE DELETED
___________OPERATIONS ON A STACK__________

0.EXIT     1.ISEMPTY    2.PUSH   3.POP
4.DISPLAY  5.LENGTH     6.AT-TOP
Enter opereration to perform:6

VALUE AT TOP=4
___________OPERATIONS ON A STACK__________

0.EXIT     1.ISEMPTY    2.PUSH   3.POP
4.DISPLAY  5.LENGTH     6.AT-TOP
Enter opereration to perform:5

LENGTH=1
___________OPERATIONS ON A STACK__________

0.EXIT     1.ISEMPTY    2.PUSH   3.POP
4.DISPLAY  5.LENGTH     6.AT-TOP
Enter opereration to perform:0

EXITING FROM STACK MENU...
______LINKED LIST MENU_________
0.EXIT    1.LINEAR LIST    2.LINKED STACK   3.LINKED QUEUE
Enter operation to perform:3

___________OPERATIONS ON A QUEUE__________

0.EXIT     1.ISEMPTY   2.INSERT      3.DELETE
4.DISPLAY  5.LENGTH    6.AT-FRONT    7.AT-REAR
Enter opereration to perform:2

Enter element to insert:4

___________OPERATIONS ON A QUEUE__________

0.EXIT     1.ISEMPTY   2.INSERT      3.DELETE
4.DISPLAY  5.LENGTH    6.AT-FRONT    7.AT-REAR
Enter opereration to perform:2

Enter element to insert:5

___________OPERATIONS ON A QUEUE__________

0.EXIT     1.ISEMPTY   2.INSERT      3.DELETE
4.DISPLAY  5.LENGTH    6.AT-FRONT    7.AT-REAR
Enter opereration to perform:3

NODE DELETED
___________OPERATIONS ON A QUEUE__________

0.EXIT     1.ISEMPTY   2.INSERT      3.DELETE
4.DISPLAY  5.LENGTH    6.AT-FRONT    7.AT-REAR
Enter opereration to perform:6

VALUE AT FRONT=5
___________OPERATIONS ON A QUEUE__________

0.EXIT     1.ISEMPTY   2.INSERT      3.DELETE
4.DISPLAY  5.LENGTH    6.AT-FRONT    7.AT-REAR
Enter opereration to perform:7

VALUE AT REAR=5
___________OPERATIONS ON A QUEUE__________

0.EXIT     1.ISEMPTY   2.INSERT      3.DELETE
4.DISPLAY  5.LENGTH    6.AT-FRONT    7.AT-REAR
Enter opereration to perform:5

LENGTH=1
___________OPERATIONS ON A QUEUE__________

0.EXIT     1.ISEMPTY   2.INSERT      3.DELETE
4.DISPLAY  5.LENGTH    6.AT-FRONT    7.AT-REAR
Enter opereration to perform:4

QUEUE CONTENTS:[Front]-> 5[0x55f25a813930] <-[rear]
___________OPERATIONS ON A QUEUE__________

0.EXIT     1.ISEMPTY   2.INSERT      3.DELETE
4.DISPLAY  5.LENGTH    6.AT-FRONT    7.AT-REAR
Enter opereration to perform:0

EXITING FROM QUEUE MENU...
______LINKED LIST MENU_________
0.EXIT    1.LINEAR LIST    2.LINKED STACK   3.LINKED QUEUE
Enter operation to perform:0

you have opted to exit
*/

