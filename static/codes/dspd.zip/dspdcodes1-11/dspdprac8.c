/**FILE NAME: DSPDPRAC8.C*/
/**AUTHOR NAME: RAJAT AGRAWAL*/
/**DATE: 29/09/17*/
/*AIM: TO STUDY AND IMPLEMENT BINARY SEARCH TREE-USING ARRAY AND LINKED LIST*/

/*HEADER FILE INCLUSION*/
#include<stdio.h>
#include<stdlib.h>
#include"treeadt.h"
/*TREE NODE DEFINITION*/
struct treearr{
    int data;
    int lpos;
    int rpos;
   };
 typedef  struct treearr tarr;
/*PRE-PROCESSOR DIRECTIVES*/
#define mxval 999
#define ndt -1
#define maxsize 50
/*USER DEFINED FUNNCTION DECLARATION*/
int tempSearch(tarr t[],int ndx);
void inorder(tree root);
void populatearr(tarr t[]);
void postorder(tree root);
void preorder(tree root);
tree createnode();
int leafbt(tree root);
int getinput(char *);
int parentbt(tree root);
int lengthlist(int []);
int heightT(tree);
tree createbst();
tree insertbst(tree root,int key);
tree deletebst(tree root,int key);
void traversebst(tree root);
tree findminnode(tree root);
void createtnode(tarr *,int);
void createbstarr(tarr []);
void insertbstarr(tarr [],int *,int);
void inorderarr(tarr t[],int ndx);
void printlevel(tree root,int i);
void levelorder(tree root);
void traversebstarr(tarr t[],int ndx);
void preorderarr(tarr t[],int ndx);
void postorderarr(tarr t[],int ndx);
int deletebstarr(tarr t[],int ndx,int key);
tarr findmintnode(tarr t[],int indx);
/*DRIVER FUNCTION*/
void main(){
    tree root;
    tarr t[maxsize];
    int key,count,choice,ndx=0,val;
    root=NULL;
    populatearr(t);
   do{
        printf("\n_________BINARY SEARCH TREE______");
        printf("\n0.Exit");
        printf("\n1.ARRAY IMPLEMENTATION");
        printf("\n2.LINKED LIST IMPLEMENTATION");
        choice=getinput("Enter operation to perform:");
        switch(choice){
           case 0:
                printf("\nyou have opted to exit\n");
                exit(0);
           case 1:
                do{ 
                	printf("\n_____BINARY SEARCH TREE_____");                      
                    printf("\n0.EXIT");
                    printf("\n1.create a bst");
                    printf("\n2.delete a node");
                    printf("\n3.print traversals");
                    choice=getinput("Enter operation to perform:");
                    switch(choice){
                        case 0:
                               printf("\nyou have opted to exit\n");
                                break;
                        case 1:
                                createbstarr(t);
                                break;
                        case 2:
                               	key=getinput("Enter key to delete:");
                                ndx=0;
                                val=deletebstarr(t,ndx,key);
                                break;
                        case 3:
                              	ndx=0;
                              	traversebstarr(t,ndx);
                                break;
                        default:
                                printf("\nInvalid choice");
                    }
                   }while(choice>0 && choice<=3); 
                    break;
           case 2:    
                do{
                    printf("\n_________BINARY SEARCH TREE______");
                    printf("\n0.EXIT");
                    printf("\n1.create  a bst");
                    printf("\n2.delete a node");
                    printf("\n3.find parent nodes");
                    printf("\n4.find leaf nodes");
                    printf("\n5.height of the bst");
                    printf("\n6.print traversals");
                    choice=getinput("Enter operation to perform:");
                    switch(choice){
                        case 0:
                               printf("\nyou have opted to exit\n");
                               break;
                        case 1:
                               root=createbst();
                               break;
                        case 2:
                              key=getinput("Enter key to delete:");
                              root=deletebst(root,key);
                              break;
                       case 3:
                              printf("\nparent nodes:");
                              count=parentbt(root);
                              printf("\nNo of parent nodes:%d",count);   
                              break;
                       case 4:
                           	  printf("\nleaf nodes:"); 
                           	  count=leafbt(root);
                              printf("\nNo of Leaf nodes:%d",count);            
                           	  break;
                       case 5:
                              printf("\nHeight of tree:%d",heightT(root));
                              break;
                        case 6:
                              traversebst(root);
                              break;
                        default:
                                printf("\nINVALID CHOICE");
                    }           
                 }while(choice>0 && choice<=6);
                 break;
                 default:
         		printf("\nINVALID CHOICE\n");
   			}
   }while(choice>=0);
}
      
/*FUNCTION DEFINITIONS*/
tree createbst(){
	int key;
	tree root=NULL;
	do{
		printf("\nEnter key to insert[%d to end]:",mxval);
			scanf("%d",&key);
			if(key!=mxval)
				root=insertbst(root,key);
	}while(key!=mxval);
	return root;
}
tree insertbst(tree root,int key){
	if(root==NULL){
		root=createnode();
		if(root==NULL)
			printf("\ninsert failed,avail underflow");
			else{
				root->data=key;
				root->lchild=root->rchild=NULL;
				}
   }
   else{
   	if(key<root->data)
   		root->lchild=insertbst(root->lchild,key);
   	else if(key>root->data)
   		root->rchild=insertbst(root->rchild,key);
   	else
   		printf("\nDuplicate key");
   	}
   	return root;
}
		
int deletebstarr(tarr t[],int ndx,int key){
tarr temp;
int i=0,j=0,save,flag=0;
if(t[0].data==ndt){
	printf("\nEmpty tree deletion failed");
	return ndx;
}
while(j!=maxsize){
	if(key==t[j].data)
		flag=1;
	j++;
}
if(flag==0){
	printf("\nKey not found");
	return key;
}		
		
if(key<t[ndx].data)
	t[ndx].lpos=deletebstarr(t,t[ndx].lpos,key);
else if(key>t[ndx].data)
	t[ndx].rpos=deletebstarr(t,t[ndx].rpos,key);
else{
	 if(key==t[ndx].data){
	 	if(t[ndx].lpos!=ndt && t[ndx].rpos!=ndt && t[t[ndx].rpos].data!=mxval){
			save=ndx;
			flag=1;
			temp=findmintnode(t,t[ndx].rpos);
			t[ndx].data=temp.data;
			t[ndx].rpos=deletebstarr(t,t[ndx].rpos,t[ndx].data);
			return save;
		}
		else if(t[ndx].lpos==ndt && (t[ndx].rpos==ndt || t[t[ndx].rpos].data==mxval)){
			i=0;
			i=tempSearch(t,ndx);
			if(key<t[i].data){
				t[i].lpos=-1;
			}	
			else
				t[i].rpos=-1;
			t[ndx].data=-1;
			return ndx;
		}
		 else if(t[ndx].rpos==ndt || t[t[ndx].rpos].data==mxval){
		 	if(ndx==0){
		 		t[ndx].rpos=t[t[ndx].lpos].rpos;
		 		t[ndx]=t[t[ndx].lpos];
		 	}
		 	else{
		 		i=0;
				i=tempSearch(t,ndx);
				if(key<t[i].data){
					printf("\nyes");
	    		 t[i].lpos=t[ndx].lpos;
	    		 t[ndx]=t[t[ndx].lpos];
	    		} 
	 			else{
	     		t[i].rpos=t[ndx].lpos;
	 			t[ndx].data=-1;
	 			t[ndx]=t[t[ndx].lpos];
	 			}
	 		}	
 			return ndx;
		}
		else if(t[ndx].lpos==ndt && t[t[ndx].rpos].data!=mxval){
			if(ndx==0){
		 		t[ndx].lpos=t[t[ndx].rpos].lpos;
		 		t[ndx]=t[t[ndx].rpos];
		 	}
		 	else{
				i=0;
				i=tempSearch(t,ndx);
				if(key<t[i].data){
	    		 t[i].lpos=t[ndx].rpos;
	    		 t[ndx]=t[t[ndx].rpos];
	    		 t[t[ndx].rpos].data=-1;
	    		}
	 			else{
	     			t[i].rpos=t[ndx].rpos;	
	     	   	t[ndx]=t[t[ndx].rpos];
	     	   	}
	     	}   	
     	   	return ndx;		
		}	
	 }			
}
return ndx;	
}	
int tempSearch(tarr t[],int ndx){
    int i=0;
    while(1){
            if(i==maxsize)
            break;
            if(t[i].rpos==ndx || t[i].lpos==ndx)
            break;
            i++;
    }
return i;
}
tarr findmintnode(tarr t[],int indx){
	if(t[indx].data==ndt)
		return t[indx];
	if(t[indx].lpos==ndt)
		return t[indx];
	return(findmintnode(t,t[indx].lpos));	
}		
tree deletebst(tree root,int key){
	tree temp;
	if(root==NULL){
		printf("\nDelete failed,Empty tree");
		return NULL;
	}
	if(key<root->data)	
  		root->lchild=deletebst(root->lchild,key);
  	else if(key>root->data)
  		root->rchild=deletebst(root->rchild,key);
   else{
   	temp=root;
   	if(root->lchild && root->rchild){
   		temp=findminnode(root->rchild);
   		root->data=temp->data;
   		root->rchild=deletebst(root->rchild,root->data);
   	}
   	else{
   		temp=root;
   		if(root->lchild==NULL)
   			root=root->rchild;
   		else if(root->rchild==NULL)
   			root=root->lchild;
   		free(temp);
   	}
   }
   return root;
}   				
tree findminnode(tree root){
	if(root==NULL)
		return NULL;
	if(root->lchild==NULL)
		return root;
	return (findminnode(root->lchild));
}	
void levelorder(tree root){
    int i;
    for(i=1;i<=heightT(root)+1;i++)
        printlevel(root,i);
}
void printlevel(tree root,int i){
   if(root==NULL)
    return;
   if(i==1){
    printf("%d  ",root->data);
    return;
   }
    printlevel(root->lchild,i-1);
    printlevel(root->rchild,i-1);        
}			
void traversebst(tree root){
	printf("\n");
	printf("\t\ninorder:");
		inorder(root);
	printf("\n");
	printf("\t\npre-order:");
		preorder(root);	
	printf("\n");
	printf("\t\npost-order:");
		postorder(root);
	printf("\n");
	printf("\t\nLevel-order:");
	    levelorder(root);	
	printf("\n\n");
}
void createbstarr(tarr t[]){
	int key;
	int tail=0,i;
	do{
		printf("\nEnter key to insert[%d to end]:",mxval);
			scanf("%d",&key);
				insertbstarr(t,&tail,key);
	}while(key!=mxval);	
}
void insertbstarr(tarr t[],int *tail,int key){
   int ndx=0;
   if(*tail==0){
        createtnode(&(t[*tail]),key);
        *tail+=1;
        return;
    }  		
	while(ndx<*tail){
     /*traverse left tree*/
     if(key<t[ndx].data){
         if(t[ndx].lpos==-1){
	    t[ndx].lpos=*tail;
	    createtnode(&(t[*tail]),key);
	    *tail=*tail+1;
	    return;
      }  
       else{
          ndx=t[ndx].lpos;
          continue;
         }
  	  }
   /*traverse  right tree*/
     else if(key>t[ndx].data){
         if(t[ndx].rpos==-1){
	    t[ndx].rpos=*tail;
	    createtnode(&t[*tail],key);
	    *tail=*tail+1;
	    return;
       }  
       else{
           ndx=t[ndx].rpos;
           continue;
       }
     }
     else{
     	printf("\nDuplicate key:cannot insert");
     	return;
     	}       
  }
}		
 void createtnode(tarr *t,int key){
    (*t).data=key;
    (*t).lpos=ndt;
    (*t).rpos=ndt;
    return;
}    
void populatearr(tarr t[]){
    int i;
    for(i=0;i<maxsize;i++){
        t[i].data=ndt;
        t[i].lpos=ndt;
        t[i].rpos=ndt;
    }        
}
void traversebstarr(tarr t[],int ndx){
	printf("\n");
	printf("\t\ninorder:\t");
		inorderarr(t,ndx);
	printf("\n");
	printf("\t\npre-order:\t");
		preorderarr(t,ndx);	
	printf("\n");
	printf("\t\npost-order:\t");
		postorderarr(t,ndx);
	printf("\n");
}
void inorderarr(tarr t[],int ndx){
  if(t[ndx].data!=ndt && t[ndx].data!=mxval){
  		if(t[ndx].lpos!=ndt)
  			inorderarr(t,t[ndx].lpos);
 	 	printf("%d  ",t[ndx].data);
  		if(t[ndx].rpos!=ndt)
  			inorderarr(t,t[ndx].rpos);
	} 
}  
void preorderarr(tarr t[],int ndx){
  if(t[ndx].data!=ndt && t[ndx].data!=mxval){
  		printf("%d  ",t[ndx].data);
  		if(t[ndx].lpos!=ndt)
  			preorderarr(t,t[ndx].lpos);
  		if(t[ndx].rpos!=ndt)
  			preorderarr(t,t[ndx].rpos);
	} 
}  
void postorderarr(tarr t[],int ndx){
  if(t[ndx].data!=ndt && t[ndx].data!=mxval){
  		if(t[ndx].lpos!=ndt)
  			postorderarr(t,t[ndx].lpos);
  		if(t[ndx].rpos!=ndt)
  			postorderarr(t,t[ndx].rpos);
  		printf("%d  ",t[ndx].data);	
	}
}   
/*EXECUTION TRAIL
_________BINARY SEARCH TREE______
0.Exit
1.ARRAY IMPLEMENTATION
2.LINKED LIST IMPLEMENTATION
Enter operation to perform:1

_________BINARY SEARCH TREE______
0.EXIT
1.create a bst
2.delete a node
3.print traversals
Enter operation to perform:1

Enter key to insert[999 to end]:7

Enter key to insert[999 to end]:5

Enter key to insert[999 to end]:8

Enter key to insert[999 to end]:4

Enter key to insert[999 to end]:6

Enter key to insert[999 to end]:10

Enter key to insert[999 to end]:9

Enter key to insert[999 to end]:999

_________BINARY SEARCH TREE______
0.EXIT
1.create a bst
2.delete a node
3.print traversals
Enter operation to perform:2

Enter key to delete:7

_________BINARY SEARCH TREE______
0.EXIT
1.create a bst
2.delete a node
3.print traversals
Enter operation to perform:3

	
inorder:	4  5  6  8  9  10  
	
pre-order:	8  5  4  6  10  9  
	
post-order:	4  6  5  9  10  8  

_________BINARY SEARCH TREE______
0.EXIT
1.create a bst
2.delete a node
3.print traversals
Enter operation to perform:0

you have opted to exit

_________BINARY SEARCH TREE______
0.Exit
1.ARRAY IMPLEMENTATION
2.LINKED LIST IMPLEMENTATION
Enter operation to perform:2

_________BINARY SEARCH TREE______
0.EXIT
1.create  a bst
2.delete a node
3.find parent nodes
4.find leaf nodes
5.height of the bst
6.print traversals
Enter operation to perform:1

Enter key to insert[999 to end]:7

Enter key to insert[999 to end]:5

Enter key to insert[999 to end]:8

Enter key to insert[999 to end]:4

Enter key to insert[999 to end]:6

Enter key to insert[999 to end]:10

Enter key to insert[999 to end]:9

Enter key to insert[999 to end]:999

_________BINARY SEARCH TREE______
0.EXIT
1.create  a bst
2.delete a node
3.find parent nodes
4.find leaf nodes
5.height of the bst
6.print traversals
Enter operation to perform:2

Enter key to delete:7

_________BINARY SEARCH TREE______
0.EXIT
1.create  a bst
2.delete a node
3.find parent nodes
4.find leaf nodes
5.height of the bst
6.print traversals
Enter operation to perform:6

	
inorder:4  5  6  8  9  10  
	
pre-order:8  5  4  6  10  9  
	
post-order:4  6  5  9  10  8  
	
Level-order:8  5  10  4  6  9  


_________BINARY SEARCH TREE______
0.EXIT
1.create  a bst
2.delete a node
3.find parent nodes
4.find leaf nodes
5.height of the bst
6.print traversals
Enter operation to perform:3

parent nodes:   8   5  10
No of parent nodes:3
_________BINARY SEARCH TREE______
0.EXIT
1.create  a bst
2.delete a node
3.find parent nodes
4.find leaf nodes
5.height of the bst
6.print traversals
Enter operation to perform:4

leaf nodes:   4   6   9
No of Leaf nodes:3
_________BINARY SEARCH TREE______
0.EXIT
1.create  a bst
2.delete a node
3.find parent nodes
4.find leaf nodes
5.height of the bst
6.print traversals
Enter operation to perform:5

Height of tree:2
_________BINARY SEARCH TREE______
0.EXIT
1.create  a bst
2.delete a node
3.find parent nodes
4.find leaf nodes
5.height of the bst
6.print traversals
Enter operation to perform:0

you have opted to exit

_________BINARY SEARCH TREE______
0.Exit
1.ARRAY IMPLEMENTATION
2.LINKED LIST IMPLEMENTATION
Enter operation to perform:0

you have opted to exit
*/
