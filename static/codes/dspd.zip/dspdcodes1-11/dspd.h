/* FILE NAME:   RAJATSORT.C*/
/* AUTHOR NAME:	RAJAT AGRAWAL*/
/* AIM:	TO STUDY AND IMPLEMENT BASIC SORTING METHODS-SELECTION,INSERTION,BUBBLE,SHELL AND BUCKET*/
/* PRE-PROCESSOR DIRECTIVES INCLUSION*/
     #define maxsize 10000000
	 #define swap(x,y,t) {t=x;x=y;y=t;} 
/*FUNCTION DEFINITIONS*/
void copyarr(int arr[],int cpy[],int length){  
   int i;
    for(i=0;i<length;i++)
       cpy[i]=arr[i];   
}
void create(int arr[],int length,int mode){
	int offset,i;
	switch(mode)
	{
		case 1:
				offset=1000000;
				for(i=0;i<length;i++)
				   arr[i]=offset+(25*i);
				break;
	    case 2:
	    		offset=1000000000;
				for(i=0;i<length;i++)
				  arr[i]=offset-(25*i);
				break;
		case 3:
				offset=1000000;
				for(i=0;i<length;i++){	
					if(!(i%7))
				    	arr[i]=offset+(25*i);
				    else
				    	arr[i]=offset+(50*i);
			    }	
				break;
		case 4: offset=100000000;
				srandom(offset);
				for(i=0;i<length;i++)
					arr[i]=random()/10;
			    break;	
	    default:
	    		printf("Enter a valid mode");
	}
}		
void display_list(int arr[],int length){
    int i;
    for(i=0;i<length;i++){
   		 if(!(i%10))
    	 printf("\n");
    	 printf("%12d ",arr[i]);
    }
}
void bubble_sort(int arr[],int length){
    int i,j,t;	
        for(i=1;i<length;i++)
            for(j=0;j<length-i;j++)
                if(arr[j]>arr[j+1])
                    swap(arr[j],arr[j+1],t);
}
void insertion_sort(int arr[],int length){
    int i,j,key;
		for(j=1;j<length;j++){
		    key=arr[j];
		    i=j-1;
		    while(i>=0 && arr[i]>key){
		        arr[i+1]=arr[i];
		        i=i-1;
		     }
		  arr[i+1]=key;
	   }			 
}
void selection_sort(int arr[],int length){
    int i,min,max,j,t;
		for(i=0;i<length;i++)
		{    min=i;
		    for(j=i+1;j<length;j++)
		     {    if(arr[j]<arr[min])
		              min=j;
		       swap(arr[i],arr[min],t);
		     }
		}
}
void shell_sort(int arr[],int length){
    int i,gap,j,key;
		for(gap=(length/2)-1;gap>0;gap/=2){
		    for(i=gap;i<=length-1;i++){
		        key=arr[i];
		        for(j=i;j>=gap && arr[j-gap]>key;j-=gap)
		            arr[j]=arr[j-gap];
		        arr[j]=key;
		    }
       }
}      
void bucket_sort(int arr[],int n){
	int flag=0,pos,k,j,m,i;
	int **bucket=(int **) malloc(10 * sizeof(int *));
	for (i=0; i<10; i++)
		bucket[i]=(int *)malloc(maxsize*sizeof(int));
	for(pos=1;flag!=n;pos*=10){
		flag=0;
		for(k=0;k<n;k++){
			bucket[(arr[k]/pos)%10][k]=arr[k];
			if((arr[k]/pos)%10==0)
				flag++;
		}
		if(flag==n)
			return;
		for(j=0,m=0;j<10;j++){
			for(k=0;k<n;k++){
		 		if(bucket[j][k]>0){
		 			arr[m]=bucket[j][k];
		 			bucket[j][k]=0;
		 			m++;
		 		}
		   }
		}          
    }	
} 
		       
        
             
     


