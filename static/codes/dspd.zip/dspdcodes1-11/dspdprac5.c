/* FILE NAME: dspdprac5.c*/ 
/* AUTHOR NAME:	RAJAT AGRAWAL*/
/* AIM:	TO DEMONSTRATE USE OF STACK ADT FOR EVALUATION OF ARITHMETIC EXPRESSIONS*/
/* HEADER FILE INCLUSION*/
	#include<stdio.h>
	#include<stdlib.h>
	#include<string.h>
	#include<ctype.h>
	#include<math.h>
/*PRE-PROCESSOR DIRECTIVES DECLARATION*/
	#define size 50
/*USER-DEFINED FUNCTION DECLARATION*/
void createvararr(char vararr[],char xpr[]);
void populatevararr(char vararr[]);
int is_existtok(char vararr[],char tok);
char operator(char);
void ipush(int arr[],int,int *);
int getinput(char *);
void getinp(char infix[]);
char topelement(char stack[],int top);
int push(char stack[],int top,char x);
char pop(char stack[],int *top);
int priority(char ch);
int validexp(char infix[]);
int ipop(int [],int *);
int evalexp(char [],int [],char []);
/*DRIVER FUNCTION*/
void main(){
 int i,arr[size],k,j,m,choice,top=-1,val,t=-1,result,len;
 char vararr[size],postfix[size],ch,popped;
 char infix[size];
 char stack[size];
 populatevararr(postfix); 		
 do{
 	i=0;
 	j=0;
 	printf("\n________INFIX-POSTFIX OPERATIONS___________");
     printf("\n0.EXIT");
     printf("\n1.VALIDATE AN INFIX EXPRESSION");
	printf("\n2.CONVERT INFIX TO POSTFIX EXPRESSION");
	printf("\n3.EVALUATE POSTFIX EXPRESSION");  
	choice=getinput("ENTER OPERATION TO PERFORM:");
	switch(choice){
		case 0:
				printf("\nYou have opted to exit...\n");
				exit(0);
		case 1:		
				printf("Enter an infix expression:");
					getchar();
					fgets(infix,size,stdin);
					len=strlen(infix);
					infix[len-1]='\0';
					len=strlen(infix);
					while(infix[i]!='\0'){
						if(infix[i]==' '){
							for(m=i;m<len;m++)
								infix[m]=infix[m+1];
							len--;
							infix[m]='\0';	
						}								
						i++;		
					}
					i=0;
					while(infix[i]!='\0'){
						if(islower(infix[i]))
							infix[i]-=32;
					i++;		
					}
					k=validexp(infix);
					if(k==0)
						printf("\nValid infix expression");
			    	break;		
	    case 2:	
    			printf("\nINFIX EXPRESSION:");
    			printf("%s",infix);
    			if(validexp(infix)==0){	
		     		while((ch=infix[i])!='\0'){
		     			if(isalpha(ch))
		     				postfix[j++]=ch;
		     			else if(ch=='(')
		     				top=push(stack,top,ch);
		     			else if(ch==')'){
		     				while((popped=pop(stack,&top))!='(')
		     					postfix[j++]=popped;
		     			}	
		     			else{	
	     					if(priority(ch)>priority(topelement(stack,top)))
	     						top=push(stack,top,ch);
	     					else{
	     						while(priority(topelement(stack,top))>=priority(ch)){
	     							if(topelement(stack,top)=='#')
	     								break;
	     							popped=pop(stack,&top);
	     							postfix[j++]=popped;
	     						}
	     						top=push(stack,top,ch);
	     					}
		     			}
		     		i++;
		     		}
		     	while((popped=pop(stack,&top))!='#')
		     		postfix[j++]=popped;
		     	postfix[j]='\0';
		     	printf("\nEQUIVALENT POSTFIX EXPRESSION:");
		     	for(i=0;postfix[i]!='\0';i++)
		     		printf("%c",postfix[i]);
		       } 
		       else
		       		printf("\nNOT A VALID EXPRESSION");
		        break;
		case 3:	
				i=0;
				t=-1;
				if(postfix[0]!='#'){	
					printf("\nPOSTFIX EXPRESSION:%s\n",postfix);
					populatevararr(vararr);
					createvararr(vararr,postfix);
					while((ch=vararr[i])!='#'){
						printf("Enter value of %c:",ch);
						scanf("%d",&val);
						ipush(arr,val,&t);
						i++;
					}
					result=evalexp(postfix,arr,vararr);
					printf("\nVALUE OF EXPRESSION=%d",result);	
				}
				else
					printf("\n Enter an infix expression first to proceed");	
					break;
		default:
				printf("Invalid input\n");
	}
 }while(choice>0 && choice<=3);
}
/*FUNCTION DEFINITIONS*/
void ipush(int arr[],int val,int *t){
	*t=*t+1;
	arr[*t]=val;
}
void populatevararr(char vararr[]){
	int i;
	for(i=0;i<50;i++)
		vararr[i]='#';
}
int is_existtok(char vararr[],char tok){
	int k;
	char ch;
	k=0;
	while((ch=vararr[k])!='#'){
		if(ch==tok)
			return 0;
		++k;
	}
	return 1;
}		
void createvararr(char vararr[],char xpr[]){
	int i=0,j=0;	  
	char t; 
	while((t=xpr[i])!='\0'){
		if(isalpha(t)){
			if(is_existtok(vararr,t)){
				vararr[j]=t;
				++j;
			}
		}
		++i;
	}
}	
int evalexp(char postfix[],int arr[],char vararr[]){
	int i=0,j,brr[size],t=-1,val1,val2,r;
	char ch,c;
	while((ch=postfix[i])!='\0'){
		if(isalpha(ch)){
			j=0;
			while((c=vararr[j])!='#'){
				if(c==ch)
					ipush(brr,arr[j],&t);
				j++;
			}
		}
		else if(ch==operator(ch)){
				val1=ipop(brr,&t);
				val2=ipop(brr,&t);		    				    		
				switch(ch){
					case '+':
								r=val2+val1;
						    	ipush(brr,r,&t);
							    break;
				    case '-':
				    			r=val2-val1;
				    			ipush(brr,r,&t);
				    			break;
				    case '*':
				    			r=val2*val1;
				    			ipush(brr,r,&t);
				    			break;
				    case '/':
				    			r=val2/val1;
				    			ipush(brr,r,&t);
				    			break;
				    case '^':
				    			r=pow(val2,val1);
				    			ipush(brr,r,&t);
				    			break;
				}
			}
		i++;
	}   
	return (ipop(brr,&t));
} 				
int ipop(int brr[],int *t){
	int val;
	if(*t==-1)
		printf("\ninteger Stack empty");
	else{
		val=brr[*t];
		*t=*t-1;
	}
	return val;
}								
int validexp(char infix[]){
	int l,i=0,j,lb=0,rb=0,flag=0;
	l=strlen(infix);
	while(infix[i]!='\0'){
		 if(infix[0]==operator(infix[0])){
		 	printf("\nfirst character is an operator");
		 	flag=1;
		 	break;
		 }
		 else if(isalpha(infix[i]) && isalpha(infix[i+1])){
		 	printf("\nTwo consecutive operands");
			flag=1;
		 	break;
		 }
	 	 else if(infix[i]==operator(infix[i]) && infix[i+1]==operator(infix[i+1])){
	 	 	if((infix[i]!='\0')&&(infix[i+1]!='\0')){
	 	 		printf("\nTwo consecutive operators");
	 			flag=1;
	 			break;
	 		}	
	 	}
	 	 else if(infix[1]=='\0'){
	 	 	printf("\nsingle character expression");
			flag=1;
			break;
		 }
	 	 else if(infix[l-1]==operator(infix[l-1])){
	 	 		printf("\nLast character is an operator");
				flag=1;	 	 	
	 	 		break;
	 	 }
	 	 else if(infix[0]=='(' && infix[1]==')'){
	 	 	printf("\n() encountered");
	 	 	flag=1;
	 	 	break;
	 	 }
	 	 else if((infix[i]=='('&&infix[i+1]==')')||(infix[i]==')'&&infix[i+1]=='(')){
	 	 	printf("\ninvalid expression");
	 	 	flag=1;
	 	 	break;
	 	 }
	 	 else if(infix[2]==')'){
	 	 	printf("\ninvalid expression");
	 	 	flag=1;
	 	 	break;
	 	 }
	 	 else if((infix[i]==operator(infix[i])) && (infix[i+1]==')')){
	 	 	printf("\ninvalid expression");
	 	 	flag=1;
	 	 	break;
	 	 }
	 	 else if((infix[i]=='(') && (infix[i+1]==operator(infix[i+1]))){
	 	 	printf("operator after '('");
	 	 	flag=1;
	 	 	break;
	 	 }
	 	 else if(ispunct(infix[i]) && infix[i]!=operator(infix[i])){
	 	 	 if(!(isalpha(infix[i])) && infix[i]!='(' && infix[i]!=')'){
		 	 	printf("Invalid character %c",infix[i]);	
		 	 	flag=1;
	 	 		break;
	 	 	}
	 	 }
	 	 else{
	 	 		for(j=0;infix[j]!='\0';j++){
	 	 			if(infix[j]=='(')
						lb++;
					else if(infix[j]==')')
						rb++;
				}
				 if(lb<rb || lb>rb){
					printf("\nunequal no of braces");
					flag=1;
					break;
				}
				else{
					flag=0;
				}
			}
		++i;
	}		
	return flag;
}
int getinput(char *str){
		int value;
		printf("\n%s",str);
		scanf("%d",&value);
		return value;
}			
char operator(char op){
	if(op=='+' || op=='-' || op=='/' || op=='*' || op=='^')
		return op;
	else 
		return 0;
}		
int push(char stack[],int top,char x){
	top+=1;
	stack[top]=x;
	return top;
}
char pop(char stack[],int *top){
	char x;
	if(*top!=-1){
		x=stack[*top];
		*top-=1;
		return x;
	}
	else
		return '#';
}		
char topelement(char stack[],int top){
	char ch;
	if(top!=-1)
		ch=stack[top];
	else 
		ch='#';
 return ch;
}		
int priority(char ch){
	switch(ch){
		case '^':
				 return 3;
		case '/':
				 return 2;
		case '*':
				 return 2;
		case '+':
				 return 1;
		case '-':
				 return 1;
		default:
				return 0;
	}
}

/*EXECUTION TRAIL:
________INFIX-POSTFIX OPERATIONS___________
0.EXIT
1.VALIDATE AN INFIX EXPRESSION
2.CONVERT INFIX TO POSTFIX EXPRESSION
3.EVALUATE POSTFIX EXPRESSION
ENTER OPERATION TO PERFORM:1
Enter an infix expression:a

single character expression
________INFIX-POSTFIX OPERATIONS___________
0.EXIT
1.VALIDATE AN INFIX EXPRESSION
2.CONVERT INFIX TO POSTFIX EXPRESSION
3.EVALUATE POSTFIX EXPRESSION
ENTER OPERATION TO PERFORM:1
Enter an infix expression:(A+BC)

Two consecutive operands
________INFIX-POSTFIX OPERATIONS___________
0.EXIT
1.VALIDATE AN INFIX EXPRESSION
2.CONVERT INFIX TO POSTFIX EXPRESSION
3.EVALUATE POSTFIX EXPRESSION
ENTER OPERATION TO PERFORM:1
Enter an infix expression:(A+/c)

Two consecutive operators
________INFIX-POSTFIX OPERATIONS___________
0.EXIT
1.VALIDATE AN INFIX EXPRESSION
2.CONVERT INFIX TO POSTFIX EXPRESSION
3.EVALUATE POSTFIX EXPRESSION
ENTER OPERATION TO PERFORM:1
Enter an infix expression:+A-b

first character is an operator
________INFIX-POSTFIX OPERATIONS___________
0.EXIT
1.VALIDATE AN INFIX EXPRESSION
2.CONVERT INFIX TO POSTFIX EXPRESSION
3.EVALUATE POSTFIX EXPRESSION
ENTER OPERATION TO PERFORM:1
Enter an infix expression:A-b*

Last character is an operator
________INFIX-POSTFIX OPERATIONS___________
0.EXIT
1.VALIDATE AN INFIX EXPRESSION
2.CONVERT INFIX TO POSTFIX EXPRESSION
3.EVALUATE POSTFIX EXPRESSION
ENTER OPERATION TO PERFORM:1
Enter an infix expression:(A&B+c)

Invalid character &
________INFIX-POSTFIX OPERATIONS___________
0.EXIT
1.VALIDATE AN INFIX EXPRESSION
2.CONVERT INFIX TO POSTFIX EXPRESSION
3.EVALUATE POSTFIX EXPRESSION
ENTER OPERATION TO PERFORM:1
Enter an infix expression:(A+b)+((c+d-c)

unequal no of braces
________INFIX-POSTFIX OPERATIONS___________
0.EXIT
1.VALIDATE AN INFIX EXPRESSION
2.CONVERT INFIX TO POSTFIX EXPRESSION
3.EVALUATE POSTFIX EXPRESSION
ENTER OPERATION TO PERFORM:1
Enter an infix expression:(A+B)*(c- D)/E

Valid infix expression
________INFIX-POSTFIX OPERATIONS___________
0.EXIT
1.VALIDATE AN INFIX EXPRESSION
2.CONVERT INFIX TO POSTFIX EXPRESSION
3.EVALUATE POSTFIX EXPRESSION
ENTER OPERATION TO PERFORM:2

INFIX EXPRESSION:(A+B)*(C-D)/E
EQUIVALENT POSTFIX EXPRESSION:AB+CD-*E/
________INFIX-POSTFIX OPERATIONS___________
0.EXIT
1.VALIDATE AN INFIX EXPRESSION
2.CONVERT INFIX TO POSTFIX EXPRESSION
3.EVALUATE POSTFIX EXPRESSION
ENTER OPERATION TO PERFORM:3

POSTFIX EXPRESSION:AB+CD-*E/
Enter value of A:3
Enter value of B:4
Enter value of C:6
Enter value of D:5
Enter value of E:1

VALUE OF EXPRESSION=7
*/


		
