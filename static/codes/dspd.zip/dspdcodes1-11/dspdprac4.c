/* FILE NAME: dspdprac4.c*/ 
/* AUTHOR NAME:	RAJAT AGRAWAL*/
/* AIM:	TO STUDY AND IMPLEMENT DIFFERENT LINAR DATA STRUCTURES USING ARRAYS-
		STACK ADT,QUEUE ADT AND CIRCULAR QUEUE ADT*/
/* HEADER FILE INCLUSION*/
	#include<stdio.h>
	#include<stdlib.h>
/*PREPROCESSOR DIRECTIVES DECLARATION*/
	#define minvalue -999999
	#define maxsize 5
/*USER-DEFINED FUNCTION DECLARARTION*/
	void initialize_stack(int stack[]);
	void initialize_q(int queue[],int *front,int *rear);
	void initializeCQ(int Cqueue[],int *f,int *r);
	int push(int stack[],int top,int x);
	int pop(int stack[],int top);
	int isfull_stack(int stack[],int top);
	int isempty_stack(int stack[],int top);
	int peep(int stack[],int top);
	void display_stack(int stack[],int top);
	int isempty_q(int queue[],int front,int rear);
	int isfull_q(int queue[],int front,int rear);
	void insert_q(int queue[],int *front,int *rear,int key);
	int delete_q(int queue[],int *front,int *rear);
	int q_front(int queue[],int *front,int *rear);
	int q_rear(int queue[],int *front,int *rear);
	void display_q(int queue[],int front,int rear);
	int getinput(char *);
	int isfullCQ(int Cqueue[],int f,int r);
	int isemptyCQ(int Cqueue[],int f,int r);
	void insertCQ(int Cqueue[],int *f,int *r,int key);
	int deleteCQ(int Cqueue[],int *f,int  *r);
	int frontCQ(int Cq[],int front,int rear);
	int rearCQ(int Cq[],int front,int rear);
	void displayCQ(int Cqueue[],int *f,int *r);
/*DRIVER FUNCTION*/
void main(){
int i,choice,a,b,c,ans,stack[maxsize],queue[maxsize],Cq[maxsize],key;
int top,front,rear,f,r;
top=-1;
initialize_stack(stack);
initialize_q(queue,&front,&rear);
initializeCQ(Cq,&f,&r);
do{
	printf("\n____________LINEAR DATA STRUCTURES__________________\n");
	printf("\n0.EXIT    1.STACK_ADT     2.QUEUE_ADT     3.CIRCULARQUEUE_ADT");
	choice=getinput("Enter operation to perform:");
	switch(choice){
		case 0:
				printf("\nYou have opted to exit");
				exit(0);
		case 1:
				do{
					printf("\n___________OPERATIONS ON A STACK____________\n");
					printf("\n0.EXIT    1.ISEMPTY         2.ISFULL  3.PUSH");    
					printf("\n4.POP     5.DISPLAY_STACK   6.PEEP");
					choice=getinput("Enter opereration to perform:");
					switch(choice){
						case 0:
								printf("\nExiting from stack_adt");
								break;
						case 1:
								a=isempty_stack(stack,top);
								if(a==1)
									printf("\n STACK IS EMPTY");
								else
									printf("\nSTACK IS NOT EMPTY");	
								break;
						case 2:
								a=isfull_stack(stack,top);
								if(a==1)
									printf("\n STACK IS IS FULL");
								else
									printf("\nSTACK IS NOT FULL");	
								break;
						case 3: 
								if(isfull_stack(stack,top))
									printf("\nSTACK FULL:CANNOT PUSH");
								else{
									key=getinput("ENTER ELEMENT TO PUSH:");
									top=push(stack,top,key);
							    }
							    break;
					    case 4:
							   if(isempty_stack(stack,top))
									printf("\nSTACK UNDERFLOW:CANNOT POP"); 
							   else	
							   		top=pop(stack,top);
							   break;	
					    case 5:
					    	   display_stack(stack,top);
					    	   break;
					    case 6:
					    	   printf("VALUE AT TOP OF STACK=%d",peep(stack,top));
					    		break;
					    default:
					    		printf("\nINVALID INPUT");	
					   	
				   }
			   }while(choice>0 && choice<=6);
			   break;
	     case 2:
	     		do{
					printf("\n____________OPERATIONS ON A QUEUE_____________\n");
					printf("\n0.EXIT          1.ISEMPTY       2.ISFULL");   
					printf("\n3.INSERT_QUEUE  4.DELETE_QUEUE  5.DISPLAY_QUEUE"); 
					printf("\n6.AT-FRONT      7.AT-REAR");
					choice=getinput("Enter opereration to perform:");
					switch(choice){
						case 0:
								printf("\nEXITING FROM QUEUE ADT");
								break;					
						case 1:
								b=isempty_q(queue,front,rear);
								if(b==1)
									printf("\n QUEUE IS EMPTY");
								else
									printf("\nQUEUE IS NOT EMPTY");	
								break;
						case 2:
								b=isfull_q(queue,front,rear);
								if(b==1)
									printf("\n QUEUE IS FULL");
								else
									printf("\nQUEUE IS NOT FULL");	
								
								break;
						case 3:
								if(isfull_q(queue,front,rear))
									printf("\nQUEUE FULL:INSERT FAILED");
								else{
									key=getinput("ENTER ELEMENT TO INSERT:");
								    insert_q(queue,&front,&rear,key);
								}
								break;
						case 4:
								if(isempty_q(queue,front,rear))
									printf("\nQUEUE EMPTY:DELETION FAILED");
								else{
									key=delete_q(queue,&front,&rear);
									printf("\nDELETED ELEMENT IS:%d",key);
								}
								break; 	 
					    case 5:
								display_q(queue,front,rear);
								break;
						case 6:
								b=q_front(queue,&front,&rear);
								printf("\nVALUE AT FRONT:%d",b);
								break;
						case 7:
								b=q_rear(queue,&front,&rear);
								printf("\nVALUE AT REAR:%d",b);
								break;
						default:
								printf("\nINVALID INPUT");
					}
				}while(choice>0 && choice<=7);		    		
				 break;
		 case 3:
		 		do{ printf("\n______OPERATIONS ON A CIRCULAR-QUEUE_______\n");
					printf("\n0.EXIT       1.INSERTCQ     2.DELETECQ");    
					printf("\n3.ISFULLCQ   4.ISEMPTYCQ    5.DISPLAY_CQ");
					printf("\n6.AT-FRONT   7.AT-REAR\n");
					choice=getinput("Enter operation to perform:");
					switch(choice){
						case 0:
								printf("\nExiting from circular queue adt");
								break;
						case 1:
								if(!(isfullCQ(Cq,f,r))){
									key=getinput("Enter element to insert:");
									insertCQ(Cq,&f,&r,key);
								}
								else
									printf("\nQUEUE FULL:INSERT FAILED\n");
								break;
						case 2: if((f==-1)!=1){
									key=deleteCQ(Cq,&f,&r);
									printf("ELEMENT DELETED IS:%d",key);
								}
								else
									printf("\nQUEUE IS EMPTY:DELETION FAILED\n");
								break;
						case 3: c=isfullCQ(Cq,f,r);
									if(c==1)
									printf("\nCIRCULAR QUEUE IS FULL");
								else
									printf("\nCIRCULAR QUEUE IS NOT FULL");	
								break;
						case 4: c=isemptyCQ(Cq,f,r);
								if(c==1)
									printf("\nCIRCULAR QUEUE IS EMPTY");
								else
									printf("\nCIRCULAR QUEUE IS NOT EMPTY");	
								break;
						case 5: if(isemptyCQ(Cq,f,r)){
									printf("CIRCULAR QUEUE IS EMPTY");
									printf(":NOTHING TO DISPLAY\n");
								}
								else
						        	displayCQ(Cq,&f,&r);
								break;
					    case 6:
					    		printf("\nVALUE AT FRONT=%d",frontCQ(Cq,f,r));
					    		break;
					    case 7:
					    		printf("\nVALUE AT REAR=%d",rearCQ(Cq,f,r));
					    		break;
					    default:
								printf("\nINVALID INPUT");       		
		          }
		      }while(choice>0 && choice<=7);
		      break;					
		  default:
					printf("\nINVALID INPUT");
		}
		ans=getinput("Do you want to continue:(Enter 1 to continue)");
	}while(ans==1);
}		 			
/*FUNCTION DEFINITIONS*/
/*STACK FUNCTIONS*/
int push(int stack[],int top,int x){
	top+=1;
	stack[top]=x;
	return top;
}
int pop(int stack[],int top){
	int x;
	x=stack[top];
	top-=1;
	return top;
}
 int isfull_stack(int stack[],int top){
 	if(top==maxsize-1)
 		return 1;
 	return 0;
 }
 int isempty_stack(int stack[],int top){
 	if(top==-1)
 		return 1;
 	return 0;
 }
 int peep(int stack[],int top){
 if(top==-1)
 	return top;
 else
 	return stack[top];
 }	
void display_stack(int stack[],int top){
	int i;
	if(top==-1){
		printf("STACK IS EMPTY:NOTHING TO DISPLAY\n");
	}
	else{
		printf("STACK CONTENTS :");	
		for(i=top;i>=0 && stack[top]!=minvalue;i--)
			printf("%2d",stack[i]);
	    printf("\n");
	}
}
void initialize_stack(int stack[]){
	stack[0]=minvalue;
}
int getinput(char *str){
		int value;
		printf("\n%s",str);
		scanf("%d",&value);
		return value;
	}	
/*QUEUE FUNCTIONS*/
int isempty_q(int queue[],int front,int rear){
	if(front==-1)
		return 1;
	return 0;
}
int isfull_q(int queue[],int front,int rear){
	if(rear==maxsize-1)
		return 1;
	return 0;
}
void insert_q(int queue[],int *front,int *rear,int key){
	*rear+=1;
	queue[*rear]=key;
	if(*front==-1)
		*front=0;
	return;
}
int delete_q(int queue[],int *front,int *rear){
	int key;
	key=queue[*front];
		if(*front==0 && *rear==0)
			*front=*rear=-1;
		else
			*front=(*front)+1;
	return key;
}
void initialize_q(int queue[],int *front,int *rear){
	*front=-1;
	*rear=-1;
	queue[0]=minvalue;
}
int q_front(int queue[],int *front,int *rear){
	if(*front==-1)
		return *front;
	if(*front!=-1)
		return (queue[*front]);
}
int q_rear(int queue[],int *front,int *rear){
	if(*rear!=-1)
		return (queue[*rear]);
	else
		return *rear;
}
void display_q(int queue[],int front,int rear){
	int i;
	if(front==-1){
		printf("\nQUEUE IS EMPTY:NOTHING TO DISPLAY\n");
		return;
	}
	else{
		printf("QUEUE CONTENTS:");
		printf("[front]>>");
		for(i=front;i<=rear;i++)
			printf("%2d",queue[i]);
		printf(" <<[Rear]");
	printf("\n");
	return;
    }
}
/*CIRCULAR QUEUE FUNCTIONS*/
int frontCQ(int Cq[],int front,int rear){
	if(isemptyCQ(Cq,front,rear))
		return front;
	else
		return (Cq[front]);
}
int rearCQ(int Cq[],int front,int rear){
	if(isemptyCQ(Cq,front,rear))
		return rear; 
	else
		return (Cq[rear]);
}
void initializeCQ(int Cqueue[],int *f,int *r){
	*f=-1;
	*r=-1;
 }
 int isfullCQ(int Cqueue[],int f,int r){
	if((f==0 && r==maxsize-1) || ((r+1)==f))
		return 1;
	return 0;
 }
 int isemptyCQ(int Cqueue[],int f,int r){
 	if(f==-1)
 		return 1;
 	return 0;
 }
 void insertCQ(int Cqueue[],int *f,int *r,int key){
 
 	
 		if(*f==-1){
 			*r=0;
 			*f=0;
 		}
 		else if(*r==maxsize-1)
 			*r=0;
 		else
 			*r=*r+1;
 		Cqueue[*r]=key;
 }
 int deleteCQ(int Cqueue[],int *f,int  *r){
 	int key;
 		key=Cqueue[*f];
 		Cqueue[*f]=minvalue;
 		if(*f==*r)
 			*f=*r=-1;
 		else if(*f==maxsize-1)
 			*f=0;
 		else
 			*f=*f+1;
    return key;
 }
void displayCQ(int Cqueue[],int *f,int *r){
	int i=0;
	printf("CIRCULAR QUEUE CONTNETS:");
	if(*r >= *f){
		for(i=0;i<*f;i++)
			printf(" __");
	    printf("[front]>>");
	    for(i=*f;i<*r;i++)
	    	printf("%2d",Cqueue[i]);
	    printf("%2d <<[rear]\n",Cqueue[*r]);
	}
	else{
			 for(i=0;i<*r;i++)
				printf("%2d",Cqueue[i]);
			printf("%2d <<[rear]",Cqueue[*r]);
				for(;i<*f;i++)
					printf(" __");
				printf("[front]>>");
				for(i=*f;i<maxsize;i++)
	    			printf("%2d",Cqueue[i]);
    }
}

/*OUTPUT:
____________LINEAR DATA STRUCTURES__________________

0.EXIT    1.STACK_ADT     2.QUEUE_ADT     3.CIRCULARQUEUE_ADT
Enter operation to perform:1

___________OPERATIONS ON A STACK____________

0.EXIT    1.ISEMPTY         2.ISFULL  3.PUSH
4.POP     5.DISPLAY_STACK   6.PEEP
Enter opereration to perform:1

 STACK IS EMPTY
___________OPERATIONS ON A STACK____________

0.EXIT    1.ISEMPTY         2.ISFULL  3.PUSH
4.POP     5.DISPLAY_STACK   6.PEEP
Enter opereration to perform:2

STACK IS NOT FULL
___________OPERATIONS ON A STACK____________

0.EXIT    1.ISEMPTY         2.ISFULL  3.PUSH
4.POP     5.DISPLAY_STACK   6.PEEP
Enter opereration to perform:4

STACK UNDERFLOW:CANNOT POP
___________OPERATIONS ON A STACK____________

0.EXIT    1.ISEMPTY         2.ISFULL  3.PUSH
4.POP     5.DISPLAY_STACK   6.PEEP
Enter opereration to perform:5
STACK IS EMPTY:NOTHING TO DISPLAY

___________OPERATIONS ON A STACK____________

0.EXIT    1.ISEMPTY         2.ISFULL  3.PUSH
4.POP     5.DISPLAY_STACK   6.PEEP
Enter opereration to perform:6
VALUE AT TOP OF STACK=-1
___________OPERATIONS ON A STACK____________

0.EXIT    1.ISEMPTY         2.ISFULL  3.PUSH
4.POP     5.DISPLAY_STACK   6.PEEP
Enter opereration to perform:3

ENTER ELEMENT TO PUSH:2

___________OPERATIONS ON A STACK____________

0.EXIT    1.ISEMPTY         2.ISFULL  3.PUSH
4.POP     5.DISPLAY_STACK   6.PEEP
Enter opereration to perform:1

STACK IS NOT EMPTY
___________OPERATIONS ON A STACK____________

0.EXIT    1.ISEMPTY         2.ISFULL  3.PUSH
4.POP     5.DISPLAY_STACK   6.PEEP
Enter opereration to perform:5
STACK CONTENTS : 2

___________OPERATIONS ON A STACK____________

0.EXIT    1.ISEMPTY         2.ISFULL  3.PUSH
4.POP     5.DISPLAY_STACK   6.PEEP
Enter opereration to perform:6
VALUE AT TOP OF STACK=2
___________OPERATIONS ON A STACK____________

0.EXIT    1.ISEMPTY         2.ISFULL  3.PUSH
4.POP     5.DISPLAY_STACK   6.PEEP
Enter opereration to perform:4

___________OPERATIONS ON A STACK____________

0.EXIT    1.ISEMPTY         2.ISFULL  3.PUSH
4.POP     5.DISPLAY_STACK   6.PEEP
Enter opereration to perform:5
STACK IS EMPTY:NOTHING TO DISPLAY

___________OPERATIONS ON A STACK____________

0.EXIT    1.ISEMPTY         2.ISFULL  3.PUSH
4.POP     5.DISPLAY_STACK   6.PEEP
Enter opereration to perform:0

Exiting from stack_adt
Do you want to continue:(Enter 1 to continue)1

____________LINEAR DATA STRUCTURES__________________

0.EXIT    1.STACK_ADT     2.QUEUE_ADT     3.CIRCULARQUEUE_ADT
Enter operation to perform:2

____________OPERATIONS ON A QUEUE_____________

0.EXIT          1.ISEMPTY       2.ISFULL
3.INSERT_QUEUE  4.DELETE_QUEUE  5.DISPLAY_QUEUE
6.AT-FRONT      7.AT-REAR
Enter opereration to perform:1

 QUEUE IS EMPTY
____________OPERATIONS ON A QUEUE_____________

0.EXIT          1.ISEMPTY       2.ISFULL
3.INSERT_QUEUE  4.DELETE_QUEUE  5.DISPLAY_QUEUE
6.AT-FRONT      7.AT-REAR
Enter opereration to perform:2

QUEUE IS NOT FULL
____________OPERATIONS ON A QUEUE_____________

0.EXIT          1.ISEMPTY       2.ISFULL
3.INSERT_QUEUE  4.DELETE_QUEUE  5.DISPLAY_QUEUE
6.AT-FRONT      7.AT-REAR
Enter opereration to perform:4

QUEUE EMPTY:DELETION FAILED
____________OPERATIONS ON A QUEUE_____________

0.EXIT          1.ISEMPTY       2.ISFULL
3.INSERT_QUEUE  4.DELETE_QUEUE  5.DISPLAY_QUEUE
6.AT-FRONT      7.AT-REAR
Enter opereration to perform:5

QUEUE IS EMPTY:NOTHING TO DISPLAY

____________OPERATIONS ON A QUEUE_____________

0.EXIT          1.ISEMPTY       2.ISFULL
3.INSERT_QUEUE  4.DELETE_QUEUE  5.DISPLAY_QUEUE
6.AT-FRONT      7.AT-REAR
Enter opereration to perform:6

VALUE AT FRONT:-1
____________OPERATIONS ON A QUEUE_____________

0.EXIT          1.ISEMPTY       2.ISFULL
3.INSERT_QUEUE  4.DELETE_QUEUE  5.DISPLAY_QUEUE
6.AT-FRONT      7.AT-REAR
Enter opereration to perform:7

VALUE AT REAR:-1
____________OPERATIONS ON A QUEUE_____________

0.EXIT          1.ISEMPTY       2.ISFULL
3.INSERT_QUEUE  4.DELETE_QUEUE  5.DISPLAY_QUEUE
6.AT-FRONT      7.AT-REAR
Enter opereration to perform:3

ENTER ELEMENT TO INSERT:5

____________OPERATIONS ON A QUEUE_____________

0.EXIT          1.ISEMPTY       2.ISFULL
3.INSERT_QUEUE  4.DELETE_QUEUE  5.DISPLAY_QUEUE
6.AT-FRONT      7.AT-REAR
Enter opereration to perform:1

QUEUE IS NOT EMPTY
____________OPERATIONS ON A QUEUE_____________

0.EXIT          1.ISEMPTY       2.ISFULL
3.INSERT_QUEUE  4.DELETE_QUEUE  5.DISPLAY_QUEUE
6.AT-FRONT      7.AT-REAR
Enter opereration to perform:5
QUEUE CONTENTS:[front]>> 5 <<[Rear]

____________OPERATIONS ON A QUEUE_____________

0.EXIT          1.ISEMPTY       2.ISFULL
3.INSERT_QUEUE  4.DELETE_QUEUE  5.DISPLAY_QUEUE
6.AT-FRONT      7.AT-REAR
Enter opereration to perform:6

VALUE AT FRONT:5
____________OPERATIONS ON A QUEUE_____________

0.EXIT          1.ISEMPTY       2.ISFULL
3.INSERT_QUEUE  4.DELETE_QUEUE  5.DISPLAY_QUEUE
6.AT-FRONT      7.AT-REAR
Enter opereration to perform:7

VALUE AT REAR:5
____________OPERATIONS ON A QUEUE_____________

0.EXIT          1.ISEMPTY       2.ISFULL
3.INSERT_QUEUE  4.DELETE_QUEUE  5.DISPLAY_QUEUE
6.AT-FRONT      7.AT-REAR
Enter opereration to perform:0

EXITING FROM QUEUE ADT
Do you want to continue:(Enter 1 to continue)1

____________LINEAR DATA STRUCTURES__________________

0.EXIT    1.STACK_ADT     2.QUEUE_ADT     3.CIRCULARQUEUE_ADT
Enter operation to perform:3

______OPERATIONS ON A CIRCULAR-QUEUE_______

0.EXIT       1.INSERTCQ     2.DELETECQ
3.ISFULLCQ   4.ISEMPTYCQ    5.DISPLAY_CQ
6.AT-FRONT   7.AT-REAR

Enter operation to perform:3

CIRCULAR QUEUE IS NOT FULL
______OPERATIONS ON A CIRCULAR-QUEUE_______

0.EXIT       1.INSERTCQ     2.DELETECQ
3.ISFULLCQ   4.ISEMPTYCQ    5.DISPLAY_CQ
6.AT-FRONT   7.AT-REAR

Enter operation to perform:4

CIRCULAR QUEUE IS EMPTY
______OPERATIONS ON A CIRCULAR-QUEUE_______

0.EXIT       1.INSERTCQ     2.DELETECQ
3.ISFULLCQ   4.ISEMPTYCQ    5.DISPLAY_CQ
6.AT-FRONT   7.AT-REAR

Enter operation to perform:5
CIRCULAR QUEUE IS EMPTY:NOTHING TO DISPLAY

______OPERATIONS ON A CIRCULAR-QUEUE_______

0.EXIT       1.INSERTCQ     2.DELETECQ
3.ISFULLCQ   4.ISEMPTYCQ    5.DISPLAY_CQ
6.AT-FRONT   7.AT-REAR

Enter operation to perform:6

VALUE AT FRONT=-1
______OPERATIONS ON A CIRCULAR-QUEUE_______

0.EXIT       1.INSERTCQ     2.DELETECQ
3.ISFULLCQ   4.ISEMPTYCQ    5.DISPLAY_CQ
6.AT-FRONT   7.AT-REAR

Enter operation to perform:7

VALUE AT REAR=-1
______OPERATIONS ON A CIRCULAR-QUEUE_______

0.EXIT       1.INSERTCQ     2.DELETECQ
3.ISFULLCQ   4.ISEMPTYCQ    5.DISPLAY_CQ
6.AT-FRONT   7.AT-REAR

Enter operation to perform:1

Enter element to insert:2

______OPERATIONS ON A CIRCULAR-QUEUE_______

0.EXIT       1.INSERTCQ     2.DELETECQ
3.ISFULLCQ   4.ISEMPTYCQ    5.DISPLAY_CQ
6.AT-FRONT   7.AT-REAR

Enter operation to perform:1

Enter element to insert:3

______OPERATIONS ON A CIRCULAR-QUEUE_______

0.EXIT       1.INSERTCQ     2.DELETECQ
3.ISFULLCQ   4.ISEMPTYCQ    5.DISPLAY_CQ
6.AT-FRONT   7.AT-REAR

Enter operation to perform:2
ELEMENT DELETED IS:2
______OPERATIONS ON A CIRCULAR-QUEUE_______

0.EXIT       1.INSERTCQ     2.DELETECQ
3.ISFULLCQ   4.ISEMPTYCQ    5.DISPLAY_CQ
6.AT-FRONT   7.AT-REAR

Enter operation to perform:4

CIRCULAR QUEUE IS NOT EMPTY
______OPERATIONS ON A CIRCULAR-QUEUE_______

0.EXIT       1.INSERTCQ     2.DELETECQ
3.ISFULLCQ   4.ISEMPTYCQ    5.DISPLAY_CQ
6.AT-FRONT   7.AT-REAR

Enter operation to perform:5
CIRCULAR QUEUE CONTNETS: __[front]>> 3 <<[rear]

______OPERATIONS ON A CIRCULAR-QUEUE_______

0.EXIT       1.INSERTCQ     2.DELETECQ
3.ISFULLCQ   4.ISEMPTYCQ    5.DISPLAY_CQ
6.AT-FRONT   7.AT-REAR

Enter operation to perform:6

VALUE AT FRONT=3
______OPERATIONS ON A CIRCULAR-QUEUE_______

0.EXIT       1.INSERTCQ     2.DELETECQ
3.ISFULLCQ   4.ISEMPTYCQ    5.DISPLAY_CQ
6.AT-FRONT   7.AT-REAR

Enter operation to perform:7

VALUE AT REAR=3
______OPERATIONS ON A CIRCULAR-QUEUE_______

0.EXIT       1.INSERTCQ     2.DELETECQ
3.ISFULLCQ   4.ISEMPTYCQ    5.DISPLAY_CQ
6.AT-FRONT   7.AT-REAR

Enter operation to perform:0

Exiting from circular queue adt
Do you want to continue:(Enter 1 to continue)0
*/
									
		     		
		    		
		  		
				  		
									
									
			
