/**FILE NAME: DSPDPRAC10.C*/
/**AUTHOR NAME: RAJAT AGRAWAL*/
/**DATE: 14/10/17*/
/*AIM:TO STUDY GRAPH DATA STRUCTURE AND DEMONSTRATE DIFFERENT TRAVERSALS ON IT-DFS AND BFS */
/*HEADER FILE INCLUSION*/
#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include<time.h>
#include"queueadt.h"
/*GRAPH DEFINITION*/
	struct queue{
		int data[mx];
		int f;
		int r;
	};
	typedef struct queue Q;
	struct adjlstnode{
		int vertex;
		struct adjlstnode *link;
	};
	typedef struct adjlstnode gnode;
	typedef gnode *graph;	
/*PRE-PROCESSOR DIRECTIVES*/
#define mx 8
/*function declarations*/
void insert_q(int [],int *front,int *rear,int key);
graph insertorderedll(graph first[],int u,int key);
void dfsll(graph first[],int src,char a[],int visited[]);
void bfsll(graph first[],int src,char a[],int visited[],Q *q);
graph createnode();
void displayll(graph first[],int ver);
void display_q(int [],int front,int rear);
int delete_q(int [],int *front,int *rear);
int isfull_q(int [],int front,int rear);
void initialize_q(int [],int *front,int *rear);
void dfs(int adj[][mx],int src,char a[],int ver,int visited[]);
void initialize(int adj[][mx],int v);
void createadj(int adj[][mx],int u,int v,int type);
void bfs(int adj[][mx],int src,char a[],int ver,int visited[],int [],int *,int *);
int getinput(char *);
void initialize_Q(Q *q);
int dequeue(Q *p);
void enqueue(Q *p,int key);
int isempty(Q *p);
 /*DRIVER FUNCTION*/        
void main(){
int adj[mx][mx],ver,v,u,front=-1,rear=-1;
char a[41],c;
int visited[mx],q[mx*mx],i,j,src,type,choice;
graph first[mx],temp;
Q q1;
initialize_Q(&q1);
srand(time(NULL));
for(i=0;i<40;i++)		
	a[i]='A'+random()%26;
a[40]=(char)0;
do{
	ver=0;
	printf("\n______GRAPH TRAVERSALS______");
	printf("\n0.EXIT");
	printf("\n1.EXECUTE USING ADJACENCY MATRIX");
	printf("\n2.EXECUTE USING ADJACENCY LIST");
	choice=getinput("Enter operation to perform:");
	switch(choice){
		case 0:
			printf("\nYou have opted to exit\n");
			exit(0);
		case 1:
			initialize_q(q,&front,&rear);
			do{
				printf("\n______EXECUTION USING ADJACENCY MATRIX________");
				printf("\n0.EXIT");
				printf("\n1.PRINT ADJACENCY MATRIX");
				printf("\n2.EXECUTE DFS");
				printf("\n3.EXECUTE BFS");
				choice=getinput("Enter operation to perform:");
				switch(choice){
					case 0:	
						printf("\nYou have opted to exit\n");
						break;
					case 1:
						printf("\nEnter type of graph:");
						printf("\n1.DIRECTED");
						printf("\n2.UN-DIRECTED\n");	
						type=getinput("Enter your choice:");	
						do{
							 printf("\nEnter no of vertices:(<=%d)",mx);
							 scanf("%d",&ver);
						  }while(ver>mx || ver<0);
						  initialize(adj,ver);
						  printf("\nEnter edges as(u,v) & -1 to terminate:");
						  printf("\n\t\tEDGE  |  ADJACENT EDGE\n");
						 printf("\t   --------------------------------\n");
						  do{
						  	  printf("\t\t  ");
							  scanf("%d%d",&u,&v);
							  if(u==-1 || v==-1)
								  break;
								else if(adj[u][v]==1)
									  printf("\t\tEdge already exists\n");
							  else if((u<ver && v<ver) && (u>-1 || v>-1))
								  createadj(adj,u,v,type);
								else
								  printf("\t\tInvalid edges\n");
							 }while(u<mx && v<mx);
							 printf("\nADJACENCY MATRIX :\n");
							 printf("\n u|v |");
							 for(i=0;i<ver;i++)
								 printf(" %d ",i);
								 printf("\n");
								 for(i=0;i<5*ver;i++)
							 			printf("-");
							 	printf("\n");		
						  for(i=0;i<ver;i++){
						  	printf("  %d  | ",i);
							 for(j=0;j<ver;j++)
								  printf("%d  ",adj[i][j]);
						  printf("\n");
						  }
						  break;
					case 2:
						if(ver!=0){
							printf("\nAVAILABLE VERTICES:");
							for(i=0;i<ver;i++)
								printf("\n%d %c",i,a[i]);
						do{
							for(i=0;i<ver;i++)
								visited[i]=0;
							printf("\nEnter source vertex(0-%d):",ver-1);
							scanf("%d",&src);
							}while(src==-1 || src>=ver);
							printf("\nDEPTH FIRST SEARCH TRAVERSAL:");
						  dfs(adj,src,a,ver,visited);
						 }   
						break;
 					case 3:
						if(ver!=0){
 							printf("\nAVAILABLE VERTICES:");
								for(i=0;i<ver;i++)
									printf("\n%d %c",i,a[i]);
							do{
								for(i=0;i<ver;i++)
									visited[i]=0;
								printf("\nEnter source vertex(0-%d):",ver-1);
								scanf("%d",&src);
								}while(src==-1 || src>=ver);
								printf("\nBREADTH FIRST SEARCH TRAVERSAL:");
								bfs(adj,src,a,ver,visited,q,&front,&rear);
 						}	
 							break;
					default:
							printf("\nINVALID CHOICE");
				}
				}while(choice>0 && choice<=3);
				break;
			case 2:
				do{
					printf("\n________EXECUTION USING ADJACENCY LIST_______");
					printf("\n0.EXIT");
					printf("\n1.PRINT ADJACENCY LIST");
					printf("\n2.EXECUTE DFS");
					printf("\n3.EXECUTE BFS");
					choice=getinput("Enter operation to perform:");
					switch(choice){
						case 0:	
							printf("\nYou have opted to exit\n");
							break;
						case 1:
							printf("\nEnter type of graph:");
							printf("\n1.DIRECTED");
							printf("\n2.UN-DIRECTED\n");	
							type=getinput("Enter your choice:");	
							do{
								 printf("\nEnter no of vertices:(<=%d)",mx);
								 scanf("%d",&ver);
							  }while(ver>mx || ver<0);
							  for(i=0;i<ver;i++){
									first[i]=NULL;
								}

							  do{
								  printf("Enter edges as(u,v) & -1 to terminate:");
								  scanf("%d%d",&u,&v);
								  if(u==-1 || v==-1)
									  break;
		    					  else if(first[u]!=NULL && u<ver && v<ver){
									temp=first[u];
									while(temp!=NULL){
									   if(temp->vertex==v){	
							  		   	 printf("Edge already exists\n");
							  		   	 temp=temp->link;
							  		 	 break;	
									   }													  		
								  	   else{
							  		      temp=temp->link;
							  			  if(temp==NULL){
						  					first[u]=insertorderedll(first,u,v);
						  					if(type==2 && u!=v)
										     first[v]=insertorderedll(first,v,u);	
						  				  }
								  		}	  	
									}
								  }		
								  else if((u<ver && v<ver) && (u>-1 || v>-1)){
									first[u]=insertorderedll(first,u,v);
									if(type==2 && u!=v)
										first[v]=insertorderedll(first,v,u);	
		     						}						 	
									else
									  printf("Invalid edges\n");
								 }while(u<mx && v<mx);
								 printf("\nADJACENCY LIST:\n"); 
								 displayll(first,ver);
							  break;
							case 2:
								if(ver!=0){
									printf("\nAVAILABLE VERTICES:");
								for(i=0;i<ver;i++)
									printf("\n%d %c",i,a[i]);
								do{
									for(i=0;i<ver;i++)
										visited[i]=0;
								   printf("\nEnter source vertex(0-%d):",ver-1);
									scanf("%d",&src);
								}while(src==-1 || src>=ver);
									printf("\nDEPTH FIRST SEARCH TRAVERSAL:");
								  dfsll(first,src,a,visited);
								}   
 								break;
	 						case 3:
 								if(ver!=0){
									printf("\nAVAILABLE VERTICES:");
									for(i=0;i<ver;i++)
										printf("\n%d %c",i,a[i]);
									do{
										for(i=0;i<ver;i++)
											visited[i]=0;
									   printf("\nEnter source vertex(0-%d):",ver-1);
										scanf("%d",&src);
									}while(src==-1 || src>=ver);
								    printf("\nBREADTH FIRST SEARCH TRAVERSAL:");
									bfsll(first,src,a,visited,&q1);   
	 							}	
	 							break;
							default:
										printf("\nINVALID CHOICE");
						}
				}while(choice>0 && choice<=3);
				break;
				default:
						printf("\nINVALID CHOICE");				
			}
					
	}while(choice>=0);
}    
 void initialize(int adj[][mx],int v){											
    int i,j;
    for(i=0;i<v;i++)
        for(j=0;j<v;j++)
            adj[i][j]=0;
 }
 void createadj(int adj[][mx],int u,int v,int type){
 if(type==1)
 adj[u][v]=1;
 else if(type==2)
    adj[u][v]=adj[v][u]=1;
 else
    printf("\nInvalid graph type");
 }
 void dfs(int adj[][mx],int src,char a[],int ver,int visited[]){
    int cnt;
    printf("%c ",a[src]);
    visited[src]=1;
    for(cnt=1;cnt<ver;cnt++)
        if(!visited[cnt] && adj[src][cnt]==1)
        dfs(adj,cnt,a,ver,visited);
 }
void bfs(int adj[][mx],int src,char a[],int ver,int visited[],int q[],int *front,int *rear){
	int temp,j,w;
	insert_q(q,front,rear,src);
	visited[src]=1;
	while(!(isempty_q(q,*front,*rear))){
				temp=delete_q(q,&*front,&*rear);
				if(visited[temp]==1){
					printf("%c ",a[temp]);
				}			
					for(j=0;j<ver;j++){
						if(adj[temp][j]==1){
								w=j;
							if(visited[w]==0){
								visited[w]=1;
								insert_q(q,front,rear,w);
							}		
						}
						if(*front==ver-1)
							*front=-1;	
					}		
	}
}	

void bfsll(graph first[],int src,char a[],int visited[],Q *q){
	int temp,w;
	graph p;
	enqueue(q,src);
		visited[src]=1;
		while(!(isempty(q))){
			temp=dequeue(q);
			if(visited[temp]==1)
				printf("%c ",a[temp]);
				for(p=first[temp];p!=NULL;p=p->link){
					w=p->vertex;
					if(visited[w]!=1){
						visited[w]=1;
						enqueue(q,w);
					}
				}
			}									
	return;	
}		
 int getinput(char *str){
		int value;
		printf("\n%s",str);
		scanf("%d",&value);
		return value;
}	
graph createnode(){
	graph neww;
	neww=(graph)malloc(sizeof(gnode));
	if(neww==NULL)
		printf("AVAIL STACK UNDERFLOW");
	return neww;
}
graph insertorderedll(graph first[],int u,int key){
	graph neww,temp;
	neww=createnode();
	if(neww==NULL){
		printf("\nNode not allocated,insert failed");
		return first[u];
	}
	neww->vertex=key;
	neww->link=NULL;
	if(first[u]==NULL){
		return neww;
	}
	if(first[u]->vertex>=neww->vertex){
		neww->link=first[u];
		return neww;
	}
	temp=first[u];
	while(temp->link!=NULL && temp->link->vertex<=neww->vertex)
		temp=temp->link;
	neww->link=temp->link;	
	temp->link=neww;
	return first[u];
}				
void dfsll(graph first[],int src,char a[],int visited[]){
	graph w;
	visited[src]=1;
	printf("%c ",a[src]);
	for(w=first[src];w;w=w->link)
		if(!visited[w->vertex])
			dfsll(first,w->vertex,a,visited);
}
void displayll(graph first[],int ver){
	graph neww;
	int i,j;
	printf("\nEDGE|\n");
   for(i=0;i<5.5*ver;i++)
		printf("-");
	for(i=0;i<ver;i++){
			printf("\n  %d ",i);
			neww=first[i];
			for(j=i;j<ver;j++){
				if(first[j]==NULL)
					printf(" ");
				else{
						while(neww!=NULL){
							printf("->");
							printf(" %d ",neww->vertex);
							neww=neww->link;
						}
				}	
			}
	}						
}
void initialize_Q(Q *q){
	q->f=-1;
	q->r=-1;
	q->data[0]=-1;
}
void enqueue(Q *p,int key){
	if(p->r==-1){
		p->r=p->f=0;
		p->data[p->r]=key;
	}
	else{
		p->r=p->r+1;
		p->data[p->r]=key;
	}	
}
int dequeue(Q *p){
	int x;
	x=p->data[p->f];
	if(p->r==p->f){
		p->r=-1;
		p->f=-1;
	}
	else
		p->f=p->f+1;
	return x;		
}	
int isempty(Q *p){
	if(p->r==-1)
		return 1;
	return 0;
}
/*EXECUTION TRAIL
______GRAPH TRAVERSALS______
0.EXIT
1.EXECUTE USING ADJACENCY MATRIX
2.EXECUTE USING ADJACENCY LIST
Enter operation to perform:1

______EXECUTION USING ADJACENCY MATRIX________
0.EXIT
1.PRINT ADJACENCY MATRIX
2.EXECUTE DFS
3.EXECUTE BFS
Enter operation to perform:1

Enter type of graph:
1.DIRECTED
2.UN-DIRECTED

Enter your choice:1

Enter no of vertices:(<=8)3

Enter edges as(u,v) & -1 to terminate:
		EDGE  |  ADJACENT EDGE
	   --------------------------------
		  0			1
		  0			2	
		  1			2
		  1			0
		  2			1
		  -1    	-1

ADJACENCY MATRIX :

 u|v | 0  1  2 
---------------
  0  | 0  1  1  
  1  | 1  0  1  
  2  | 0  1  0  

______EXECUTION USING ADJACENCY MATRIX________
0.EXIT
1.PRINT ADJACENCY MATRIX
2.EXECUTE DFS
3.EXECUTE BFS
Enter operation to perform:2

AVAILABLE EDGES:
0 U
1 Z
2 Q
Enter source vertex(0-2):0

DEPTH FIRST SEARCH TRAVERSAL:U Z Q 
______EXECUTION USING ADJACENCY MATRIX________
0.EXIT
1.PRINT ADJACENCY MATRIX
2.EXECUTE DFS
3.EXECUTE BFS
Enter operation to perform:3

AVAILABLE EDGES:
0 U
1 Z
2 Q
Enter source vertex(0-2):2

BREADTH FIRST SEARCH TRAVERSAL:Q Z U 
______EXECUTION USING ADJACENCY MATRIX________
0.EXIT
1.PRINT ADJACENCY MATRIX
2.EXECUTE DFS
3.EXECUTE BFS
Enter operation to perform:0

You have opted to exit

______GRAPH TRAVERSALS______
0.EXIT
1.EXECUTE USING ADJACENCY MATRIX
2.EXECUTE USING ADJACENCY LIST
Enter operation to perform:2

________EXECUTION USING ADJACENCY LIST_______
0.EXIT
1.PRINT ADJACENCY LIST
2.EXECUTE DFS
3.EXECUTE BFS
Enter operation to perform:1

Enter type of graph:
1.DIRECTED
2.UN-DIRECTED

Enter your choice:2

Enter no of vertices:(<=8)3
Enter edges as(u,v) & -1 to terminate:0 1
Enter edges as(u,v) & -1 to terminate:2 2
Enter edges as(u,v) & -1 to terminate:2 0
Enter edges as(u,v) & -1 to terminate:1 1
Enter edges as(u,v) & -1 to terminate:1 2
Enter edges as(u,v) & -1 to terminate:-1 -1

ADJACENCY LIST:

EDGE|
-----------------
  0 -> 1 -> 2 
  1 -> 0 -> 1 -> 2 
  2 -> 0 -> 1 -> 2 
________EXECUTION USING ADJACENCY LIST_______
0.EXIT
1.PRINT ADJACENCY LIST
2.EXECUTE DFS
3.EXECUTE BFS
Enter operation to perform:2

AVAILABLE EDGES:
0 U
1 Z
2 Q
Enter source vertex(0-2):0

DEPTH FIRST SEARCH TRAVERSAL:U Z Q 
________EXECUTION USING ADJACENCY LIST_______
0.EXIT
1.PRINT ADJACENCY LIST
2.EXECUTE DFS
3.EXECUTE BFS
Enter operation to perform:3

AVAILABLE EDGES:
0 U
1 Z
2 Q
Enter source vertex(0-2):1

BREADTH FIRST SEARCH TRAVERSAL:Z U Q 
________EXECUTION USING ADJACENCY LIST_______
0.EXIT
1.PRINT ADJACENCY LIST
2.EXECUTE DFS
3.EXECUTE BFS
Enter operation to perform:0

You have opted to exit

______GRAPH TRAVERSALS______
0.EXIT
1.EXECUTE USING ADJACENCY MATRIX
2.EXECUTE USING ADJACENCY LIST
Enter operation to perform:0

You have opted to exit
*/
